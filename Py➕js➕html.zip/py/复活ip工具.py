import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, simpledialog
import socket
import threading
import queue
import json
from datetime import datetime as dt
import base64
import time
import requests
import os

class CustomMessageBox(tk.Toplevel):
	def __init__(self, parent, title, message, **kwargs):
		super().__init__(parent, **kwargs)
		self.title(title)
		self.geometry("300x150")
		self.resizable(False, False)

		parent_x = parent.winfo_x()
		parent_y = parent.winfo_y()
		parent_width = parent.winfo_width()
		parent_height = parent.winfo_height()
		x = parent_x + (parent_width - 300) // 2
		y = parent_y + (parent_height - 150) // 2
		self.geometry(f"+{x}+{y}")

		message_label = tk.Label(self, text=message, fg="green", font=("Microsoft YaHei", 10), wraplength=280)
		message_label.pack(pady=20, padx=10)

		ok_button = tk.Button(self, text="OK", command=self.destroy,
							  fg="red", font=("Microsoft YaHei", 10, "bold"),
							  width=10)
		ok_button.pack(pady=10)

		self.transient(parent)
		self.grab_set()
		parent.wait_window(self)

class IPScannerApp:
	def __init__(self, root):
		self.root = root
		# 正确的 base64 标题（小凯IP段扫描工具）
		self._original_title = self._decode_title("5bCP5YevSVCS5q61JuaJq+aPj+W3peWFtw==")
		self.root.title(self._original_title)
		self.root.geometry("650x680")
		self.root.resizable(True, True)

		self.set_dark_theme()

		main_frame = ttk.Frame(root, padding=10)
		main_frame.pack(fill=tk.BOTH, expand=True)

		title_frame = ttk.Frame(main_frame)
		title_frame.pack(fill=tk.X, pady=(0, 10))

		title_container = ttk.LabelFrame(title_frame, padding=(10, 5))
		title_container.pack(fill=tk.X, expand=True)

		title_label = ttk.Label(title_container,
								text=self._original_title,
								font=("Microsoft YaHei", 18, "bold"),
								foreground="#4fc3f7")
		title_label.pack()

		instruction = ttk.Label(main_frame,
								text="请输入IP地址和端口",
								font=("Microsoft YaHei", 10),
								foreground="#DAA520")
		instruction.pack(pady=(0, 10))

		input_frame = ttk.Frame(main_frame)
		input_frame.pack(fill=tk.X, pady=(0, 10))

		self.ip_entry = tk.Entry(input_frame,
								 width=25,
								 font=("Microsoft YaHei", 10),
								 bg="#3e3e3e",
								 fg="#00FF00",
								 insertbackground="white")
		self.ip_entry.pack(side=tk.LEFT, padx=(0, 10), fill=tk.X, expand=True)
		self.ip_entry.insert(0, "192.168.1.1:80")

		button_frame = ttk.Frame(main_frame)
		button_frame.pack(fill=tk.X, pady=(0, 10))

		self.start_button = tk.Button(button_frame,
									  text="开始扫描",
									  command=self.start_scan,
									  bg="#3e3e3e",
									  fg="#DAA520",
									  font=("Microsoft YaHei", 10, "bold"),
									  relief=tk.RAISED,
									  bd=1)
		self.start_button.pack(side=tk.LEFT, padx=(0, 5))

		self.stop_button = tk.Button(button_frame,
									 text="停止扫描",
									 command=self.stop_scan,
									 bg="#3e3e3e",
									 fg="#DAA520",
									 font=("Microsoft YaHei", 10, "bold"),
									 relief=tk.RAISED,
									 bd=1,
									 state=tk.DISABLED)
		self.stop_button.pack(side=tk.LEFT, padx=(5, 5))

		self.save_button = tk.Button(button_frame,
									 text="保存结果",
									 command=self.save_results,
									 bg="#3e3e3e",
									 fg="#DAA520",
									 font=("Microsoft YaHei", 10, "bold"),
									 relief=tk.RAISED,
									 bd=1)
		self.save_button.pack(side=tk.LEFT, padx=(5, 0))

		self.location_frame = ttk.Frame(main_frame)
		self.location_frame.pack(fill=tk.X, pady=(5, 10))

		self.location_var = tk.StringVar()
		self.location_label = ttk.Label(self.location_frame,
										textvariable=self.location_var,
										font=("Microsoft YaHei", 10),
										foreground="#FF0000",
										background="#2d2d2d")
		self.location_label.pack(fill=tk.X, expand=True)

		config_frame = ttk.Frame(main_frame)
		config_frame.pack(fill=tk.X, pady=(5, 10))

		c_label = ttk.Label(config_frame,
							text="C段范围:",
							font=("Microsoft YaHei", 9),
							foreground="#DAA520")
		c_label.pack(side=tk.LEFT, padx=(0, 5))

		self.c_entry = tk.Entry(config_frame,
								width=4,
								font=("Microsoft YaHei", 9),
								bg="#3e3e3e",
								fg="#00FF00",
								insertbackground="white")
		self.c_entry.pack(side=tk.LEFT, padx=(0, 15))
		self.c_entry.insert(0, "1-255")

		d_label = ttk.Label(config_frame,
							text="D段范围:",
							font=("Microsoft YaHei", 9),
							foreground="#DAA520")
		d_label.pack(side=tk.LEFT, padx=(0, 5))

		self.d_entry = tk.Entry(config_frame,
								width=4,
								font=("Microsoft YaHei", 9),
								bg="#3e3e3e",
								fg="#00FF00",
								insertbackground="white")
		self.d_entry.pack(side=tk.LEFT, padx=(0, 15))
		self.d_entry.insert(0, "1-255")

		thread_label = ttk.Label(config_frame,
								 text="线程数:",
								 font=("Microsoft YaHei", 9),
								 foreground="#DAA520")
		thread_label.pack(side=tk.LEFT, padx=(0, 5))

		self.thread_entry = tk.Entry(config_frame,
									 width=4,
									 font=("Microsoft YaHei", 9),
									 bg="#3e3e3e",
									 fg="#00FF00",
									 insertbackground="white")
		self.thread_entry.pack(side=tk.LEFT, padx=(0, 15))
		self.thread_entry.insert(0, "100")

		# 移除“本群使用，请勿外传，密码半月更换一次。”的提示标签
		# notice_frame = ttk.Frame(main_frame)
		# notice_frame.pack(fill=tk.X, pady=(10, 0))
		# notice_label = ttk.Label(notice_frame,
		#                          text="本群使用，请勿外传，密码半月更换一次。",
		#                          font=("Microsoft YaHei", 10, "bold"),
		#                          foreground="#A020F0")
		# notice_label.pack(pady=5)

		log_label = ttk.Label(main_frame,
							  text="扫描日志：",
							  font=("Microsoft YaHei", 9, "bold"),
							  foreground="#DAA520")
		log_label.pack(anchor=tk.W, pady=(5, 5))

		self.log_area = scrolledtext.ScrolledText(main_frame,
												  height=12,
												  font=("Consolas", 9),
												  bg="#1e1e1e",
												  fg="#d4d4d4",
												  insertbackground="white")
		self.log_area.tag_config("log", foreground="#00FF00")
		self.log_area.pack(fill=tk.BOTH, expand=True)
		self.log_area.config(state=tk.DISABLED)

		status_frame = ttk.Frame(main_frame)
		status_frame.pack(fill=tk.X, pady=(10, 0))

		self.progress_label = ttk.Label(status_frame,
										text="就绪",
										font=("Microsoft YaHei", 9),
										foreground="#FF0000")
		self.progress_label.pack(side=tk.LEFT)

		self.progress_var = tk.StringVar()
		self.progress_var.set("0/0")
		self.count_label = ttk.Label(status_frame,
									 textvariable=self.progress_var,
									 font=("Microsoft YaHei", 9, "bold"),
									 foreground="#FF0000")
		self.count_label.pack(side=tk.RIGHT)

		self.progress = ttk.Progressbar(status_frame, mode="determinate")
		self.progress.pack(fill=tk.X, pady=(5, 0))

		self.scanning = False
		self.scan_threads = []
		self.valid_ips = []
		self.scanned_count = 0
		self.total_ips = 0
		self.start_time = 0
		self.ip_queue = queue.Queue()
		self.lock = threading.Lock()
		self.last_log_time = 0
		self.progress_update_id = None
		self.location_var.set("")

		self.root.protocol("WM_DELETE_WINDOW", self.on_close)
		self._check_title_integrity()

	def _decode_title(self, encoded):
		try:
			return base64.b64decode(encoded).decode('utf-8')
		except Exception:
			return "小凯IP段扫描工具"

	def _check_title_integrity(self):
		if self.root.title() != self._original_title:
			messagebox.showerror("错误", "程序标题被非法修改，即将退出！")
			self.root.destroy()
			return
		self._title_check_id = self.root.after(1000, self._check_title_integrity)

	def on_close(self):
		if hasattr(self, '_title_check_id'):
			self.root.after_cancel(self._title_check_id)
		self.root.destroy()

	def set_dark_theme(self):
		self.root.configure(background="#2d2d2d")
		style = ttk.Style()
		style.configure(".", background="#2d2d2d", foreground="white")
		style.configure("TFrame", background="#2d2d2d")
		style.configure("TLabel", background="#2d2d2d", foreground="white")
		style.configure("Horizontal.TProgressbar",
						background="#4fc3f7",
						troughcolor="#3e3e3e")

	def add_log(self, message):
		self.log_area.config(state=tk.NORMAL)
		timestamp = dt.now().strftime("%H:%M:%S")  # 修复：使用 dt.now()
		self.log_area.insert(tk.END, f"[{timestamp}] {message}\n", "log")
		self.log_area.config(state=tk.DISABLED)
		self.log_area.see(tk.END)

	def update_progress(self):
		if self.scanned_count >= self.total_ips and self.total_ips > 0:
			return

		elapsed = time.time() - self.start_time
		self.progress_var.set(f"{self.scanned_count}/{self.total_ips}")

		if self.total_ips > 0:
			percent = (self.scanned_count / self.total_ips) * 100
			self.progress["value"] = percent

			if self.scanned_count < self.total_ips:
				remaining = self.total_ips - self.scanned_count
				ips_per_sec = self.scanned_count / elapsed if elapsed > 0 else 0
				if ips_per_sec > 0:
					time_remaining = remaining / ips_per_sec
					self.progress_label.config(text=f"扫描中: {percent:.1f}% | 速度: {ips_per_sec:.1f} IP/s | 剩余时间: {time_remaining:.1f}s")
				else:
					self.progress_label.config(text=f"扫描中: {percent:.1f}%")
			else:
				self.progress_label.config(text=f"扫描完成! 耗时: {elapsed:.1f}秒 | 找到 {len(self.valid_ips)} 个有效IP")

			current_time = time.time()
			if current_time - self.last_log_time > 1.0:
				progress_msg = f"扫描进度: {self.scanned_count}/{self.total_ips} ({percent:.1f}%), 有效IP: {len(self.valid_ips)}个"
				self.add_log(progress_msg)
				self.last_log_time = current_time

	def parse_range(self, range_str, default_start, default_end):
		if not range_str.strip():
			return default_start, default_end

		try:
			if '-' in range_str:
				parts = range_str.split('-')
				if len(parts) != 2:
					raise ValueError("格式错误")
				start = int(parts[0].strip())
				end = int(parts[1].strip())
			else:
				start = end = int(range_str.strip())

			if not (1 <= start <= 255) or not (1 <= end <= 255) or start > end:
				raise ValueError("范围必须在1-255之间，且起始值不能大于结束值")

			return start, end
		except ValueError as e:
			messagebox.showwarning("输入警告",
								   f"无效的范围格式: {range_str}\n将使用默认值: {default_start}-{default_end}\n错误: {str(e)}")
			return default_start, default_end

	def translate_isp(self, isp):
		isp = isp.lower()
		if "mobile" in isp:
			return "移动"
		elif "unicom" in isp or "cnc" in isp or "169" in isp:
			return "联通"
		elif "telecom" in isp or "chinanet" in isp:
			return "电信"
		elif "broad" in isp or "cable" in isp:
			return "广电"
		elif "rail" in isp or "railway" in isp:
			return "铁通"
		elif "tietong" in isp:
			return "铁通"
		elif "cernet" in isp:
			return "教育网"
		else:
			return isp

	def get_ip_location(self, ip):
		IP_API = "http://ip-api.com/json/{ip}?fields=status,country,regionName,city,isp,as&lang=zh-CN"
		try:
			response = requests.get(IP_API.format(ip=ip), timeout=3)
			data = response.json()
			if data.get('status') == 'success':
				region = data.get('regionName', '').replace("省", "").replace("市", "").strip()
				city = data.get('city', '').replace("市", "").strip()
				isp = data.get('isp', '').strip()
				chinese_isp = self.translate_isp(isp)
				return region, city, chinese_isp
			return "未知", "未知", "未知"
		except Exception:
			return "未知", "未知", "未知"

	def start_scan(self):
		input_str = self.ip_entry.get().strip()
		if not input_str:
			CustomMessageBox(self.root, "输入错误", "请输入IP地址和端口")
			return

		try:
			ip_part, port_part = input_str.split(":")
			port = int(port_part)
			base_ip = ".".join(ip_part.split(".")[:2])
		except Exception as e:
			CustomMessageBox(self.root, "输入错误", f"无效的输入格式: {e}\n请使用格式: 192.168.1.1:80")
			return

		if port < 1 or port > 65535:
			CustomMessageBox(self.root, "输入错误", "端口号必须在1-65535之间")
			return

		try:
			c_start, c_end = self.parse_range(self.c_entry.get(), 1, 255)
			d_start, d_end = self.parse_range(self.d_entry.get(), 1, 255)

			thread_count_str = self.thread_entry.get().strip()
			thread_count = int(thread_count_str) if thread_count_str else 100

			if not (1 <= thread_count <= 500):
				CustomMessageBox(self.root, "输入错误", "线程数必须在1-500之间")
				return
		except ValueError as e:
			CustomMessageBox(self.root, "输入错误", f"配置参数错误: {e}")
			return

		self.valid_ips = []
		self.scanned_count = 0
		self.total_ips = (c_end - c_start + 1) * (d_end - d_start + 1)
		self.start_time = time.time()
		self.scanning = True
		self.last_log_time = time.time()

		self.log_area.config(state=tk.NORMAL)
		self.log_area.delete(1.0, tk.END)
		self.log_area.config(state=tk.DISABLED)

		self.add_log(f"开始扫描: {base_ip}.*.*:{port}")
		self.add_log(f"扫描范围: C段({c_start}-{c_end}) D段({d_start}-{d_end})")
		self.add_log(f"线程数: {thread_count}")
		self.add_log(f"总IP数: {self.total_ips}")
		self.add_log("扫描中...")

		self.start_button.config(state=tk.DISABLED)
		self.stop_button.config(state=tk.NORMAL)
		self.save_button.config(state=tk.NORMAL)
		self.progress["value"] = 0

		def query_location():
			try:
				ip_to_query = self.ip_entry.get().split(":")[0].strip()
				region, city, isp = self.get_ip_location(ip_to_query)
				location_info = f"{region}{city}{isp}"
				self.location_var.set(f"您查询的IP归属地是: {location_info}")
			except Exception:
				self.location_var.set("查询归属地失败")

		threading.Thread(target=query_location, daemon=True).start()

		for c in range(c_start, c_end + 1):
			for d in range(d_start, d_end + 1):
				ip = f"{base_ip}.{c}.{d}"
				self.ip_queue.put((ip, port))

		self.scan_threads = []
		for i in range(thread_count):
			thread = threading.Thread(target=self.scan_worker, daemon=True)
			thread.start()
			self.scan_threads.append(thread)

		self.update_progress_task()

	def scan_worker(self):
		while self.scanning:
			try:
				ip, port = self.ip_queue.get(timeout=0.5)
			except queue.Empty:
				if self.scanning and self.scanned_count < self.total_ips:
					continue
				else:
					break

			try:
				sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
				sock.settimeout(0.5)
				result = sock.connect_ex((ip, port))
				if result == 0:
					with self.lock:
						self.valid_ips.append(ip)
				sock.close()
			except Exception:
				pass

			with self.lock:
				self.scanned_count += 1

		if self.scanned_count >= self.total_ips:
			self.root.after(100, self.scan_complete)

	def scan_complete(self):
		if not self.scanning:
			return

		self.scanning = False
		elapsed = time.time() - self.start_time
		self.add_log(f"扫描完成! 耗时: {elapsed:.1f}秒")
		self.add_log(f"找到 {len(self.valid_ips)} 个有效IP")

		self.start_button.config(state=tk.NORMAL)
		self.stop_button.config(state=tk.DISABLED)

		self.progress_label.config(text=f"扫描完成! 耗时: {elapsed:.1f}秒 | 找到 {len(self.valid_ips)} 个有效IP")
		self.progress["value"] = 100
		self.progress_var.set(f"{self.total_ips}/{self.total_ips}")

	def stop_scan(self):
		self.scanning = False
		self.add_log("扫描已停止")
		self.stop_button.config(state=tk.DISABLED)
		self.start_button.config(state=tk.NORMAL)

		if self.progress_update_id:
			self.root.after_cancel(self.progress_update_id)
			self.progress_update_id = None

	def save_results(self):
		if not self.valid_ips:
			messagebox.showwarning("无结果", "没有找到有效IP，无法保存", parent=self.root)
			return

		current_dir = os.getcwd()
		file_path = os.path.join(current_dir, "有效ip.txt")

		try:
			with open(file_path, "w", encoding="utf-8") as f:
				f.write("\n".join(self.valid_ips))
			self.add_log(f"结果已保存到: {file_path}")
			messagebox.showinfo("保存成功",
								f"已保存 {len(self.valid_ips)} 个有效IP到:\n{file_path}",
								parent=self.root)
		except Exception as e:
			self.add_log(f"保存失败: {e}")
			messagebox.showerror("保存失败",
								 f"无法保存文件: {e}",
								 parent=self.root)

	def update_progress_task(self):
		if self.scanning:
			self.update_progress()
			self.progress_update_id = self.root.after(200, self.update_progress_task)
		else:
			self.progress_update_id = None

def main():
	root = tk.Tk()
	app = IPScannerApp(root)
	root.mainloop()

if __name__ == "__main__":
	main()