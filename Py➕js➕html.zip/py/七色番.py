/* @header({ searchable: 1, filterable: 1, quickSearch: 1, title: '七色番', '类型': '影视', lang: 'zh' }) */
var DOMAINS = [
    'https://www.7sefun.top',
    'https://www.7sefun.xyz'
];
var HOST = DOMAINS[0];
var UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 15_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Mobile/15E148 Safari/604.1';
var HEADERS = {
    'User-Agent': UA,
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'zh-CN,zh;q=0.9'
};

// ============ 一级分类（drpy2 标准 class_name/class_url） ============
var CATS = [
    { id: '1', name: 'TV番剧' },
    { id: '2', name: '剧场电影' },
    { id: '4', name: '特摄剧' },
    { id: '5', name: '国漫' },
    { id: '6', name: '美番' }
];

// ============ 二级分类（filter 筛选：剧情/地区/语言/年份/字母/排序） ============
var CAT_FILTERS = (function () {
    var years = [];
    for (var y = 2025; y >= 1980; y--) years.push(String(y));
    // 站点为 0~9（URL 中 ~ 编码为 %7E），不能用 0-9
    var letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('').concat(['0~9']);
    var sort = [
        { n: '时间排序', v: 'time' },
        { n: '人气排序', v: 'hits' },
        { n: '评分排序', v: 'score' }
    ];
    function values(names) {
        var out = [{ n: '全部', v: '' }];
        for (var i = 0; i < names.length; i++) out.push({ n: names[i], v: names[i] });
        return out;
    }
    var areaLang = [
        { key: 'area', name: '地区', value: values(['日本']) },
        { key: 'lang', name: '语言', value: values(['日语', '国语']) },
        { key: 'year', name: '年份', value: values(years) },
        { key: 'letter', name: '字母', value: values(letters) },
        { key: 'by', name: '排序', value: sort }
    ];
    var letterSort = [
        { key: 'letter', name: '字母', value: values(letters) },
        { key: 'by', name: '排序', value: sort }
    ];
    var animeClasses = values([
        '异世界', '百合', '后宫', '热血', '穿越', '奇幻', '战斗', '搞笑', '日常',
        '科幻', '治愈', '校园', '恋爱', '冒险', '推理', '机战', '音乐', '恐怖',
        '惊悚', '泡面番', '游戏改', '小说改', '漫画改', 'Netflix',
        '2025年01月', '2025年04月', '2025年07月'
    ]);
    var movieClasses = values([
        '异世界', '百合', '热血', '穿越', '奇幻', '战斗', '搞笑', '日常', '科幻',
        '治愈', '校园', '恋爱', '冒险', '机战', '音乐'
    ]);
    var tokusatsuClasses = values(['假面骑士', '奥特曼', '超级战队', '剧场版']);
    return {
        '1': [{ key: 'class', name: '剧情', value: animeClasses }].concat(areaLang),
        '2': [{ key: 'class', name: '剧情', value: movieClasses }].concat(areaLang),
        '4': [{ key: 'class', name: '剧情', value: tokusatsuClasses }].concat(areaLang),
        // 国漫 / 美番 站点仅有字母 + 排序筛选
        '5': letterSort,
        '6': letterSort
    };
})();

// ============ 通用工具 ============
var _domainIdx = 0;

function _host() {
    return DOMAINS[_domainIdx % DOMAINS.length];
}

function _abs(u) {
    var value = String(u || '').trim();
    if (!value) return '';
    if (u.indexOf('//') === 0) return 'https:' + value;
    if (/^(http|https):\/\//i.test(value)) return value;
    return _host() + (value.charAt(0) === '/' ? value : '/' + value);
}

async function _get(url, timeout) {
    var path = String(url || '').replace(/^https?:\/\/[^\/]+/i, '');
    var lastErr = null;
    for (var depth = 0; depth < DOMAINS.length * 2; depth++) {
        try {
            var rsp = await request(_host() + path, { headers: HEADERS, timeout: timeout || 12000 });
            if (!rsp) throw new Error('empty');
            var text = typeof rsp === 'string' ? rsp : (rsp.content || rsp.body || rsp.text || '');
            if (text) return text;
            throw new Error('empty');
        } catch (e) { lastErr = e; }
        _domainIdx++; // 失败自动切换备用域名重试
    }
    console.log('[七色番] 请求失败: ' + url + ' -> ' + lastErr);
    return '';
}

function _clean(value) {
    return String(value === undefined || value === null ? '' : value)
        .replace(/<[^>]*>/g, '')
        .replace(/\s+/g, ' ')
        .trim();
}

function _normalizeItem(title, pic, remarks, url) {
    if (!title) return null;
    return {
        title: title,
        pic_url: pic,
        desc: remarks || '',
        url: url || title
    };
}

// 站点播放地址 AES 解密（CBC/Pkcs7）
function _decryptPlay(cipherText, uid, Crypto) {
    var key = Crypto.enc.Utf8.parse('2890' + uid + 'tB959C');
    var iv = Crypto.enc.Utf8.parse('2F131BE91247866E');
    return Crypto.AES.decrypt(cipherText, key, {
        iv: iv,
        mode: Crypto.mode.CBC,
        padding: Crypto.pad.Pkcs7
    }).toString(Crypto.enc.Utf8);
}

// ============ 分类列表（一级 + filter 二级筛选） ============
// ---- 正则提取（不依赖解析器，任何 JS 环境可用） ----
function _regexModuleItems(html) {
    var items = [];
    var parts = html.split('class="module-item"');
    for (var i = 1; i < parts.length; i++) {
        var seg = parts[i];
        var am = seg.match(/<a[^>]+href="([^"]+)"[^>]*title="([^"]*)"/);
        var title = am ? am[2] : '';
        var href = am ? am[1] : '';
        if (!title) {
            var im = seg.match(/<img[^>]+alt="([^"]*)"/);
            title = im ? im[1] : '';
        }
        if (!href) {
            var hm = seg.match(/<a[^>]+href="([^"]+)"/);
            href = hm ? hm[1] : '';
        }
        if (!title || !href) continue;
        var pm = seg.match(/data-src="([^"]+)"/) || seg.match(/src="([^"]+\.(?:jpg|jpeg|png|webp))"/);
        var dm = seg.match(/<div class="module-item-text">([\s\S]*?)<\/div>/);
        items.push({
            title: _clean(title),
            pic_url: pm ? _abs(pm[1]) : '',
            desc: dm ? _clean(dm[1]) : '',
            url: _abs(href)
        });
    }
    return items;
}

function _regexModuleSearch(html) {
    var items = [];
    var parts = html.split('class="module-search-item"');
    for (var i = 1; i < parts.length; i++) {
        var seg = parts[i];
        var im = seg.match(/<img[^>]+alt="([^"]*)"/);
        var title = im ? im[1] : '';
        var hm = seg.match(/<a[^>]+href="([^"]+)"/);
        var href = hm ? hm[1] : '';
        if (!title || !href) continue;
        var pm = seg.match(/data-src="([^"]+)"/) || seg.match(/src="([^"]+\.(?:jpg|jpeg|png|webp))"/);
        var dm = seg.match(/<div class="module-item-note">([\s\S]*?)<\/div>/);
        var cm = seg.match(/<div class="module-info-item-content">([\s\S]*?)<\/div>/);
        items.push({
            title: _clean(title),
            pic_url: pm ? _abs(pm[1]) : '',
            desc: dm ? _clean(dm[1]) : '',
            content: cm ? _clean(cm[1]) : '',
            url: _abs(href)
        });
    }
    return items;
}

function _regexVideoItems(html) {
    var items = [];
    var parts = html.split('class="video');
    for (var i = 1; i < parts.length; i++) {
        var seg = parts[i];
        var hm = seg.match(/<a[^>]+href="([^"]+)"/);
        var href = hm ? hm[1] : '';
        if (!href) continue;
        var srcM = seg.match(/<img[^>]+src="([^"]+)"/);
        var altM = seg.match(/<img[^>]+alt="([^"]+)"/);
        var title = altM ? altM[1] : '';
        var pic = srcM ? srcM[1] : '';
        if (!title) {
            var nm = seg.match(/<div class="video-name">([\s\S]*?)<\/div>/);
            title = nm ? _clean(nm[1]) : '';
        }
        if (!title) {
            var nb = seg.match(/<div class="video-by">([\s\S]*?)<\/div>/);
            title = nb ? _clean(nb[1]) : '';
        }
        if (!title) continue;
        var dt = seg.match(/<div class="video-time">([\s\S]*?)<\/div>/);
        items.push({
            title: _clean(title),
            pic_url: pic ? _abs(pic) : '',
            desc: dt ? _clean(dt[1]) : '',
            url: _abs(href)
        });
    }
    return items;
}

// 站点移动端(mxone)模板：列表项 .module-item；PC 端兜底 .video
function _mapList(html) {
    if (!html) return [];
    var items = [];
    // 通道1：drpy2 标准解析
    try {
        var nodes = pdfa(html, '.module-item') || [];
        for (var i = 0; i < nodes.length; i++) {
            var item = nodes[i];
            var title = _clean(pdfa(item, 'a&&title')) || _clean(pdfa(item, 'img&&alt'));
            var href = pd(item, 'a&&href', _host());
            if (!title || !href) continue;
            items.push({
                title: title,
                pic_url: pd(item, 'img&&data-src', _host()),
                desc: _clean(pdfh(item, '.module-item-text&&Text')),
                url: href
            });
        }
    } catch (e) { }
    if (items.length) return items;
    // 通道2：正则解析（不依赖环境解析器）
    items = _regexModuleItems(html);
    if (items.length) return items;
    return _regexVideoItems(html);
}

// 构造 /vodshow/ 筛选 URL（tid-地区-排序-类型-语言-字母-…-年份）
function _buildShowPath(tid, ext, page) {
    var slots = ['', '', '', '', '', '', '', '', '', '', '', ''];
    slots[0] = String(tid || '1');
    slots[1] = ext.area ? encodeURIComponent(String(ext.area)) : '';
    slots[2] = String(ext.by || 'time');
    slots[3] = ext.class ? encodeURIComponent(String(ext.class)) : '';
    slots[4] = ext.lang ? encodeURIComponent(String(ext.lang)) : '';
    // 字母在第6段（下标5），如 /vodshow/1-----A------.html；站点 0~9 中 ~ 编码为 %7E
    slots[5] = ext.letter ? encodeURIComponent(String(ext.letter)).replace(/~/g, '%7E') : '';
    slots[11] = ext.year ? encodeURIComponent(String(ext.year)) : '';
    return '/vodshow/' + slots.join('-') + '.html?page=' + (Number(page || 1) || 1);
}

async function _getCategoryList(tid, pg, filter, extend) {
    var page = Number(pg || 1) || 1;
    var typeId = String(tid || '1').trim() || '1';
    var rawExt = extend || filter || {};
    var ext = {
        area: rawExt.area || '',
        by: rawExt.by || rawExt.order_by || 'time',
        class: rawExt.class || rawExt.cateId || '',
        lang: rawExt.lang || '',
        letter: rawExt.letter || '',
        year: rawExt.year || ''
    };
    var path = _buildShowPath(typeId, ext, page);
    var html = await _get(_host() + path);
    return _mapList(html);
}

// ============ 详情页解析 ============
function _infoValue(html, label) {
    var groups = pdfa(html, '.video-info-items');
    for (var i = 0; i < groups.length; i++) {
        var head = _clean(pdfh(groups[i], '.video-info-itemtitle&&Text'));
        if (head.indexOf(label) >= 0) {
            return _clean(pdfh(groups[i], '.video-info-item&&Text'));
        }
    }
    return '';
}

async function _getDetail(id) {
    var detailUrl = /^https?:\/\//i.test(id) ? id : _host() + id;
    var html = await _get(detailUrl);

    var typeNodes = pdfa(html, '.video-info-aux a');
    var typeName = typeNodes.length ? _clean(pdfh(typeNodes[0], 'body&&Text')) : '';
    var year = '';
    var area = '';
    typeNodes.forEach(function (node) {
        var text = _clean(pdfh(node, 'Text'));
        var href = String(pdfh(node, 'a&&href') || '');
        if (/^\d{4}$/.test(text)) year = text;
        if (/\/vodshow\/\d+-[^-]/.test(href)) area = text;
    });

    var tabNodes = pdfa(html, '.module-tab-item');
    var listNodes = pdfa(html, '.sort-item');
    var tabs = [];
    var groups = [];

    tabNodes.forEach(function (node) {
        var name = _clean(pdfh(node, 'span&&Text')) || _clean(pdfh(node, 'Text')).replace(/\d+$/, '');
        tabs.push(name.replace(/[#$]/g, ' ') || '线路' + (tabs.length + 1));
    });

    listNodes.forEach(function (listNode, lineIndex) {
        var episodes = [];
        var seen = {};
        pdfa(listNode, 'a').forEach(function (episodeNode) {
            var href = pd(episodeNode, 'a&&href', _host());
            if (!href || seen[href]) return;
            seen[href] = true;
            var name = _clean(pdfh(episodeNode, 'a&&Text'))
                .replace(/^第/, '')
                .replace(/集$|期$/, '')
                .replace(/[#$]/g, ' ') || ('第' + (episodes.length + 1) + '集');
            episodes.push(name + '$' + href);
        });
        if (episodes.length) {
            groups.push(episodes.join('#'));
            if (!tabs[lineIndex]) tabs[lineIndex] = '线路' + (lineIndex + 1);
        }
    });

    if (tabs.length > groups.length) tabs.length = groups.length;
    while (groups.length < tabs.length) groups.push('');

    return {
        vod_id: id,
        vod_name: _clean(pdfh(html, '.page-title&&Text')),
        vod_pic: pd(html, '.lazyload&&data-src', _host()),
        type_name: typeName,
        vod_remarks: _infoValue(html, '备注'),
        vod_year: year,
        vod_area: area,
        vod_actor: _infoValue(html, '主演'),
        vod_director: _infoValue(html, '导演'),
        vod_content: _infoValue(html, '剧情'),
        vod_play_from: tabs.join('$$$'),
        vod_play_url: groups.join('$$$')
    };
}

// ============ 搜索 ============
async function _searchPage(kw, pg) {
    var keyword = String(kw || '').trim();
    if (!keyword) return [];
    var page = Number(pg || 1) || 1;
    var url = _host() + '/vodsearch/' + encodeURIComponent(keyword) + '----------' + page + '---.html';
    var html = await _get(url);
    var items = [];
    // 通道1：drpy2 标准解析
    try {
        var nodes = pdfa(html, '.module-search-item') || [];
        for (var i = 0; i < nodes.length; i++) {
            var item = nodes[i];
            var title = _clean(pdfa(item, 'img&&alt'));
            var href = pd(item, '.video-info-header a&&href', _host());
            if (!title || !href) continue;
            items.push({
                title: title,
                pic_url: pd(item, '.lazy&&data-src', _host()),
                desc: _clean(pdfh(item, '.module-item-note&&Text')),
                content: _clean(pdfh(item, '.module-info-item-content&&Text')),
                url: href
            });
        }
    } catch (e) { }
    if (items.length) return items;
    // 通道2：正则提取解析（不依赖环境解析器）
    items = _regexModuleSearch(html);
    if (items.length) return items;
    return _regexVideoItems(html);
}

// ============ 线路播放（播放页解密 → ndx/ec 解析 → 直链） ============
async function _parsePlay(flag, id) {
    var pageUrl = /^https?:\/\//i.test(id) ? id : _host() + id;
    var html = await _get(pageUrl);
    var match = html.match(/r player_[\s\S]*?=(.*?)</);
    if (!match) throw new Error('七色番未找到播放数据');
    var player = JSON.parse(match[1]);
    var playUrl = String(player.url || '');
    if (String(player.encrypt) === '1') {
        playUrl = unescape(playUrl);
    } else if (String(player.encrypt) === '2') {
        playUrl = unescape(base64Decode(playUrl));
    }

    var configHtml = await _get(_host() + '/static/player/' + player.from + '.js');
    var srcMatch = configHtml.match(/src="(.*?)'/);
    if (!srcMatch) throw new Error('七色番未找到播放器配置');
    var api = srcMatch[1].indexOf('http') === 0 ? srcMatch[1] : _host() + srcMatch[1];

    if (String(player.from) === 'ndx') {
        var target = (api + player.id + '&from=' + player.from + '&url=' + playUrl).replace('index', 'dp');
        var response = await request(target, {
            headers: { 'User-Agent': UA, Referer: api }
        });
        var direct = String(response.match(/"url": "(.*?)"/)[1] || '').trim();
        if (!/^https?:\/\//i.test(direct)) throw new Error('ndx 播放地址解析失败');
        return { parse: 0, url: direct, header: { 'User-Agent': UA } };
    }

    var target = api.replace('index.php', 'ec.php') + playUrl;
    var response;
    try {
        response = await request(target, {
            headers: { 'User-Agent': UA, Referer: _host() + '/' }
        });
    } catch (e) {
        var reason = [e && e.message, e && e.cause && e.cause.message, String(e)].join(' ');
        if (!/cert|ssl|tls/i.test(reason)) throw e;
        target = target.replace(/^https:/i, 'http:');
        response = await request(target, {
            headers: { 'User-Agent': UA, Referer: _host() + '/' }
        });
    }

    var start = response.indexOf('{', response.indexOf('let ConFig'));
    var end = response.lastIndexOf('}');
    if (start < 0 || end <= start) throw new Error('七色番播放配置解析失败');
    var config = JSON.parse(response.slice(start, end + 1));
    if (!config.url || !config.config || !config.config.uid) throw new Error('七色番播放配置不完整');

    var Crypto = typeof CryptoJS !== 'undefined' ? CryptoJS : getCryptoJS();
    if (!Crypto) throw new Error('CryptoJS unavailable');
    var direct = _decryptPlay(config.url, config.config.uid, Crypto);
    if (!/^https?:\/\//i.test(direct)) throw new Error('七色番播放地址解密失败');
    return {
        parse: 0,
        url: direct,
        header: { 'User-Agent': UA, Referer: _host() + '/' }
    };
}

// ============ drpy2 rule ============
var rule = {
    类型: '影视',
    title: '七色番',
    host: HOST,
    homeUrl: '/vodshow/1--------1---.html',
    headers: HEADERS,
    searchable: 1,
    filterable: 1,
    quickSearch: 1,
    timeout: 15000,
    play_parse: true,
    play_json: [],
    class_name: CATS.map(function (c) { return c.name; }).join('&'),
    class_url: CATS.map(function (c) { return c.id; }).join('&'),
    filter: CAT_FILTERS,

    推荐: '*',

    一级: async function (tid, pg, filter, extend) {
        var list = [];
        try {
            list = await _getCategoryList(tid, pg, filter, extend);
        } catch (e) {
            console.log('[七色番] 一级失败: ' + e);
        }
        console.log('[七色番] 一级 tid=' + tid + ' 解析 ' + list.length + ' 条');
        return setResult(list);
    },

    二级: async function (ids) {
        var id = String((Array.isArray(ids) ? ids[0] : ids) || '').trim();
        if (!id) return {};
        var detail = await _getDetail(id);
        if (!detail) {
            return { vod_id: id, vod_name: '未知影片', vod_content: '获取失败或影片不存在' };
        }
        return detail;
    },

    搜索: async function (wd, quick, pg) {
        var keyword = String(wd || '').trim();
        if (!keyword) return setResult([]);
        var list = [];
        try {
            list = await _searchPage(keyword, pg);
        } catch (e) {
            console.log('[七色番] 搜索失败: ' + e);
        }
        console.log('[七色番] 搜索 "' + keyword + '" ' + list.length + ' 条');
        return setResult(list);
    },

    lazy: async function (flag, id) {
        var url = String(id || '').trim();
        if (!url) return { parse: 0, url: '', header: HEADERS };
        try {
            return await _parsePlay(flag, url);
        } catch (e) {
            console.log('[七色番] lazy 解析失败: ' + e);
            throw e;
        }
    }
};
