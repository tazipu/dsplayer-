import json
import re
import uuid
from urllib.parse import urlsplit, urljoin

from base.spider import Spider as BaseSpider


HOST = "https://www.youtube.com"
# YouTube 网页端内置公开 API Key（与官网 JS 共用，无需申请）。
YOUTUBEI_KEY = "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
PLAYER_URL = "https://www.youtube.com/youtubei/v1/player?key=" + YOUTUBEI_KEY
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
)
REQUEST_TIMEOUT = 15
PLAY_CACHE_SECONDS = 300  # HLS 地址数小时有效，缓存 5 分钟避免每次选台都请求
PLAYER_HEADERS = {"User-Agent": USER_AGENT, "Referer": HOST + "/", "Origin": HOST}
# ANDROID 客户端无需 JS 签名即可拿到直播 HLS 地址（WEB 客户端会被风控拦截）。
ANDROID_CONTEXT = {
    "clientName": "ANDROID",
    "clientVersion": "20.10.38",
    "androidSdkVersion": 34,
    "hl": "en",
    "gl": "US",
}
VIDEO_ID_RE = re.compile(r"^[A-Za-z0-9_-]{11}$")
WATCH_ID_RE = re.compile(r"watch\?v=([A-Za-z0-9_-]{11})")
CANONICAL_RE = re.compile(r'"canonical" href="https://www\.youtube\.com/watch\?v=([A-Za-z0-9_-]{11})"')
YT3 = "https://yt3.googleusercontent.com/"

# 频道清单：id 支持 @handle、UC 开头的频道 ID、11 位视频 ID、完整 watch 链接。
CHANNELS = [
    {"name": "中天新聞", "logo": YT3 + "stUf6P7kJeOrW96ZKdaHoYvg6USCR0MOe90jfOp2oTLOdPWeQDIKNm6S25wcEzJBXuVLRNmAag=s900-c-k-c0x00ffffff-no-rj", "id": "vr3XyVCR4T0"},
    {"name": "中視新聞", "logo": YT3 + "L2H1Zj71XnBJF8tr3Kpy52VhflXZYaKJC2XxeBjtGuFAcY8lZjpULhOOFI6bScWYJE56rBQ=s900-c-k-c0x00ffffff-no-rj", "id": "TCnaIE_SAtM"},
    {"name": "中視經典綜藝", "logo": YT3 + "MBI5cULrvmFMMuLBol_cTi7OpM1lsM_fslv1BvPp6nDXzYe0WfUhgRUpnsZmX2hN83QKVd99WA=s900-c-k-c0x00ffffff-no-rj", "id": "ADDSmXoPDY8"},
    {"name": "大陸尋奇", "logo": YT3 + "lgYau0BBp86eSt5vrGUKn126PryXWWEiL0oFmZpH3s6ye7773NfC0fkv40VJuOoAwD9A3UZQPEM=s900-c-k-c0x00ffffff-no-rj", "id": "ta7uI13rb_E"},
    {"name": "四季线上", "logo": YT3 + "fnmEjPKCEpjKr0qQQqGC-D3iWhxyVj9yzTnW6saueERWN6NCsmKk4lLiehwCDIenEKRkljcDcqg=s900-c-k-c0x00ffffff-no-rj", "id": "GjXBXz5dl6E"},
    {"name": "寰宇新聞", "logo": YT3 + "rcKSZ9TOod8vM90qsaF8pV6e6Mrh_INiOfhzRlLXiyvzeOYGoJrL2fWWGH0pHu-N0_rRdCLPbg=s900-c-k-c0x00ffffff-no-rj", "id": "6IquAgfvYmc"},
    {"name": "寰宇新聞台灣台", "logo": YT3 + "rcKSZ9TOod8vM90qsaF8pV6e6Mrh_INiOfhzRlLXiyvzeOYGoJrL2fWWGH0pHu-N0_rRdCLPbg=s900-c-k-c0x00ffffff-no-rj", "id": "w87VGpgd90U"},
    {"name": "寰宇財經台", "logo": YT3 + "Fj0zgas43cG4IVGzsU-XXEHRrbfr2cxmPNliOZl-zA5LEuuXrAt6LRhp2xhzqnQSI88to-zo1A=s900-c-k-c0x00ffffff-no-rj", "id": "yAUQQ0DhPxI"},
    {"name": "凤凰资讯台", "logo": YT3 + "0DVIlBXVrcph_VblCI-B0lFTXHOQ9ottOBU4I8dY57IQl600eVqiM3dTp4aaNe1Ee7RFYosd4Ls=s900-c-k-c0x00ffffff-no-rj", "id": "Ry--eMIjYLQ"},
    {"name": "CCTV4", "logo": YT3 + "ytc/AIdro_lJl5JukmttgmlUSCzwsVzGi_mwLkSXh3T58f1YT26-0qY=s900-c-k-c0x00ffffff-no-rj", "id": "vNVp6bxkL1c"},
    {"name": "TVBS", "logo": YT3 + "ytc/AIdro_k-0Eo2JQs8c-kMUqmrxsZIsJqC9jSpr-mydLFNrnKbP3Q=s900-c-k-c0x00ffffff-no-rj", "id": "o_-hSMgpAzs"},
    {"name": "TVBS NEWS", "logo": YT3 + "IrPD-qWFtgEr0kplk7RvA5HWJz3BLzg8mBMh9bz2lNvRSE_YgCErB7dheHcQohExnC_VCdCKnA=s900-c-k-c0x00ffffff-no-rj", "id": "m_dhMSvUCIc"},
    {"name": "TVBS新聞台", "logo": YT3 + "IrPD-qWFtgEr0kplk7RvA5HWJz3BLzg8mBMh9bz2lNvRSE_YgCErB7dheHcQohExnC_VCdCKnA=s900-c-k-c0x00ffffff-no-rj", "id": "2mCSYvcfhtc"},
    {"name": "華視綜藝", "logo": YT3 + "kfsFTlwOqu7N_B_Y2-mFXstSEyOk302pyHP2KHU714u65oWS7rWFR4pZDRsP434K-vQ2Zmg_=s900-c-k-c0x00ffffff-no-rj", "id": "0ePhPlTJbGo"},
    {"name": "華視新聞", "logo": YT3 + "bNiPVeUS2UrnSYACw9l-MmxLPus732f22CycYL5El6Z5pgH865m0jEfqcxNNFsXEKPPt0wWc=s900-c-k-c0x00ffffff-no-rj", "id": "wM0g8EoUZ_E"},
    {"name": "东森综合", "logo": YT3 + "l3F4IEMzxNCs_4x_9CakIuizfhnmOFj-FPJvjvZIY_vVmTcbl0AS5qjbLsD_ASXMtwUxod4nkA=s900-c-k-c0x00ffffff-no-rj", "id": "cimbpAZUjzw"},
    {"name": "東森新聞", "logo": YT3 + "3SP20B5NfOMGNTvAd4PkffLIHt7vA5_SrtefsCbmKBm4k4uD5JhSE2LzDsPyxWT6RP3BiW4vAA=s900-c-k-c0x00ffffff-no-rj", "id": "V1p33hqPrUk"},
    {"name": "東森財經新聞", "logo": YT3 + "ytc/AIdro_kxT0OP6l7H5dzJ54X4mgRpJUvl7miRrph58-ffpLJRIg=s900-c-k-c0x00ffffff-no-rj", "id": "1I2iq41Akmo"},
    {"name": "東森財經股市", "logo": YT3 + "ytc/AIdro_kxT0OP6l7H5dzJ54X4mgRpJUvl7miRrph58-ffpLJRIg=s900-c-k-c0x00ffffff-no-rj", "id": "AEBeWMM1atA"},
    {"name": "東森LIVE", "logo": YT3 + "3SP20B5NfOMGNTvAd4PkffLIHt7vA5_SrtefsCbmKBm4k4uD5JhSE2LzDsPyxWT6RP3BiW4vAA=s900-c-k-c0x00ffffff-no-rj", "id": "E0zhe2gkXBs"},
    {"name": "民視新聞", "logo": YT3 + "eq9GJ0t1CmnqrVFqohCpAQYtW6pzTwtg4ATiPJbjOtKGlHrcQ8FmY7b5taNl0crRQXs3GnOl=s900-c-k-c0x00ffffff-no-rj", "id": "ylYJSBUgaMA"},
    {"name": "三立LIVE", "logo": YT3 + "SDjcZE8Xo2dsS5OF3_LA8hkZrzXqr1L37S4JlgbJ9B7Be77fViYJmDY7mr76hkpvw6PEdIEd9Q=s900-c-k-c0x00ffffff-no-rj", "id": "hGJkDZDchYI"},
    {"name": "三立新聞", "logo": YT3 + "SDjcZE8Xo2dsS5OF3_LA8hkZrzXqr1L37S4JlgbJ9B7Be77fViYJmDY7mr76hkpvw6PEdIEd9Q=s900-c-k-c0x00ffffff-no-rj", "id": "yeYC0mbSIOo"},
    {"name": "三立財經", "logo": "https://yt3.ggpht.com/gUb2DwHKe4ejBHK1YQJ8ZUOcOUCSHYobbrpGtTTvlLhBL38CBV089YcYJCyjQvUJTMb2svrLe6Q=s176-c-k-c0x00ffffff-no-rj", "id": "pF507BLtbqU"},
    {"name": "非凡商業", "logo": YT3 + "8u-Sf1fw54VH96huvO6WBkFWvwWwoiZTtJA0qkUCycqsIIoFwi0zI2Z8sjlVG6qkp6YlmUm7CA=s900-c-k-c0x00ffffff-no-rj", "id": "eA6Aczd3FZM"},
    {"name": "公視", "logo": YT3 + "ytc/AIdro_ms3o2HJnVOnEZSceyQygn7y_lsRZn1S91CJIUthdizIg=s900-c-k-c0x00ffffff-no-rj", "id": "quwqlazU-c8"},
    {"name": "臺視新聞", "logo": YT3 + "7PGt2KNBgi9Yj0EATq91tUIHl-xGBJX7mUOkt-iMTMjOuzwMBZjxhTj-YIxru3syWqyuZM3FrQ=s900-c-k-c0x00ffffff-no-rj", "id": "9iRAqBMakXY"},
    {"name": "鏡新聞", "logo": YT3 + "uE_YE2L5yKQ1pdEA-OjRBUAmIMtKzKujgNjh5nkHbRXdStjAyR1tl7xbeKuz9XIAcJf4roSG=s900-c-k-c0x00ffffff-no-rj", "id": "5n0y6b0Q25o"},
    {"name": "全球財經台", "logo": "", "id": "ai_SsuBkXLM"},
    {"name": "信大", "logo": YT3 + "k7S29cYzy1gEjvrwf_kUTGsrYAGxWzkQV7mD9lrS8ZOvVOTD2Kte6aN6EnL5ATKPTH-SMNTW=s900-c-k-c0x00ffffff-no-rj", "id": "UJeImkJpaLM"},
    {"name": "Al Jazeera", "logo": YT3 + "XsTga3Nsfc1E6ZgC6HfHfzTG_3zhuZleOnsKxSK2aILMjwkkIm-0vdALFaU-yt0Lw07iLtbSifk=s900-c-k-c0x00ffffff-no-rj", "id": "gCNeDWCI0vo"},
    {"name": "Sky News", "logo": YT3 + "dGnkztdrLtXRlzkdqReeL-NES2761xxmNVcJhGKqFpR0vQBoP9XaxnXF95FDpwrjyFr2iJvV8Es=s900-c-k-c0x00ffffff-no-rj", "id": "xDWQ3LkccY8"},
    {"name": "LiveNOW from FOX", "logo": YT3 + "AqzY5ePezRAQ2136-TbM_88d43JfIovkzztge92WKQ4K_ISfJMFA9yuX0Nw87DLWms4W9r2c3Q=s900-c-k-c0x00ffffff-no-rj", "id": "0mnGc7lFHi0"},
    {"name": "DW News", "logo": YT3 + "NSOdTQTWlqMy8O_j32dx-ftfTCHMOt04Hm7KZ4pfAK6-eQzQSZMWvvss90kG8KQfJ7iNP3phyA=s900-c-k-c0x00ffffff-no-rj", "id": "LuKwFajn37U"},
    {"name": "Euronews", "logo": YT3 + "8MyE7rxMBfLZOpYkJVJFm1C8I9jxbceBbOJS9OhrepZMVGxGV-OEJU-UdLOew_qR_l-knETWeu4=s900-c-k-c0x00ffffff-no-rj", "id": "pykpO5kQJ98"},
    {"name": "FRANCE 24", "logo": YT3 + "ytc/AIdro_n_QTJ5-GLGnftQFkb7Kp36W2eBH3H-7ZqTQxzFkkqGrIE=s900-c-k-c0x00ffffff-no-rj", "id": "HvZt-nh9sGg"},
    {"name": "NBC News", "logo": YT3 + "PJj5jtuEOi5UmkFy4IBonj5WcabNcnJAIJe-jZMd1ArwIuVyQxFH_2zryBHwvfv6mJujwRpWDCM=s900-c-k-c0x00ffffff-no-rj", "id": "ZcK5-K-i5S4"},
    {"name": "CNA LIVE", "logo": YT3 + "ytc/AIdro_n00DzE39o-4IFJ07IP3gG__TMqKxXXbwYaARinwTXTDFM=s900-c-k-c0x00ffffff-no-rj", "id": "XWq5kBlakcQ"},
    {"name": "THE K-POP", "logo": YT3 + "ak7rvwiEaaJDbiau5F_o_oV6wHqAUZwORy_-ALQyI2IEJjo_m9IAxAecX7Og1UY93TiVxs9Zgw=s900-c-k-c0x00ffffff-no-rj", "id": "JVocS7Yftw8"},
    {"name": "Animal Plant", "logo": "", "id": "iG_-FTvPiLs"},
    {"name": "Nat Geo", "logo": YT3 + "i9rVmcq-AiZ1yHc7fdn3Yd34JXmCG6ZFwBXkQwxwUXFykvatrR58C9VZLHStf9ud8FlGFyxMloA=s900-c-k-c0x00ffffff-no-rj", "id": "hPsGFrzhvdc"},
    {"name": "Nat Geo Wild", "logo": YT3 + "-Qnrya3t3zOFYecI-Dkb7vI-xFo1WaPUCDFgsnpo1ZV4nAegQdUsbMFKXM5HQCEgFPiFqoJa=s900-c-k-c0x00ffffff-no-rj", "id": "MiQe9ob9aDc"},
    {"name": "Nat Geo Kids", "logo": YT3 + "GsBWcfJJbCKMQ-ndyaeLPqIwfqvU2dughQEl0eGRP8MfvML-HIl5HK_vamdjOWzbvMSLdLINGA=s900-c-k-c0x00ffffff-no-rj", "id": "q5xC6wv9Ut0"},
    {"name": "BBC Earth", "logo": YT3 + "4aOOdq9yagLxasYPhdG7qQEVP-nrcmqoFD74N-dxw9ctOxXZtuSTTZKGzNsx-Nn0OqzVGnPZUA=s900-c-k-c0x00ffffff-no-rj", "id": "yMMTtY_L-y0"},
    {"name": "Love Nature", "logo": YT3 + "rvwRw4-NR4Td4LOj0tvIIv9a8kQusEF8Jihy_O05tufympeoe4Zz1rmjoUxcP_asutnBmRUe1Ko=s900-c-k-c0x00ffffff-no-rj", "id": "Zns4k_dICzs"},
    {"name": "International Space Station", "logo": "", "id": "0FBiyFpV__g"},
    {"name": "Watch Earth", "logo": YT3 + "Uw3qkgJffPHEfcLYV_H-dOJOoyaSYSJmQQAsk3_zOdLfWpN73w-aOBI6sZLteSw8vlWhA12R=s900-c-k-c0x00ffffff-no-rj", "id": "fO9e9jnhYK8"},
    {"name": "The Choice", "logo": YT3 + "j2pA1Wk7JeTXHGySQ5naJjxUGJ5E5xASZfmXfIY2VL8HIV9WUGHm_KhdOgznQnxFx5KkGyJAlQ=s900-c-k-c0x00ffffff-no-rj", "id": "WufvwWymK4c"},
    {"name": "TOM and JERRY", "logo": YT3 + "ytc/AIdro_m1DN9gzRGZFKbJ7lTrRaPntkpo8B5byefszt90NApk9qQ=s900-c-k-c0x00ffffff-no-rj", "id": "rEKifG2XUZg"},
    {"name": "Disney Jr", "logo": YT3 + "ycmH6u_8GXdVOSwL8K8D0QSLxzoJvd6yiRORWT0QYosXdtBBOkqQdXTR4DS6kDHd-U49Z3dcpHY=s900-c-k-c0x00ffffff-no-rj", "id": "OLm79RPFDaQ"},
    {"name": "Entertainment - Mediacorp", "logo": YT3 + "PsccIFmisj7e2bMFSafKULp-xokr8veejGqEruASYdGn3UF-6kShdusRQJSpGh95GN6cKWjB=s900-c-k-c0x00ffffff-no-rj", "id": "ipqTkEH3mhE"},
]


class Spider(BaseSpider):

    def init(self, extend=""):
        self.device_id = "WEB_" + str(uuid.uuid4())

    def getName(self):
        return "YouTube 直播"

    def liveContent(self, url):
        channels = []
        for index, item in enumerate(CHANNELS):
            name = str(item.get("name") or "").strip()
            cid = str(item.get("id") or "").strip()
            if not name or not cid:
                continue
            channels.append({
                "name": name,
                "tvgName": name,
                "tvgId": "yt_" + re.sub(r"\W+", "", cid),
                "number": "{:02d}".format(index + 1),
                "logo": str(item.get("logo") or ""),
                "urls": [self.getProxyUrl({"id": cid})],
                "parse": 0,
                "format": "application/x-mpegURL",
                "ua": USER_AGENT,
                "referer": HOST + "/",
                "origin": HOST,
            })
        if not channels:
            raise ValueError("YouTube 直播：频道清单为空")
        return [{"name": "YouTube 直播", "channel": channels}]

    def localProxy(self, param):
        # 中转模式：播放器只跟本机代理说话，分片全部由脚本去拉，
        # 绕开 YouTube 分片地址的 IP 绑定（解析 IP 与播放 IP 不一致会被 403）。
        if param.get("proxy"):
            return self._proxy_bytes(str(param.get("proxy")))
        cid = str(param.get("id", "") or "").strip()
        if not cid:
            return [400, "text/plain", "YouTube 直播：频道代碼錯誤"]
        try:
            return [200, "application/x-mpegURL", self._proxied_playlist(cid)]
        except (OSError, ValueError) as error:
            return [502, "text/plain", "YouTube 直播：" + str(error)]

    def destroy(self):
        pass

    def _variant_url(self, cid):
        video_id = self._video_id(cid)
        return self.net.cached("play:" + video_id, {"ttl": PLAY_CACHE_SECONDS * 1000, "stale": False},
                               lambda: self._hls_url(video_id))

    def _proxied_playlist(self, cid):
        variant_url = self._variant_url(cid)
        variant = self._get_text(variant_url)
        rendition = self._pick_rendition(variant, variant_url)
        media = self._get_text(rendition)
        return self._rewrite_playlist(media, rendition)

    @staticmethod
    def _pick_rendition(variant, base):
        best = None
        best_bw = -1
        lines = variant.splitlines()
        for i, line in enumerate(lines):
            m = re.match(r"#EXT-X-STREAM-INF:.*BANDWIDTH=(\d+)", line)
            if m and i + 1 < len(lines):
                bw = int(m.group(1))
                if bw > best_bw:
                    best_bw = bw
                    best = urljoin(base, lines[i + 1].strip())
        if not best:
            raise ValueError("未找到可用清晰度")
        return best

    def _rewrite_playlist(self, media, base):
        out = []
        for line in media.splitlines():
            s = line.strip()
            if s and not s.startswith("#"):
                out.append(self.getProxyUrl({"proxy": urljoin(base, s)}))
                continue
            m = re.search(r'URI="([^"]+)"', line)
            if m and ("EXT-X-MAP" in line or "EXT-X-KEY" in line):
                out.append(line[:m.start(1)] + self.getProxyUrl({"proxy": urljoin(base, m.group(1))}) + line[m.end(1):])
                continue
            out.append(line)
        return "\n".join(out) + "\n"

    def _proxy_bytes(self, url):
        parsed = urlsplit(url)
        if parsed.scheme != "https" or not parsed.hostname:
            return [400, "text/plain", "地址錯誤"]
        result = self.net.req(url, {
            "method": "GET", "headers": PLAYER_HEADERS,
            "timeout": REQUEST_TIMEOUT * 1000, "buffer": 1,
        })
        if result.get("error") or result.get("code") not in range(200, 300):
            return [502, "text/plain", "分片拉取失败"]
        return [200, "video/mp2t", result["content"]]

    def _video_id(self, cid):
        # 1) 直接就是 11 位视频 ID，或 watch 链接
        if VIDEO_ID_RE.match(cid):
            return cid
        m = WATCH_ID_RE.search(cid)
        if m:
            return m.group(1)
        # 2) 频道 handle / 频道 ID：取 /live 页的 canonical，正在直播时会指向 watch?v=
        if cid.startswith("@"):
            live_url = HOST + "/" + cid + "/live"
        elif cid.startswith("UC"):
            live_url = HOST + "/channel/" + cid + "/live"
        else:
            raise ValueError("频道 ID 格式錯誤：" + cid)
        html = self._get_text(live_url)
        m = CANONICAL_RE.search(html)
        if not m:
            raise ValueError("该频道当前未在直播")
        return m.group(1)

    def _hls_url(self, video_id):
        payload = json.dumps({"videoId": video_id, "context": {"client": ANDROID_CONTEXT}})
        result = self.net.req(PLAYER_URL, {
            "method": "POST",
            "headers": {**PLAYER_HEADERS, "Content-Type": "application/json"},
            "data": payload,
            "postType": "json",
            "timeout": REQUEST_TIMEOUT * 1000,
        })
        if result.get("error") or result.get("code") not in range(200, 300):
            raise ValueError("youtubei接口失败 code=" + str(result.get("code") or result.get("error")))
        try:
            data = json.loads(result["content"])
        except ValueError:
            raise ValueError("播放資料格式錯誤")
        status = (data.get("playabilityStatus") or {})
        if status.get("status") != "OK":
            raise ValueError("视频不可播：" + str(status.get("reason") or status.get("status")))
        hls = ((data.get("streamingData") or {}).get("hlsManifestUrl") or "").strip()
        parsed = urlsplit(hls)
        if parsed.scheme != "https" or not parsed.hostname:
            raise ValueError("未取到 HLS 播放地址")
        return hls

    def _get_text(self, url):
        result = self.net.req(url, {
            "method": "GET", "headers": PLAYER_HEADERS, "timeout": REQUEST_TIMEOUT * 1000,
        })
        return self._content(result, range(200, 300))

    @staticmethod
    def _content(result, codes):
        if result.get("error"):
            raise ValueError("網路請求失敗：" + str(result["error"]))
        if result.get("code") not in codes:
            raise ValueError("HTTP " + str(result.get("code") or "無回應"))
        return result["content"]
