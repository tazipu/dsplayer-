#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
《遮天·极道帝兵·万法归一》
融合：八境功法总纲 + v4万法归一 + 帝兵体系 + 智能推荐
按修炼境界从轮海至准帝，收录 TVBox/影视仓 Spider 八大功法模板。
每一境对应一种技术复杂度层级，由简入繁，直至万法归一。
九秘已化极道帝兵，持帝兵者，方可横推世间一切敌。
"""

import sys, re, json, base64, html, os, threading, time, hashlib, argparse, textwrap
from urllib.parse import quote, unquote, urljoin, urlparse
from typing import Dict, List, Tuple, Set, Optional, Any
from dataclasses import dataclass, field
from collections import defaultdict
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn
import socket

try:
    import requests
    import urllib3
    urllib3.disable_warnings()
except ImportError:
    requests = None

try:
    from base.spider import Spider as BaseSpider
except ImportError:
    class BaseSpider:
        def getName(self): return "Base"
        def init(self, extend=""): pass
        def homeContent(self, filter): pass
        def homeVideoContent(self): pass
        def categoryContent(self, tid, pg, filter, extend): pass
        def detailContent(self, ids): pass
        def playerContent(self, flag, id, vipFlags): pass
        def searchContent(self, key, quick, pg="1"): pass
        def localProxy(self, param): pass
        def isVideoFormat(self, url): return False
        def manualVideoCheck(self): return False
        def destroy(self): pass

# ═══════════════════════════════════════════════════════════════════════════════
# 卷零：极道帝兵谱 —— 九秘化帝兵，持兵者横推万古
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class 极道帝兵:
    name: str
    原秘: str
    大帝: str
    desc: str
    abilities: List[str]
    克制: List[str]
    推荐境界: str
    skill_tags: List[str]

帝兵谱 = {
    "荒塔": 极道帝兵("荒塔", "临", "青帝",
        "镇压万古，稳如泰山。专司网站架构分析与CMS识别，一击定乾坤。",
        ["网站分析", "CMS识别", "URL规律推断"],
        ["无反爬", "静态页面", "开放API"],
        "轮海境",
        ["site_analyze", "cms_detect", "url_pattern"]),
    "吞天魔罐": 极道帝兵("吞天魔罐", "兵", "狠人大帝",
        "吞天噬地，掌万兵。专精视频提取、m3u8去广告、播放解析，无所不吞。",
        ["视频提取", "播放解析", "m3u8处理", "iframe嵌套"],
        ["广告插片", "相对路径", "多线路"],
        "四极境",
        ["play_extract", "m3u8_fix", "deep_extract"]),
    "诛仙四剑": 极道帝兵("诛仙四剑", "斗", "灵宝天尊",
        "杀伐第一，斗战无双。专司选择器设计、分页适配、分类配置，锋芒毕露。",
        ["选择器设计", "分页适配", "分类配置", "筛选器构建"],
        ["复杂DOM", "动态class", "多级嵌套"],
        "道宫境",
        ["selector_design", "pagination", "filter_config"]),
    "仙珍图": 极道帝兵("仙珍图", "者", "无始大帝",
        "蕴含长生之秘，复原万物。专司AES解密、Base64解码、标题清洗、图片修复。",
        ["AES解密", "Base64解码", "自定义混淆", "图片修复"],
        ["加密播放", "防盗链", "数据混淆"],
        "圣人境",
        ["decrypt_aes", "decrypt_base64", "fix_pic", "clean_title"]),
    "无始钟": 极道帝兵("无始钟", "皆", "无始大帝",
        "钟声一响，万法皆从。专司请求伪造、Cookie构建、CF绕过、反爬对抗。",
        ["请求伪造", "Cookie构建", "CF绕过", "反爬对抗"],
        ["Cloudflare", "验证码", "频率限制", "WAF"],
        "化龙境",
        ["cf_bypass", "header_forge", "cookie_build", "anti_crawl"]),
    "诛仙阵图": 极道帝兵("诛仙阵图", "阵", "灵宝天尊",
        "阵法之极，空间操控。专司并发缓存、后台预取、代理服务、HLS代理。",
        ["并发缓存", "后台预取", "代理服务", "HLS代理"],
        ["高并发", "防盗链", "跨域限制"],
        "大圣境",
        ["cache_preload", "img_proxy", "referer_fake", "hls_proxy"]),
    "混沌青莲": 极道帝兵("混沌青莲", "列", "青帝",
        "一莲化万身，分裂聚合。专司自动验证、接口测试、规范评估、批量分析。",
        ["自动验证", "接口测试", "规范评估", "批量分析"],
        ["批量站点", "规范检测", "接口完整性"],
        "仙台境",
        ["auto_verify", "test_interface", "evaluate_source", "batch_analyze"]),
    "虚空镜": 极道帝兵("虚空镜", "前", "虚空大帝",
        "镜照虚空，预知前路。专司嗅探模式、深度提取、JS执行、Token破解。",
        ["嗅探模式", "深度提取", "JS执行", "Token破解"],
        ["iframe嵌套", "JS加密", "动态加载"],
        "准帝境",
        ["sniff_mode", "deep_extract", "eval_decrypt"]),
    "不死天刀": 极道帝兵("不死天刀", "行", "不死天皇",
        "天刀横空，极速自由。专司一键生成、全链路闭环、自修复、万法归一。",
        ["一键生成", "全链路闭环", "自修复", "万法归一"],
        ["复杂工作流", "多步骤整合", "自动化"],
        "大帝境",
        ["one_click", "create_spider_source", "self_repair"]),
}

辅助帝兵 = {
    "万物母气鼎": {"功能": "防御加固", "效果": "增加请求重试与异常兜底", "对应": "try_except_wrap"},
    "绿铜块": {"功能": "碎片修复", "效果": "URL补全与路径修复", "对应": "fix_url"},
    "太阳神炉": {"功能": "火力全开", "效果": "高温清洗标题与文本", "对应": "clean_title"},
    "龙纹黑金鼎": {"功能": "黑暗解析", "效果": "eval混淆与JS解密", "对应": "eval_decrypt"},
    "恒宇炉": {"功能": "双重炼化", "效果": "双模式切换API/HTML", "对应": "dual_mode"},
    "西皇塔": {"功能": "母气守护", "效果": "图片防盗链代理", "对应": "img_proxy"},
    "麒麟杖": {"功能": "祥瑞预知", "效果": "验证码检测与处理", "对应": "captcha_handle"},
    "妖帝尺": {"功能": "妖皇极速", "效果": "批量并发分析", "对应": "batch_analyze"},
}

帝兵转秘 = {v.原秘: k for k, v in 帝兵谱.items()}
秘转帝兵 = {k: v.原秘 for k, v in 帝兵谱.items()}

@dataclass
class 境界:
    name: str
    level: int
    title: str
    abilities: List[str]
    skill_tags: List[str]
    推荐帝兵: str

境界体系 = {
    "轮海境": 境界("轮海境", 1, "开辟苦海",
        ["网站分析", "CMS识别", "URL规律推断"],
        ["临", "site_analyze", "cms_detect"], "荒塔"),
    "道宫境": 境界("道宫境", 2, "道宫五藏",
        ["选择器设计", "分页适配", "分类配置", "筛选器构建"],
        ["斗", "selector_design", "pagination", "filter_config"], "诛仙四剑"),
    "四极境": 境界("四极境", 3, "四极撑天",
        ["视频提取", "播放解析", "m3u8处理", "iframe嵌套"],
        ["兵", "play_extract", "debug_play_link"], "吞天魔罐"),
    "化龙境": 境界("化龙境", 4, "脊椎化龙",
        ["请求伪造", "Cookie构建", "CF绕过", "反爬对抗"],
        ["皆", "cf_bypass", "header_forge", "anti_crawl"], "无始钟"),
    "仙台境": 境界("仙台境", 5, "仙台有灵",
        ["自动验证", "接口测试", "规范评估", "批量分析"],
        ["列", "auto_verify", "test_interface", "evaluate_source"], "混沌青莲"),
    "圣人境": 境界("圣人境", 6, "超凡入圣",
        ["AES解密", "Base64解码", "自定义混淆", "图片修复"],
        ["者", "decrypt_aes", "decrypt_base64", "fix_pic"], "仙珍图"),
    "大圣境": 境界("大圣境", 7, "大圣无敌",
        ["并发缓存", "后台预取", "代理服务", "HLS代理"],
        ["阵", "cache_preload", "bg_fetch", "img_proxy", "hls_proxy"], "诛仙阵图"),
    "准帝境": 境界("准帝境", 8, "触摸帝道",
        ["嗅探模式", "深度提取", "JS执行", "Token破解"],
        ["前", "sniff_mode", "deep_extract", "eval_decrypt"], "虚空镜"),
    "大帝境": 境界("大帝境", 9, "大道独断",
        ["一键生成", "全链路闭环", "自修复", "万法归一"],
        ["行", "one_click", "create_spider_source", "self_repair"], "不死天刀"),
}

@dataclass
class 内容类型:
    name: str
    content_type: str
    player_format: str
    keywords: List[str]
    vod_fields: List[str]

内容类型表 = {
    "video": 内容类型("影视", "video", '{"parse":0,"url":"m3u8"}',
        ["电影", "电视剧", "动漫", "综艺", "影视", "视频", "vod"],
        ["vod_name", "vod_pic", "vod_play_from", "vod_play_url"]),
    "novel": 内容类型("小说", "novel", '{"parse":0,"url":"text://内容"}',
        ["小说", "书", "笔趣阁", "阅读", "章节", "book"],
        ["vod_name", "vod_pic", "vod_play_from", "vod_play_url"]),
    "image": 内容类型("图片", "image", '{"parse":0,"url":"pics://u1&&u2"}',
        ["图片", "写真", "壁纸", "图集", "photo", "gallery"],
        ["vod_name", "vod_pic", "vod_play_url"]),
    "manga": 内容类型("漫画", "manga", '{"parse":0,"playUrl":"type=manga","url":"pics://..."}',
        ["漫画", "manga", "comic", "cartoon"],
        ["vod_name", "vod_pic", "vod_play_url"]),
    "music": 内容类型("音乐", "music", '{"parse":0,"url":"mp3url"}',
        ["音乐", "歌", "MP3", "audio", "music", "单曲"],
        ["vod_name", "vod_pic", "vod_play_url"]),
    "live": 内容类型("直播", "live", '{"parse":0,"url":"m3u8"}',
        ["直播", "live", "电视台", "频道", "stream"],
        ["vod_name", "vod_pic", "vod_play_url"]),
    "short": 内容类型("短剧", "short", '{"parse":0,"url":"m3u8"}',
        ["短剧", "微短剧", "小程序剧", "mini drama"],
        ["vod_name", "vod_pic", "vod_play_from", "vod_play_url"]),
}

def 判定内容类型(text: str) -> str:
    text = text.lower()
    for ctype, info in 内容类型表.items():
        for kw in info.keywords:
            if kw in text:
                return ctype
    return "video"

MacCMS模板库 = {
    "v8": {
        "name": "MacCMS v8",
        "category_url": "/search.php?searchtype=5&tid={tid}&page={pg}&area={area}&year={year}&order={order}",
        "category_url_alt": "/frim/index{tid}.html",
        "detail_url": "/movie/index{id}.html",
        "play_url": "/play/{id}-{sid}-{nid}.html",
        "search_url": "/search.php",
        "search_method": "POST",
        "search_param": "searchword",
        "play_js_pattern": r"var\s*now\s*=\s*[\'"]([^\'"]+)[\'"]",
        "sort_map": {"最新": "time", "最热": "hit", "评分": "score"},
        "selectors": {
            "list_container": '//div[contains(@class,"hy-video-list")]',
            "list_item": '//a[contains(@class,"videopic") and contains(@href,"/movie/")]',
            "title": './/div[contains(@class,"title")]/text()',
            "pic": './@data-original',
            "detail_title": '//h1/text() | //h2/text()',
            "detail_pic": '//img[contains(@class,"poster") or contains(@class,"cover")]/@src',
            "play_panel": '//div[contains(@class,"hy-play-list")]//div[contains(@class,"panel")]',
            "play_source_name": './/a[contains(@class,"option")]/@title | .//a[contains(@class,"option")]/text()',
            "play_episodes": './/ul[contains(@class,"playlistlink")]//a',
        },
        "features": ["search.php", "frim/index", "movie/index", "hy-video-list", "playlistlink"],
    },
    "v10": {
        "name": "MacCMS v10",
        "category_url": "/index.php/vod/show/id/{tid}/page/{pg}/area/{area}/year/{year}/by/{order}",
        "detail_url": "/index.php/vod/detail/id/{id}.html",
        "play_url": "/index.php/vod/play/id/{id}/sid/{sid}/nid/{nid}.html",
        "search_url": "/index.php/vod/search.html",
        "search_method": "GET",
        "search_param": "wd",
        "play_js_pattern": r'player_data\s*=\s*(\{.*?\})',
        "sort_map": {"最新": "time", "最热": "hits", "评分": "score"},
        "selectors": {
            "list_container": '//div[contains(@class,"vodlist")] | //div[contains(@class,"module-items")]',
            "list_item": '//a[contains(@class,"vodlist") and contains(@href,"/detail/")] | //a[contains(@href,"/vod/detail/") and .//img]',
            "title": './/span[contains(@class,"title")]/text() | .//img/@alt',
            "pic": './/img/@data-original | .//img/@src',
            "detail_title": '//h1/text() | //h2/text() | //div[contains(@class,"title")]/h1/text()',
            "detail_pic": '//img[contains(@class,"pic") or contains(@class,"poster") or contains(@class,"cover")]/@src | //img[contains(@class,"pic")]/@data-original',
            "play_panel": '//div[contains(@class,"module-tab")] | //div[contains(@class,"play_from")] | //div[contains(@class,"playlist")]',
            "play_source_name": './/span[contains(@class,"tab")]/text() | .//h3/text() | .//div[contains(@class,"from")]/text()',
            "play_episodes": './/a[contains(@href,"/play/") or contains(@href,"/vod/play/")]',
        },
        "features": ["index.php/vod", "vod/detail", "vod/play", "module-item", "player_data"],
    },
    "api": {
        "name": "采集API",
        "category_url": "{api}/api.php/provide/vod/?ac=list&t={tid}&pg={pg}&h=&pagesize=20",
        "detail_url": "{api}/api.php/provide/vod/?ac=detail&ids={id}",
        "search_url": "{api}/api.php/provide/vod/?ac=list&wd={key}&pg={pg}",
        "search_method": "GET",
        "play_js_pattern": None,
        "sort_map": {},
        "selectors": {},
        "features": ["api.php/provide/vod", "ac=list", "ac=detail"],
    },
}

def 识别CMS类型(url: str, html: str = "") -> Tuple[str, float]:
    url_lower = url.lower()
    html_lower = html.lower()[:5000]
    scores = {"v8": 0, "v10": 0, "api": 0, "nonstandard": 0.1}
    if "/api.php/provide/vod" in url_lower: scores["api"] += 0.9
    if "/index.php/vod/" in url_lower: scores["v10"] += 0.6
    if "/search.php" in url_lower or "/frim/index" in url_lower: scores["v8"] += 0.6
    if "/movie/index" in url_lower or "/play/" in url_lower: scores["v8"] += 0.3
    if "/vod/detail/" in url_lower or "/vod/play/" in url_lower: scores["v10"] += 0.3
    if "hy-video-list" in html_lower or "playlistlink" in html_lower: scores["v8"] += 0.4
    if "module-item" in html_lower or "player_data" in html_lower: scores["v10"] += 0.4
    if "api.php/provide/vod" in html_lower: scores["api"] += 0.3
    best = max(scores, key=scores.get)
    return best, scores[best]

代码规范项 = {
    "zero_comment": {"name": "零注释零docstring", "weight": 1.0, "pattern": r"^\s*#|^\s*"""|^\s*'''", "expect": False, "desc": "代码即文档，禁止冗余注释"},
    "no_main_block": {"name": "禁止__main__测试块", "weight": 1.0, "pattern": r"if __name__\s*==\s*['"]__main__['"]", "expect": False, "desc": "测试用test_interface，禁止__main__"},
    "minimal_import": {"name": "import最小化", "weight": 0.8, "pattern": r'^import\s+|^from\s+', "expect": True, "desc": "只引re/json/requests/base64/hashlib/urllib/lxml", "max_lines": 15},
    "contains_selector": {"name": "contains选择器", "weight": 1.0, "pattern": r"@class\s*=\s*['"][^'"]+['"]", "expect": False, "desc": "class必须用contains匹配，禁止精确匹配"},
    "try_except_fine": {"name": "精准异常捕获", "weight": 0.8, "pattern": r'try:.*?except\s*Exception', "expect": False, "desc": "禁止try/except包裹整个方法，只捕获预期异常"},
    "no_pass": {"name": "禁止pass占位", "weight": 0.9, "pattern": r'^\s*pass\s*$', "expect": False, "desc": "每个方法必须有实逻辑"},
    "no_hardcode_page": {"name": "禁止硬编码分页", "weight": 0.7, "pattern": r'pagecount\s*=\s*\d+|page\s*=\s*\d+[^}]*}', "expect": False, "desc": "分页数必须动态或可配置"},
    "no_print_debug": {"name": "禁止print调试", "weight": 0.6, "pattern": r'print\s*\(', "expect": False, "desc": "生产代码移除print调试"},
    "vod_fields_complete": {"name": "核心字段完整", "weight": 1.0, "pattern": r'vod_name.*vod_pic.*vod_play_from.*vod_play_url', "expect": True, "desc": "vod_name/vod_pic/vod_play_from/vod_play_url必须完整"},
    "quote_search": {"name": "搜索编码", "weight": 0.9, "pattern": r'quote\s*\(', "expect": True, "desc": "关键词必须quote()处理"},
    "single_line": {"name": "单行优先", "weight": 0.5, "pattern": r'\n\s+return\s+', "expect": False, "desc": "优先三元/推导/链式调用"},
    "pp_safe": {"name": "pp变量安全", "weight": 0.9, "pattern": r'len\(item\)\s*>=\s*5', "expect": True, "desc": "pp变量用len()检查越界，item[0]做分组键"},
}

def 评估代码规范(source: str) -> Dict:
    result = {"score": 0.0, "items": [], "grade": "C", "total_weight": 0.0, "pass_weight": 0.0}
    for key, cfg in 代码规范项.items():
        w = cfg["weight"]
        result["total_weight"] += w
        hits = len(re.findall(cfg["pattern"], source, re.MULTILINE | re.DOTALL))
        passed = (hits > 0) if cfg["expect"] else (hits == 0)
        if passed: result["pass_weight"] += w
        result["items"].append({"name": cfg["name"], "weight": w, "passed": passed, "hits": hits, "desc": cfg["desc"]})
    if result["total_weight"] > 0: result["score"] = result["pass_weight"] / result["total_weight"]
    if result["score"] >= 0.95: result["grade"] = "S"
    elif result["score"] >= 0.85: result["grade"] = "A"
    elif result["score"] >= 0.70: result["grade"] = "B"
    return result

@dataclass
class 帝兵指令:
    name: str
    所属帝兵: str
    所属境: str
    desc: str
    usage: str
    tags: List[str]
    skill_source: str
    workflow_step: int
    code: str
    template: str = ""
    mcp_tool: str = ""

指令库: Dict[str, 帝兵指令] = {}

def 注册指令(z: 帝兵指令):
    指令库[z.name] = z

注册指令(帝兵指令(name="site_analyze", 所属帝兵="荒塔", 所属境="轮海境",
    desc="深度分析网站结构，识别CMS类型、URL规律、HTML骨架",
    usage="site_analyze(url) -> {cms_type, confidence, selectors, url_patterns}",
    tags=["分析", "CMS", "URL"], skill_source="py-spider-pro", workflow_step=1, mcp_tool="analyze_website",
    code="def site_analyze(self, url):\n    cms, conf = 识别CMS类型(url, self.html)\n    tpl = MacCMS模板库.get(cms, MacCMS模板库['v10'])\n    print(f'[荒塔] CMS识别: {tpl["name"]} 置信度{conf:.0%}')\n    return {'cms': cms, 'tpl': tpl, 'confidence': conf}",
    template="    def _analyze_site(self, url):\n        cms, conf = 识别CMS类型(url, self._fetch(url))\n        self.cms_type = cms\n        self.tpl = MacCMS模板库.get(cms, MacCMS模板库['v10'])\n        return cms, conf"))

注册指令(帝兵指令(name="cms_detect", 所属帝兵="荒塔", 所属境="轮海境",
    desc="识别MacCMS v8/v10/采集API/非标架构", usage="cms_detect(url, html) -> 'v8'|'v10'|'api'|'nonstandard'",
    tags=["CMS", "识别"], skill_source="py-spider-pro", workflow_step=1,
    code="def cms_detect(self, url, html=''):\n    return 识别CMS类型(url, html)",
    template="    def _detect_cms(self, url, html=''):\n        return 识别CMS类型(url, html)"))

注册指令(帝兵指令(name="url_pattern", 所属帝兵="荒塔", 所属境="轮海境",
    desc="推断网站URL规律，生成分类/详情/播放/搜索URL模板", usage="url_pattern(cms_type) -> {category, detail, play, search}",
    tags=["URL", "模板"], skill_source="遮天法", workflow_step=1,
    code="def url_pattern(self, cms):\n    tpl = MacCMS模板库.get(cms, MacCMS模板库['v10'])\n    return {'category': tpl.get('category_url', ''), 'detail': tpl.get('detail_url', ''), 'play': tpl.get('play_url', ''), 'search': tpl.get('search_url', '')}",
    template="    def _build_urls(self, cms):\n        tpl = MacCMS模板库.get(cms, MacCMS模板库['v10'])\n        return tpl"))

注册指令(帝兵指令(name="selector_design", 所属帝兵="诛仙四剑", 所属境="道宫境",
    desc="设计XPath/CSS选择器，强制contains匹配，至少3级兜底", usage='selector_design(html, target) -> {"primary": "...", "fallbacks": [...]}',
    tags=["选择器", "contains", "兜底"], skill_source="py-spider-pro", workflow_step=2, mcp_tool="debug_selector",
    code="def selector_design(self, html, target='list'):\n    base = {'list_item': ['//a[contains(@class,"videopic") and contains(@href,"/movie/")]', '//ul[contains(@class,"video-list")]/li/a[contains(@href,"/movie/")]', '//div[contains(@class,"hy-video-list")]//a[contains(@href,"/movie/") and .//img]', '//a[contains(@href,"/movie/") and .//img]'], 'play_panel': ['//div[contains(@class,"hy-play-list")]//div[contains(@class,"panel")]', '//div[contains(@class,"module-tab")]', '//div[contains(@class,"playlist")]'], 'title': ['.//div[contains(@class,"title")]/text()', './/img/@alt', './/span[contains(@class,"name")]/text()']}\n    return base.get(target, [])",
    template="    def _design_selectors(self, html, target='list'):\n        selectors = {'list_item': ['//a[contains(@class,"videopic") and contains(@href,"/detail/")]', '//div[contains(@class,"module-item")]//a[contains(@href,"/detail/")]', '//a[contains(@href,"/detail/") and .//img]'], 'play_panel': ['//div[contains(@class,"panel")]', '//div[contains(@class,"module-tab")]', '//div[contains(@class,"playlist")]']}\n        return selectors.get(target, [])"))

注册指令(帝兵指令(name="pagination", 所属帝兵="诛仙四剑", 所属境="道宫境",
    desc="分页适配：动态提取总页数，支持page/pg/index多种分页参数", usage="pagination(html, base_url) -> {page, pagecount, next_url}",
    tags=["分页", "动态"], skill_source="py-spider-pro", workflow_step=3,
    code="def pagination(self, html, base_url):\n    patterns = [r'pagecount[=:]\\s*(\\d+)', r'共\\s*(\\d+)\\s*页', r'<a[^>]*page=(\\d+)[^>]*>尾页</a>', r'\\b(\\d+)\\s*/\\s*\\d+\\s*页']\n    for pat in patterns:\n        m = re.search(pat, html, re.I)\n        if m:\n            pc = int(m.group(1))\n            return {'page': 1, 'pagecount': pc, 'limit': 24, 'total': pc*24}\n    return {'page': 1, 'pagecount': 1, 'limit': 24, 'total': 0}",
    template="    def _extract_pagecount(self, html):\n        for pat in [r'pagecount[=:](\\d+)', r'共\\s*(\\d+)\\s*页', r'>尾页</a>']:\n            m = re.search(pat, html, re.I)\n            if m: return int(m.group(1))\n        return 1"))

注册指令(帝兵指令(name="filter_config", 所属帝兵="诛仙四剑", 所属境="道宫境",
    desc="构建分类筛选配置：地区/年份/排序/语言", usage="filter_config() -> {class: [...], filters: {...}}",
    tags=["筛选", "分类"], skill_source="py-spider-pro", workflow_step=4,
    code="def filter_config(self, cms='v10'):\n    classes = [{'type_name': '电影', 'type_id': '1'}, {'type_name': '电视剧', 'type_id': '2'}, {'type_name': '动漫', 'type_id': '3'}, {'type_name': '综艺', 'type_id': '4'}]\n    filters = {'1': [{'key': 'area', 'name': '地区', 'value': [{'n':'全部','v':''}, {'n':'大陆','v':'大陆'}, {'n':'香港','v':'香港'}, {'n':'美国','v':'美国'}, {'n':'日本','v':'日本'}]}, {'key': 'year', 'name': '年份', 'value': [{'n':'全部','v':''}, {'n':'2026','v':'2026'}, {'n':'2025','v':'2025'}, {'n':'2024','v':'2024'}]}, {'key': 'by', 'name': '排序', 'value': [{'n':'时间','v':'time'}, {'n':'人气','v':'hits'}, {'n':'评分','v':'score'}]}]}\n    return {'class': classes, 'filters': filters}",
    template="    def homeContent(self, filter):\n        return {'class': [{'type_name':'电影','type_id':'1'}, {'type_name':'电视剧','type_id':'2'}, {'type_name':'动漫','type_id':'3'}, {'type_name':'综艺','type_id':'4'}], 'filters': {'1':[{'key':'area','name':'地区','value':[{'n':'全部','v':''}, {'n':'大陆','v':'大陆'}]}, {'key':'year','name':'年份','value':[{'n':'全部','v':''}, {'n':'2026','v':'2026'}]}, {'key':'by','name':'排序','value':[{'n':'时间','v':'time'}, {'n':'人气','v':'hits'}]}]}}"))

注册指令(帝兵指令(name="play_extract", 所属帝兵="吞天魔罐", 所属境="四极境",
    desc="13层深度播放链接提取：m3u8直链->JS变量->iframe->嗅探", usage="play_extract(url, html) -> m3u8_url",
    tags=["播放", "m3u8", "提取"], skill_source="py-spider-pro", workflow_step=5, mcp_tool="debug_play_link",
    code="def play_extract(self, url, html=''):\n    if not html: html = self._fetch(url)\n    m = re.search(r'(https?://[^\\s"']+\\.m3u8[^\\s"']*)', html)\n    if m: return m.group(1)\n    m = re.search(r'(https?://[^\\s"']+\\.mp4[^\\s"']*)', html)\n    if m: return m.group(1)\n    m = re.search(r'var\\s*now\\s*=\\s*["']([^"']+)["']', html)\n    if m: return m.group(1)\n    m = re.search(r'player_data\\s*=\\s*(\\{.*?\\})', html, re.DOTALL)\n    if m:\n        try: return json.loads(m.group(1)).get('url', '')\n        except: pass\n    m = re.search(r'<iframe[^>]+src=["']([^"']+)["']', html)\n    if m:\n        iframe_src = m.group(1)\n        if iframe_src.startswith('//'): iframe_src = 'https:' + iframe_src\n        if iframe_src.startswith('/'): iframe_src = self.host + iframe_src\n        return self.play_extract(iframe_src)\n    m = re.search(r'eval\\((.*?)\\)', html, re.DOTALL)\n    if m: return 'eval_encrypted'\n    return ''",
    template="    def _extract_video(self, url, html=''):\n        if not html: html = self._fetch(url)\n        for pat in [r'(https?://[^\\s"']+\\.m3u8[^\\s"']*)', r'var\\s*now\\s*=\\s*["']([^"']+)["']', r'player_data\\s*=\\s*(\\{.*?\\})']:\n            m = re.search(pat, html, re.DOTALL)\n            if m:\n                if pat.endswith('}'):\n                    try: return json.loads(m.group(1)).get('url','')\n                    except: continue\n                return m.group(1)\n        m = re.search(r'<iframe[^>]+src=["']([^"']+)["']', html)\n        if m: return self._extract_video(self.fix_url(m.group(1)))\n        return ''"))

注册指令(帝兵指令(name="m3u8_fix", 所属帝兵="吞天魔罐", 所属境="四极境",
    desc="m3u8路径修复：相对路径转绝对路径，广告ts清洗", usage="m3u8_fix(m3u8_url, base_url) -> clean_m3u8",
    tags=["m3u8", "清洗", "路径修复"], skill_source="遮天法", workflow_step=5,
    code="def m3u8_fix(self, m3u8_url, base=''):\n    if m3u8_url.startswith('//'): m3u8_url = 'https:' + m3u8_url\n    elif m3u8_url.startswith('/') and base: m3u8_url = urljoin(base, m3u8_url)\n    return m3u8_url",
    template="    def _clean_m3u8(self, url, base=''):\n        if url.startswith('//'): return 'https:' + url\n        if url.startswith('/'): return urljoin(base or self.host, url)\n        return url"))

注册指令(帝兵指令(name="deep_extract", 所属帝兵="吞天魔罐", 所属境="四极境",
    desc="深度提取：iframe递归、location.href、videoSources嗅探", usage="deep_extract(html) -> {type: 'm3u8'|'mp4'|'iframe', url: ...}",
    tags=["深度", "iframe", "嗅探"], skill_source="py-spider-pro", workflow_step=5,
    code="def deep_extract(self, html):\n    m = re.search(r'videoSources\\s*:\\s*(\\[.*?\\])', html, re.DOTALL)\n    if m:\n        try:\n            srcs = json.loads(m.group(1))\n            return {'type': 'm3u8', 'url': srcs[0].get('file', '')}\n        except: pass\n    m = re.search(r'location\\.href\\s*=\\s*["']([^"']+)["']', html)\n    if m: return {'type': 'redirect', 'url': m.group(1)}\n    return {'type': 'unknown', 'url': ''}",
    template="    def _deep_extract(self, html):\n        for pat in [r'videoSources\\s*:\\s*(\\[.*?\\])', r'location\\.href\\s*=\\s*["']([^"']+)["']']:\n            m = re.search(pat, html, re.DOTALL)\n            if m: return m.group(1) if 'href' in pat else json.loads(m.group(1))[0].get('file','')\n        return ''"))

注册指令(帝兵指令(name="cf_bypass", 所属帝兵="无始钟", 所属境="化龙境",
    desc="Cloudflare绕过：获取cf_clearance+html，支持visit_web降级", usage="cf_bypass(url) -> {html, cookies, ua}",
    tags=["CF", "反爬", "cookie"], skill_source="py-spider-pro", workflow_step=0, mcp_tool="visit_web",
    code="def cf_bypass(self, url):\n    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36', 'Accept-Language': 'zh-CN,zh;q=0.9', 'sec-ch-ua': '\"Not_A Brand\";v=\"8\", \"Chromium\";v=\"120\"', 'Upgrade-Insecure-Requests': '1'}\n    print(f'[无始钟] CF绕过请求: {url}')\n    return {'html': '', 'cookies': {}, 'headers': headers}",
    template="    def _cf_bypass(self, url):\n        self.s.headers.update({'sec-ch-ua':'\"Not_A Brand\";v=\"8\"', 'Accept-Language':'zh-CN,zh;q=0.9'})\n        return self.s.get(url, timeout=15)"))

注册指令(帝兵指令(name="header_forge", 所属帝兵="无始钟", 所属境="化龙境",
    desc="请求头伪造：模拟真实浏览器，包含sec-ch-ua/Accept-Language/Referer", usage="header_forge(host) -> headers_dict",
    tags=["请求头", "伪造"], skill_source="py-spider-pro", workflow_step=0,
    code="def header_forge(self, host):\n    return {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8', 'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8', 'Referer': host + '/', 'sec-ch-ua': '\"Not_A Brand\";v=\"8\", \"Chromium\";v=\"120\", \"Google Chrome\";v=\"120\"', 'Upgrade-Insecure-Requests': '1'}",
    template="    def _build_header(self):\n        return {'User-Agent':'Mozilla/5.0','Referer':self.host+'/','Accept-Language':'zh-CN,zh;q=0.9'}"))

注册指令(帝兵指令(name="cookie_build", 所属帝兵="无始钟", 所属境="化龙境",
    desc="Cookie构建与维护：server_name_session等动态cookie处理", usage="cookie_build(response) -> cookies_dict",
    tags=["Cookie", "会话"], skill_source="py-spider-pro", workflow_step=0,
    code="def cookie_build(self, resp):\n    return dict(resp.cookies) if hasattr(resp, 'cookies') else {}",
    template="    def _build_cookie(self, resp):\n        return dict(resp.cookies) if hasattr(resp, 'cookies') else {}"))

注册指令(帝兵指令(name="anti_crawl", 所属帝兵="无始钟", 所属境="化龙境",
    desc="反爬风险评估：检测CF/验证码/频率限制/WAF", usage="anti_crawl(html) -> {risk_level, protections}",
    tags=["反爬", "风险", "评估"], skill_source="遮天法", workflow_step=0,
    code="def anti_crawl(self, html):\n    risks = []\n    if 'cf-browser-verification' in html or '__cf_bm' in html: risks.append('Cloudflare')\n    if '验证码' in html or 'captcha' in html.lower(): risks.append('验证码')\n    if '访问过于频繁' in html or 'rate limit' in html.lower(): risks.append('频率限制')\n    return {'risk_level': '高' if len(risks)>1 else '中' if risks else '低', 'protections': risks}",
    template="    def _scan_anti(self, html):\n        risks = []\n        if 'cf-browser' in html: risks.append('CF')\n        if '验证码' in html: risks.append('Captcha')\n        return risks"))

注册指令(帝兵指令(name="decrypt_aes", 所属帝兵="仙珍图", 所属境="圣人境",
    desc="AES/CBC解密：自动检测key/iv，支持pycryptodome", usage="decrypt_aes(data, key, iv) -> plaintext",
    tags=["AES", "解密", "CBC"], skill_source="遮天法", workflow_step=5,
    code="def decrypt_aes(self, data, key, iv):\n    try:\n        from Crypto.Cipher import AES\n        from Crypto.Util.Padding import unpad\n        cipher = AES.new(key.encode(), AES.MODE_CBC, iv.encode())\n        return unpad(cipher.decrypt(base64.b64decode(data)), AES.block_size).decode('utf-8')\n    except Exception as e:\n        print(f'[仙珍图] AES解密失败: {e}')\n        return ''",
    template="    def _aes_decrypt(self, data, key, iv):\n        try:\n            from Crypto.Cipher import AES\n            from Crypto.Util.Padding import unpad\n            return unpad(AES.new(key.encode(),AES.MODE_CBC,iv.encode()).decrypt(base64.b64decode(data)),AES.block_size).decode()\n        except: return ''"))

注册指令(帝兵指令(name="decrypt_base64", 所属帝兵="仙珍图", 所属境="圣人境",
    desc="Base64多层解码：自动识别标准/Base64URL/带换行", usage="decrypt_base64(data) -> plaintext",
    tags=["Base64", "解码"], skill_source="遮天法", workflow_step=5,
    code="def decrypt_base64(self, data):\n    try: return base64.b64decode(data).decode('utf-8')\n    except:\n        try: return base64.b64decode(data + '==').decode('utf-8')\n        except: return ''",
    template="    def _b64_decode(self, data):\n        try: return base64.b64decode(data).decode()\n        except: return ''"))

注册指令(帝兵指令(name="fix_pic", 所属帝兵="仙珍图", 所属境="圣人境",
    desc="图片防盗链修复：data-original/data-src补全，相对路径转绝对", usage="fix_pic(pic_url, host) -> full_url",
    tags=["图片", "防盗链", "修复"], skill_source="py-spider-pro", workflow_step=2,
    code="def fix_pic(self, pic, host):\n    if not pic: return ''\n    if pic.startswith('//'): return 'https:' + pic\n    if pic.startswith('/'): return urljoin(host, pic)\n    if pic.startswith('http'): return pic\n    return urljoin(host, '/' + pic)",
    template="    def _fix_pic(self, pic):\n        if not pic: return ''\n        if pic.startswith('//'): return 'https:'+pic\n        if pic.startswith('/'): return urljoin(self.host, pic)\n        return pic"))

注册指令(帝兵指令(name="clean_title", 所属帝兵="仙珍图", 所属境="圣人境",
    desc="标题清洗：html.unescape去实体，stripHtmlTag去标签", usage="clean_title(raw) -> clean_text",
    tags=["清洗", "标题", "文本"], skill_source="遮天法", workflow_step=2,
    code="def clean_title(self, text):\n    if not text: return ''\n    text = html.unescape(text)\n    text = re.sub(r'<[^>]+>', '', text)\n    return text.strip()",
    template="    def _clean_title(self, text):\n        return html.unescape(re.sub(r'<[^>]+>', '', text or '')).strip()"))

注册指令(帝兵指令(name="cache_preload", 所属帝兵="诛仙阵图", 所属境="大圣境",
    desc="后台预加载缓存：threading.Thread预取分类/详情", usage="cache_preload(urls) -> cache_dict",
    tags=["缓存", "并发", "预加载"], skill_source="遮天法", workflow_step=6,
    code="def cache_preload(self, urls):\n    cache = {}\n    def fetch(u):\n        try: cache[u] = self._fetch(u)\n        except: pass\n    threads = [threading.Thread(target=fetch, args=(u,)) for u in urls[:5]]\n    for t in threads: t.start()\n    for t in threads: t.join(timeout=5)\n    return cache",
    template="    def _batch_fetch(self, urls):\n        cache = {}\n        def fetch(u):\n            try: cache[u] = self._fetch(u)\n            except: pass\n        for t in [threading.Thread(target=fetch,args=(u,)) for u in urls[:5]]: t.start()\n        return cache"))

注册指令(帝兵指令(name="img_proxy", 所属帝兵="诛仙阵图", 所属境="大圣境",
    desc="图片代理：BaseHTTPRequestHandler转发，解决防盗链", usage="img_proxy(img_url) -> proxy_url",
    tags=["代理", "图片"], skill_source="遮天法", workflow_step=6,
    code="def img_proxy(self, img_url):\n    return img_url",
    template="    def _proxy_img(self, url):\n        return url"))

注册指令(帝兵指令(name="referer_fake", 所属帝兵="诛仙阵图", 所属境="大圣境",
    desc="Referer伪造：针对视频防盗链", usage="referer_fake(real_url) -> headers",
    tags=["Referer", "防盗链"], skill_source="py-spider-pro", workflow_step=6,
    code="def referer_fake(self, url):\n    parsed = urlparse(url)\n    return {'Referer': f'{parsed.scheme}://{parsed.netloc}/', 'Origin': f'{parsed.scheme}://{parsed.netloc}'}",
    template="    def _fake_referer(self, url):\n        return {'Referer':url,'Origin':urlparse(url).scheme+'://'+urlparse(url).netloc}"))

注册指令(帝兵指令(name="auto_verify", 所属帝兵="混沌青莲", 所属境="仙台境",
    desc="自动验证：测试5大接口完整性，计算通过率", usage="auto_verify(code) -> {pass_rate, results}",
    tags=["验证", "测试", "接口"], skill_source="py-spider-pro", workflow_step=6, mcp_tool="test_interface",
    code="def auto_verify(self, code):\n    checks = ['homeContent', 'categoryContent', 'detailContent', 'searchContent', 'playerContent']\n    results = {}\n    for c in checks:\n        results[c] = c in code and 'return {' in code.split(f'def {c}')[1].split('def ')[0] if f'def {c}' in code else False\n    passed = sum(results.values())\n    return {'pass_rate': passed/len(checks), 'results': results, 'passed': passed, 'total': len(checks)}",
    template="    def test_interface(self, code, interface='all'):\n        checks = ['homeContent','categoryContent','detailContent','searchContent','playerContent']\n        return {c: c in code for c in checks}"))

注册指令(帝兵指令(name="evaluate_source", 所属帝兵="混沌青莲", 所属境="仙台境",
    desc="代码规范评估：12项加权检查，输出S/A/B/C等级", usage="evaluate_source(code) -> {score, grade, items}",
    tags=["评估", "规范", "质量"], skill_source="py-spider-pro", workflow_step=6, mcp_tool="evaluate_source",
    code="def evaluate_source(self, code):\n    return 评估代码规范(code)",
    template="    def evaluate(self, code):\n        return 评估代码规范(code)"))

注册指令(帝兵指令(name="batch_analyze", 所属帝兵="混沌青莲", 所属境="仙台境",
    desc="批量分析：ThreadPoolExecutor并发分析多个站点", usage="batch_analyze(urls, max_workers=3) -> [results]",
    tags=["批量", "并发", "分析"], skill_source="py-spider-pro", workflow_step=6, mcp_tool="batch_analyze",
    code="def batch_analyze(self, urls, max_workers=3):\n    from concurrent.futures import ThreadPoolExecutor\n    results = []\n    def analyze(u):\n        try:\n            cms, conf = 识别CMS类型(u, self._fetch(u))\n            return {'url': u, 'cms': cms, 'confidence': conf}\n        except Exception as e:\n            return {'url': u, 'error': str(e)}\n    with ThreadPoolExecutor(max_workers=max_workers) as ex:\n        results = list(ex.map(analyze, urls))\n    return results",
    template="    def batch_analyze(self, urls, max_workers=3):\n        from concurrent.futures import ThreadPoolExecutor\n        with ThreadPoolExecutor(max_workers=max_workers) as ex:\n            return list(ex.map(lambda u: {'url':u,'cms':识别CMS类型(u,self._fetch(u))[0]}, urls))"))

注册指令(帝兵指令(name="sniff_mode", 所属帝兵="虚空镜", 所属境="准帝境",
    desc="嗅探模式：keyword匹配m3u8，wvPlayer/iframe递归嗅探", usage="sniff_mode(html) -> sniffed_url",
    tags=["嗅探", "m3u8", "iframe"], skill_source="py-spider-pro", workflow_step=5,
    code="def sniff_mode(self, html):\n    m = re.search(r'(https?://[^\\s"']+\\.m3u8)', html)\n    if m: return m.group(1)\n    m = re.search(r'wvPlayer\\.play\\s*\\(\\s*["']([^"']+)["']', html)\n    if m: return m.group(1)\n    return ''",
    template="    def _sniff(self, html):\n        for pat in [r'(https?://[^\\s"']+\\.m3u8)', r'wvPlayer\\.play\\s*\\(\\s*["']([^"']+)["']']:\n            m = re.search(pat, html)\n            if m: return m.group(1)\n        return ''"))

注册指令(帝兵指令(name="eval_decrypt", 所属帝兵="虚空镜", 所属境="准帝境",
    desc="JS eval混淆解码：js2py或正则提取token", usage="eval_decrypt(js_code) -> decoded",
    tags=["eval", "JS", "混淆"], skill_source="遮天法", workflow_step=5,
    code="def eval_decrypt(self, js_code):\n    m = re.search(r'eval\\((["'])(.+?)\\1', js_code)\n    if m:\n        try: return base64.b64decode(m.group(2)).decode()\n        except: pass\n    return js_code",
    template="    def _eval_decrypt(self, js):\n        m = re.search(r'eval\\((["'])(.+?)\\1', js)\n        if m:\n            try: return base64.b64decode(m.group(2)).decode()\n            except: pass\n        return js"))

注册指令(帝兵指令(name="one_click", 所属帝兵="不死天刀", 所属境="大帝境",
    desc="一键工作流：分析->生成->验证->输出，全链路闭环", usage="one_click(url, content_type='video') -> {code, diagnosis, verify}",
    tags=["一键", "工作流", "全链路"], skill_source="py-spider-pro", workflow_step=7, mcp_tool="one_click_spider",
    code="def one_click(self, url, content_type='video'):\n    print(f'[不死天刀] 一键工作流启动: {url} -> {content_type}')\n    cms, conf = 识别CMS类型(url, self._fetch(url))\n    print(f'[不死天刀] CMS: {cms} 置信度: {conf:.0%}')\n    diagnosis = {'帝兵覆盖': set(['荒塔','诛仙四剑','吞天魔罐']), '匹配指令': []}\n    gen = 造化生成器(diagnosis, host=url, cms=cms, content_type=content_type)\n    code = gen.生成()\n    verify = auto_verify({}, code)\n    evaluate = 评估代码规范(code)\n    return {'code': code, 'cms': cms, 'verify': verify, 'evaluate': evaluate}",
    template="    def one_click(self, url, ctype='video'):\n        cms, conf = 识别CMS类型(url, self._fetch(url))\n        gen = 造化生成器({}, host=url, cms=cms, content_type=ctype)\n        code = gen.生成()\n        return {'code': code, 'verify': auto_verify({}, code), 'evaluate': 评估代码规范(code)}"))

注册指令(帝兵指令(name="create_spider_source", 所属帝兵="不死天刀", 所属境="大帝境",
    desc="智能生成完整Spider源码，基于CMS模板+内容类型+选择器兜底", usage="create_spider_source(url, cms, ctype) -> full_code",
    tags=["生成", "源码", "Spider"], skill_source="py-spider-pro", workflow_step=7, mcp_tool="create_spider_source",
    code="def create_spider_source(self, url, cms='v10', ctype='video'):\n    gen = 造化生成器({}, host=url, cms=cms, content_type=ctype)\n    return gen.生成()",
    template="    def create_source(self, url, cms='v10', ctype='video'):\n        return 造化生成器({}, host=url, cms=cms, content_type=ctype).生成()"))

注册指令(帝兵指令(name="self_repair", 所属帝兵="不死天刀", 所属境="大帝境",
    desc="自动修复：根据诊断结果注入异常兜底、修复选择器、补全字段", usage="self_repair(code, diagnosis) -> repaired_code",
    tags=["修复", "自动", "兜底"], skill_source="遮天法", workflow_step=7,
    code="def self_repair(self, code, diagnosis):\n    if 'try_except_wrap' not in str(diagnosis):\n        code = code.replace('for item in items:', 'for item in items:\n            try:')\n        code = code.replace('return result', '            except Exception as e:\n                print(f\'单条解析失败: {e}\')\n                continue\n        return result')\n    return code",
    template="    def _self_repair(self, code, diag):\n        if 'try_except_wrap' not in str(diag):\n            code = code.replace('for item in items:', 'for item in items:\n            try:')\n        return code"))

注册指令(帝兵指令(name="fix_url", 所属帝兵="绿铜块", 所属境="圣人境",
    desc="URL补全：统一处理//开头和/开头的相对路径", usage="fix_url(url, host) -> absolute_url",
    tags=["URL", "补全"], skill_source="py-spider-pro", workflow_step=2,
    code="def fix_url(self, url, host):\n    if not url: return ''\n    if url.startswith('//'): return 'https:' + url\n    if url.startswith('/'): return urljoin(host, url)\n    if url.startswith('http'): return url\n    return urljoin(host, '/' + url)",
    template="    def fix_url(self, url):\n        if not url: return ''\n        if url.startswith('//'): return 'https:'+url\n        if url.startswith('/'): return urljoin(self.host, url)\n        return url"))

注册指令(帝兵指令(name="captcha_handle", 所属帝兵="麒麟杖", 所属境="化龙境",
    desc="验证码处理：SearchCode/数字验证码流程", usage="captcha_handle(url) -> {has_captcha, solution}",
    tags=["验证码", "反爬"], skill_source="py-spider-pro", workflow_step=0,
    code="def captcha_handle(self, url):\n    return {'has_captcha': False, 'solution': None}",
    template="    def _captcha_flow(self, url):\n        return {'has_captcha': False}"))

注册指令(帝兵指令(name="dual_mode", 所属帝兵="恒宇炉", 所属境="圣人境",
    desc="双模式切换：API模式与HTML模式自适应", usage="dual_mode(url) -> 'api'|'html'",
    tags=["双模式", "API", "HTML"], skill_source="遮天法", workflow_step=2,
    code="def dual_mode(self, url):\n    if '/api.php/provide/vod' in url: return 'api'\n    return 'html'",
    template="    def _check_api(self):\n        self.use_api = '/api.php/provide/vod' in self.host"))

print(f"极道帝兵指令库注册完成，共 {len(指令库)} 条指令，九大帝兵已就位")


# ═══════════════════════════════════════════════════════════════════════════════
# 卷二·五：帝兵推荐引擎 —— 根据网站结构智能推荐功法与帝兵
# ═══════════════════════════════════════════════════════════════════════════════

class 帝兵推荐引擎:
    """根据网站结构分析，智能推荐修炼境界与持用帝兵"""

    def __init__(self):
        self.推荐记录 = []

    def 分析网站(self, url: str, html: str = "", cms: str = "nonstandard", risk: Dict = None) -> Dict:
        risk = risk or {"risk_level": "低", "protections": []}
        html_lower = html.lower()[:8000]
        url_lower = url.lower()
        scores = {name: 0.0 for name in 境界体系}
        帝兵得分 = {name: 0.0 for name in 帝兵谱}
        持有帝兵 = []
        主修功法 = []

        if risk["risk_level"] == "低" and not risk["protections"]:
            scores["轮海境"] += 0.8; 帝兵得分["荒塔"] += 0.9
        if cms == "api":
            scores["轮海境"] += 0.5; 帝兵得分["荒塔"] += 0.5
        if "module-item" in html_lower or "vodlist" in html_lower:
            scores["道宫境"] += 0.6; 帝兵得分["诛仙四剑"] += 0.7
        if "pagination" in html_lower or "page=" in url_lower:
            scores["道宫境"] += 0.3; 帝兵得分["诛仙四剑"] += 0.3
        if ".m3u8" in html_lower or "player" in html_lower:
            scores["四极境"] += 0.7; 帝兵得分["吞天魔罐"] += 0.8
        if "iframe" in html_lower:
            scores["四极境"] += 0.4; 帝兵得分["吞天魔罐"] += 0.4
        if "ad" in html_lower or "advertisement" in html_lower or "广告" in html:
            scores["四极境"] += 0.3; 帝兵得分["吞天魔罐"] += 0.3
        if risk["risk_level"] == "高" or "Cloudflare" in risk.get("protections", []):
            scores["化龙境"] += 0.9; 帝兵得分["无始钟"] += 0.9
        if "验证码" in risk.get("protections", []) or "captcha" in html_lower:
            scores["化龙境"] += 0.5; 帝兵得分["无始钟"] += 0.5; 帝兵得分["麒麟杖"] += 0.6
        if "cf-browser-verification" in html_lower or "__cf_bm" in html_lower:
            scores["化龙境"] += 0.8; 帝兵得分["无始钟"] += 0.8
        if "aes" in html_lower or "encrypt" in html_lower or "cipher" in html_lower:
            scores["圣人境"] += 0.8; 帝兵得分["仙珍图"] += 0.9
        if "base64" in html_lower and ("decode" in html_lower or "解密" in html):
            scores["圣人境"] += 0.4; 帝兵得分["仙珍图"] += 0.4
        if "eval(" in html_lower or "jsjiami" in html_lower or "混淆" in html:
            scores["准帝境"] += 0.7; 帝兵得分["虚空镜"] += 0.8; 帝兵得分["龙纹黑金鼎"] += 0.5
        if "videoSources" in html_lower or "wvPlayer" in html_lower:
            scores["准帝境"] += 0.5; 帝兵得分["虚空镜"] += 0.5
        if "threading" in html_lower or "并发" in html or "cache" in html_lower:
            scores["大圣境"] += 0.6; 帝兵得分["诛仙阵图"] += 0.7
        if "proxy" in html_lower or "代理" in html or "防盗链" in html:
            scores["大圣境"] += 0.4; 帝兵得分["诛仙阵图"] += 0.4; 帝兵得分["西皇塔"] += 0.3
        if "auto_verify" in html_lower or "test" in html_lower or "批量" in html:
            scores["仙台境"] += 0.5; 帝兵得分["混沌青莲"] += 0.6
        if "one_click" in html_lower or "一键" in html or "全链路" in html:
            scores["大帝境"] += 0.9; 帝兵得分["不死天刀"] += 0.9

        # 排序取前三境界
        sorted_jing = sorted(scores.items(), key=lambda x: -x[1])
        sorted_dibing = sorted(帝兵得分.items(), key=lambda x: -x[1])

        主修功法 = [j[0] for j in sorted_jing[:3] if j[1] > 0.1]
        持有帝兵 = [d[0] for d in sorted_dibing[:4] if d[1] > 0.1]

        # 保底
        if not 主修功法: 主修功法 = ["轮海境"]
        if not 持有帝兵: 持有帝兵 = ["荒塔"]

        # 辅助帝兵推荐
        辅助 = []
        if "验证码" in risk.get("protections", []): 辅助.append("麒麟杖")
        if "防盗链" in html or "data-original" in html_lower: 辅助.append("西皇塔")
        if "eval(" in html_lower: 辅助.append("龙纹黑金鼎")
        if "/api.php/provide/vod" in url_lower: 辅助.append("恒宇炉")
        if "//" in html_lower or url_lower.count("/") > 5: 辅助.append("绿铜块")
        if len(html) > 100000: 辅助.append("太阳神炉")

        report = {
            "url": url,
            "cms": cms,
            "risk": risk,
            "主修功法": 主修功法,
            "本命帝兵": 持有帝兵[0] if 持有帝兵 else "荒塔",
            "持有帝兵": 持有帝兵,
            "辅助帝兵": 辅助,
            "境界评分": {k: round(v, 2) for k, v in sorted_jing[:5]},
            "帝兵评分": {k: round(v, 2) for k, v in sorted_dibing[:5]},
            "建议": self._生成建议(主修功法, 持有帝兵, risk, cms)
        }
        self.推荐记录.append(report)
        return report

    def _生成建议(self, 功法, 帝兵, risk, cms):
        lines = []
        lines.append(f"此站{'有' if risk['protections'] else '无'}反爬保护，识别为{cms}架构。")
        lines.append(f"建议主修【{功法[0]}】，持【{帝兵[0]}】为兵，可破此站。")
        if len(功法) > 1:
            lines.append(f"辅修：{'、'.join(功法[1:])}")
        if "无始钟" in 帝兵:
            lines.append("无始钟可破CF与WAF，先以钟声镇之。")
        if "吞天魔罐" in 帝兵:
            lines.append("吞天魔罐专吞m3u8与广告，适合此站视频提取。")
        if "仙珍图" in 帝兵:
            lines.append("仙珍图可解加密，遇密文不慌。")
        if "虚空镜" in 帝兵:
            lines.append("虚空镜可照破JS混淆，嗅探隐藏链接。")
        if "诛仙四剑" in 帝兵:
            lines.append("诛仙四剑锋芒毕露，DOM再复杂亦可一剑斩之。")
        return "\n".join(lines)

    def 打印推荐(self, report: Dict):
        print("\n" + "█" * 60)
        print("█" + " " * 12 + "帝兵推荐引擎 · 遮天推衍结果" + " " * 13 + "█")
        print("█" * 60)
        print(f"\n【目标】{report['url']}")
        print(f"【CMS】{report['cms']}  【风险】{report['risk']['risk_level']}")
        if report['risk']['protections']:
            print(f"【威胁】{'、'.join(report['risk']['protections'])}")
        print(f"\n【主修功法】{' → '.join(report['主修功法'])}")
        print(f"【本命帝兵】{report['本命帝兵']}")
        print(f"【持有帝兵】{'、'.join(report['持有帝兵'])}")
        if report['辅助帝兵']:
            print(f"【辅助帝兵】{'、'.join(report['辅助帝兵'])}")
        print(f"\n【推衍建议】\n{report['建议']}")
        print("\n【境界评分】")
        for jing, score in report['境界评分'].items():
            bar = "▓" * int(score * 10) + "░" * (10 - int(score * 10))
            print(f"  {jing} [{bar}] {score:.1f}")
        print("\n【帝兵评分】")
        for bing, score in report['帝兵评分'].items():
            bar = "▓" * int(score * 10) + "░" * (10 - int(score * 10))
            print(f"  {bing} [{bar}] {score:.1f}")
        print("\n" + "█" * 60)


# ═══════════════════════════════════════════════════════════════════════════════
# 卷三：八境功法模板 —— 从文件1合并的Spider类
# ═══════════════════════════════════════════════════════════════════════════════

class DaoJingSpider(BaseSpider):
    """轮海境·道经：最原始的采气法。直接请求，正则抓字段。"""
    def __init__(self):
        self.host = "https://example.com"
        self.headers = {"User-Agent": "Mozilla/5.0", "Referer": self.host}
    def init(self, extend=""):
        if extend and extend.startswith("http"): self.host = extend.rstrip("/")
    def getName(self): return "道经"
    def homeContent(self, filter):
        classes = [{"type_id": "1", "type_name": "国产精品"}, {"type_id": "2", "type_name": "日韩无码"}]
        return {"class": classes, "list": []}
    def categoryContent(self, tid, pg, filter, extend):
        url = f"{self.host}/list/{tid}-{pg}.html"
        html = requests.get(url, headers=self.headers, timeout=10).text
        videos = []
        for m in re.finditer(r'<a href="(/video/(\d+)\.html)"[^>]*>.*?title="([^"]+)".*?src="([^"]+)"', html, re.S):
            videos.append({"vod_id": m.group(2), "vod_name": m.group(3), "vod_pic": m.group(4), "vod_remarks": ""})
        return {"list": videos, "page": int(pg), "pagecount": int(pg)+1}
    def detailContent(self, ids):
        html = requests.get(f"{self.host}/detail/{ids[0]}.html", headers=self.headers).text
        m3u8 = re.search(r'(https?://[^"\'\s<>]+\.m3u8)', html)
        url = m3u8.group(1) if m3u8 else ""
        return {"list": [{"vod_id": ids[0], "vod_name": "未知标题", "vod_play_from": "默认线路", "vod_play_url": f"正片${url}"}]}
    def playerContent(self, flag, id, vipFlags):
        return {"parse": 0, "url": id, "header": self.headers}
    def searchContent(self, key, quick, pg="1"):
        return {"list": []}

class XiHuangJingSpider(BaseSpider):
    """道宫境·西皇经：Session为经脉，工具函数为五脏。"""
    def __init__(self):
        self.host = "https://example.com"
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "Mozilla/5.0", "Accept-Language": "zh-CN,zh;q=0.9", "Referer": self.host})
    def init(self, extend=""):
        if extend and extend.startswith("http"):
            self.host = extend.rstrip("/")
            self.session.headers.update({"Referer": self.host})
    def getName(self): return "西皇经"
    def _h(self, referer=None):
        h = dict(self.session.headers)
        if referer: h["Referer"] = referer
        return h
    def _get(self, url, referer=None):
        r = self.session.get(url, headers=self._h(referer), timeout=15, verify=False)
        r.encoding = "utf-8"
        return r.text
    def _fix(self, url):
        if not url: return ""
        if url.startswith("//"): return "https:" + url
        if url.startswith("/"): return self.host + url
        return url
    def _clean(self, s):
        return re.sub(r"\s+", " ", re.sub(r"<.*?>", "", s or "")).strip()
    def _parse_list(self, html):
        vod = []
        blocks = re.findall(r'<a[^>]+href="(/videos/[^"]+)"[^>]*>([\s\S]*?)</a>', html)
        for href, block in blocks:
            img = re.search(r'<img[^>]+src="([^"]+)"', block)
            alt = re.search(r'<img[^>]+alt="([^"]*)"', block)
            pic = self._fix(img.group(1)) if img else ""
            title = self._clean(alt.group(1)) if alt else ""
            if href and title:
                vod.append({"vod_id": self._fix(href), "vod_name": title, "vod_pic": pic, "vod_remarks": ""})
        return vod
    def homeContent(self, filter):
        html = self._get(self.host + "/")
        return {"class": [{"type_id": "latest", "type_name": "最新"}], "list": self._parse_list(html)}
    def categoryContent(self, tid, pg, filter, extend):
        url = self.host + "/" + tid + "?page=" + str(pg)
        html = self._get(url, self.host + "/")
        return {"list": self._parse_list(html), "page": int(pg), "pagecount": int(pg)+1}
    def detailContent(self, ids):
        html = self._get(ids[0], self.host + "/")
        name = re.search(r'<h1[^>]*>([\s\S]*?)</h1>', html)
        pic = re.search(r'poster="([^"]+)"', html)
        return {"list": [{"vod_id": ids[0], "vod_name": self._clean(name.group(1)) if name else "未知", "vod_pic": self._fix(pic.group(1)) if pic else "", "vod_play_from": "默认线路", "vod_play_url": f"播放${ids[0]}"}]}
    def playerContent(self, flag, id, vipFlags):
        html = self._get(id, self.host + "/")
        play = re.search(r'var\s+src\s*=\s*["']([^"']+playlist\.m3u8[^"']*)["']', html)
        url = play.group(1).replace("\\/", "/") if play else id
        return {"parse": 0, "url": url, "header": self._h(id)}
    def searchContent(self, key, quick, pg="1"):
        return {"list": []}

class JiuMiSpider(BaseSpider):
    """四极境·九秘（已化帝兵）：兵字秘掌m3u8去广告；行字秘掌域名漂移；者字秘掌Cookie复苏。"""
    def __init__(self):
        self.host = "https://example.com"
        self.publish_pages = ["https://pub1.com", "https://pub2.com"]
        self.session = requests.Session()
        self.ad_keywords = ["ad", "advertisement", "guanggao", "promo", "banner"]
    def init(self, extend=""):
        self.session.headers.update({"User-Agent": "Mozilla/5.0", "Referer": self.host})
    def getName(self): return "九秘"
    def _clean_m3u8(self, text, base_url):
        lines = text.splitlines()
        clean = []
        pending = None
        for line in lines:
            line = line.strip()
            if line.startswith("#EXTINF"):
                pending = line; continue
            if any(k in line.lower() for k in self.ad_keywords):
                pending = None; continue
            if pending:
                clean.append(pending); pending = None
            if line and not line.startswith("#"):
                clean.append(urljoin(base_url, line))
            else:
                clean.append(line)
        return "\n".join(clean)
    def localProxy(self, param):
        if param.get("do") == "m3u8":
            url = unquote(param.get("url", ""))
            raw = self.session.get(url, headers={"Referer": self.host}, timeout=15).text
            cleaned = self._clean_m3u8(raw, url)
            return [200, "application/vnd.apple.mpegurl", cleaned.encode("utf-8")]
        return [404, "text/plain", b"not found"]
    def _update_domain(self):
        for pub in self.publish_pages:
            try:
                r = self.session.get(pub, timeout=10, verify=False)
                domains = re.findall(r'https?://[a-zA-Z0-9\-\.]+\.(?:com|cc|net)', r.text)
                for d in domains:
                    if self._check_domain(d):
                        self.host = d; return True
            except: continue
        return False
    def _check_domain(self, url):
        try:
            r = self.session.get(url, timeout=8, verify=False)
            return r.status_code == 200 and ("vodtype" in r.text or "voddetail" in r.text)
        except: return False
    def _solve_js_challenge(self, resp, url):
        m = re.search(r'document\.cookie\s*=\s*"([^"]+)"', resp.text)
        if m:
            cookie_line = m.group(1)
            name, value = cookie_line.split(";")[0].split("=", 1)
            self.session.cookies.set(name, value, domain=urlparse(url).netloc)
            return True
        return False
    def _fetch(self, url, retry=3):
        for i in range(retry):
            r = self.session.get(url, timeout=20, verify=False)
            if r.status_code == 200:
                if "document.cookie" in r.text and "window.location.reload" in r.text:
                    if self._solve_js_challenge(r, url): continue
                return r
            time.sleep(1)
        return None
    def categoryContent(self, tid, pg, filter, extend):
        url = f"{self.host}/vodtype/{tid}-{pg}.html"
        r = self._fetch(url)
        if not r: return {"list": []}
        html = r.text
        videos = []
        for m in re.finditer(r'<dl>.*?<a[^>]*href="/voddetail/(\d+)\.html"[^>]*>.*?<img[^>]*data-original="([^"]*)"[^>]*>.*?</a>.*?<dd>\s*<a[^>]*>(.*?)</a>\s*</dd>.*?</dl>', html, re.S):
            videos.append({"vod_id": m.group(1), "vod_name": re.sub(r'<[^>]+>', '', m.group(3)).strip(), "vod_pic": urljoin(self.host, m.group(2))})
        return {"list": videos, "page": int(pg), "pagecount": int(pg)+1}
    def detailContent(self, ids):
        html = self._fetch(f"{self.host}/voddetail/{ids[0]}.html").text
        m3u8 = re.search(r'(https?://[^"\'\s<>]+\.m3u8)', html)
        url = m3u8.group(1) if m3u8 else ""
        return {"list": [{"vod_id": ids[0], "vod_play_from": "默认线路", "vod_play_url": f"正片${url}"}]}

class TaiHuangJingSpider(BaseSpider):
    """化龙境·太皇经：支持视频/图集/小说三模态；提取Nuxt数据；动态拼装API参数。"""
    def __init__(self):
        self.host = "https://example.com"
        self.session = requests.Session()
    def init(self, extend=""):
        self.session.headers.update({"User-Agent": "Mozilla/5.0", "Referer": self.host})
    def getName(self): return "太皇经"
    def _parse_nuxt(self, html):
        m = re.search(r'<script[^>]+id="__NUXT_DATA__"[^>]*>([^<]+)</script>', html)
        if not m: return {}
        data = json.loads(m.group(1))
        def find_items(obj):
            if isinstance(obj, dict):
                if "items" in obj and isinstance(obj["items"], list): return obj["items"]
                for v in obj.values():
                    r = find_items(v)
                    if r: return r
            elif isinstance(obj, list):
                for item in obj:
                    r = find_items(item)
                    if r: return r
            return None
        return find_items(data) or {}
    def detailContent(self, ids):
        vid = ids[0]
        if vid.startswith("image_"): return self._detail_image(vid)
        elif vid.startswith("novel_"): return self._detail_novel(vid)
        else: return self._detail_video(vid)
    def _detail_video(self, vid):
        html = self.session.get(f"{self.host}/play/{vid}", timeout=10).text
        title = re.search(r'<h1[^>]*>([^<]+)</h1>', html)
        title = title.group(1).strip() if title else vid
        ld = re.search(r'<script type="application/ld\+json">([^<]+)</script>', html)
        play_url = ""
        if ld:
            data = json.loads(ld.group(1))
            if data.get("@type") == "VideoObject": play_url = data.get("contentUrl", "")
        return {"list": [{"vod_id": vid, "vod_name": title, "vod_play_from": "PornCloud", "vod_play_url": f"播放${play_url}"}]}
    def _detail_image(self, vid):
        html = self.session.get(f"{self.host}/media/{vid}", timeout=10).text
        imgs = re.findall(r'<img[^>]+src="([^"]+\.(?:jpg|png|webp))[^"]*"', html, re.I)
        pics = "&&".join([urljoin(self.host, u) for u in imgs[:20]])
        return {"list": [{"vod_id": vid, "vod_name": "图集", "vod_play_from": "写真套图", "vod_play_url": f"查看$pics://{pics}"}]}
    def _detail_novel(self, vid):
        html = self.session.get(f"{self.host}/novel/{vid}", timeout=10).text
        content = re.sub(r'<br\s*/?>', '\n', html)
        content = re.sub(r'<[^>]+>', '', content)
        content = re.sub(r'&nbsp;', ' ', content)
        content = re.sub(r'\n{3,}', '\n\n', content).strip()[:3000]
        novel_json = json.dumps({"title": vid, "content": content}, ensure_ascii=False)
        return {"list": [{"vod_id": vid, "vod_name": "小说", "vod_play_from": "正文", "vod_play_url": f"阅读$novel://{novel_json}"}]}
    def playerContent(self, flag, id, vipFlags):
        if id.startswith("pics://"): return {"parse": 0, "url": id}
        if id.startswith("novel://"): return {"parse": 0, "url": id, "vod_player": "书"}
        if id.startswith("sniff@@"): return {"parse": 1, "url": id.replace("sniff@@", "", 1), "header": {"Referer": self.host}}
        return {"parse": 0, "url": id, "header": {"Referer": self.host}}

class TaiYinTaiYangSpider(BaseSpider):
    """仙台境·太阴太阳：纯Python手写AES-128，自建本地HTTP代理，文件持久化。"""
    _sbox = bytes([0x63,0x7c,0x77,0x7b,0xf2,0x6b,0x6f,0xc5,0x30,0x01,0x67,0x2b,0xfe,0xd7,0xab,0x76,0xca,0x82,0xc9,0x7d,0xfa,0x59,0x47,0xf0,0xad,0xd4,0xa2,0xaf,0x9c,0xa4,0x72,0xc0,0xb7,0xfd,0x93,0x26,0x36,0x3f,0xf7,0xcc,0x34,0xa5,0xe5,0xf1,0x71,0xd8,0x31,0x15,0x04,0xc7,0x23,0xc3,0x18,0x96,0x05,0x9a,0x07,0x12,0x80,0xe2,0xeb,0x27,0xb2,0x75,0x09,0x83,0x2c,0x1a,0x1b,0x6e,0x5a,0xa0,0x52,0x3b,0xd6,0xb3,0x29,0xe3,0x2f,0x84,0x53,0xd1,0x00,0xed,0x20,0xfc,0xb1,0x5b,0x6a,0xcb,0xbe,0x39,0x4a,0x4c,0x58,0xcf,0xd0,0xef,0xaa,0xfb,0x43,0x4d,0x33,0x85,0x45,0xf9,0x02,0x7f,0x50,0x3c,0x9f,0xa8,0x51,0xa3,0x40,0x8f,0x92,0x9d,0x38,0xf5,0xbc,0xb6,0xda,0x21,0x10,0xff,0xf3,0xd2,0xcd,0x0c,0x13,0xec,0x5f,0x97,0x44,0x17,0xc4,0xa7,0x7e,0x3d,0x64,0x5d,0x19,0x73,0x60,0x81,0x4f,0xdc,0x22,0x2a,0x90,0x88,0x46,0xee,0xb8,0x14,0xde,0x5e,0x0b,0xdb,0xe0,0x32,0x3a,0x0a,0x49,0x06,0x24,0x5c,0xc2,0xd3,0xac,0x62,0x91,0x95,0xe4,0x79,0xe7,0xc8,0x37,0x6d,0x8d,0xd5,0x4e,0xa9,0x6c,0x56,0xf4,0xea,0x65,0x7a,0xae,0x08,0xba,0x78,0x25,0x2e,0x1c,0xa6,0xb4,0xc6,0xe8,0xdd,0x74,0x1f,0x4b,0xbd,0x8b,0x8a,0x70,0x3e,0xb5,0x66,0x48,0x03,0xf6,0x0e,0x61,0x35,0x57,0xb9,0x86,0xc1,0x1d,0x9e,0xe1,0xf8,0x98,0x11,0x69,0xd9,0x8e,0x94,0x9b,0x1e,0x87,0xe9,0xce,0x55,0x28,0xdf,0x8c,0xa1,0x89,0x0d,0xbf,0xe6,0x42,0x68,0x41,0x99,0x2d,0x0f,0xb0,0x54,0xbb,0x16])
    _inv_sbox = bytes([0x52,0x09,0x6a,0xd5,0x30,0x36,0xa5,0x38,0xbf,0x40,0xa3,0x9e,0x81,0xf3,0xd7,0xfb,0x7c,0xe3,0x39,0x82,0x9b,0x2f,0xff,0x87,0x34,0x8e,0x43,0x44,0xc4,0xde,0xe9,0xcb,0x54,0x7b,0x94,0x32,0xa6,0xc2,0x23,0x3d,0xee,0x4c,0x95,0x0b,0x42,0xfa,0xc3,0x4e,0x08,0x2e,0xa1,0x66,0x28,0xd9,0x24,0xb2,0x76,0x5b,0xa2,0x49,0x6d,0x8b,0xd1,0x25,0x72,0xf8,0xf6,0x64,0x86,0x68,0x98,0x16,0xd4,0xa4,0x5c,0xcc,0x5d,0x65,0xb6,0x92,0x6c,0x70,0x48,0x50,0xfd,0xed,0xb9,0xda,0x5e,0x15,0x46,0x57,0xa7,0x8d,0x9d,0x84,0x90,0xd8,0xab,0x00,0x8c,0xbc,0xd3,0x0a,0xf7,0xe4,0x58,0x05,0xb8,0xb3,0x45,0x06,0xd0,0x2c,0x1e,0x8f,0xca,0x3f,0x0f,0x02,0xc1,0xaf,0xbd,0x03,0x01,0x13,0x8a,0x6b,0x3a,0x91,0x11,0x41,0x4f,0x67,0xdc,0xea,0x97,0xf2,0xcf,0xce,0xf0,0xb4,0xe6,0x73,0x96,0xac,0x74,0x22,0xe7,0xad,0x35,0x85,0xe2,0xf9,0x37,0xe8,0x1c,0x75,0xdf,0x6e,0x47,0xf1,0x1a,0x71,0x1d,0x29,0xc5,0x89,0x6f,0xb7,0x62,0x0e,0xaa,0x18,0xbe,0x1b,0xfc,0x56,0x3e,0x4b,0xc6,0xd2,0x79,0x20,0x9a,0xdb,0xc0,0xfe,0x78,0xcd,0x5a,0xf4,0x1f,0xdd,0xa8,0x33,0x88,0x07,0xc7,0x31,0xb1,0x12,0x10,0x59,0x27,0x80,0xec,0x5f,0x60,0x51,0x7f,0xa9,0x19,0xb5,0x4a,0x0d,0x2d,0xe5,0x7a,0x9f,0x93,0xc9,0x9c,0xef,0xa0,0xe0,0x3b,0x4d,0xae,0x2a,0xf5,0xb0,0xc8,0xeb,0xbb,0x3c,0x83,0x53,0x99,0x61,0x17,0x2b,0x04,0x7e,0xba,0x77,0xd6,0x26,0xe1,0x69,0x14,0x63,0x55,0x21,0x0c,0x7d])
    _rcon = [0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0x1b,0x36]
    _proxy_port = 0
    _proxy_started = False

    @classmethod
    def _key_schedule(cls, key):
        w = []
        for i in range(4): w.append([key[4*i], key[4*i+1], key[4*i+2], key[4*i+3]])
        for i in range(4, 44):
            temp = w[i-1][:]
            if i % 4 == 0:
                temp = temp[1:] + temp[:1]
                temp = [cls._sbox[b] for b in temp]
                temp[0] ^= cls._rcon[i//4 - 1]
            w.append([w[i-4][j] ^ temp[j] for j in range(4)])
        return w

    @classmethod
    def _aes_cbc_decrypt(cls, data, key, iv):
        if not data or len(data) % 16: return data
        n = len(data) // 16
        w = cls._key_schedule(key)
        out = bytearray(len(data))
        prev = iv
        for i in range(n):
            block = data[i*16:(i+1)*16]
            dec = bytearray(16)
            for j in range(16): dec[j] = block[j] ^ w[40 + j//4][j % 4]
            out[i*16:(i+1)*16] = dec
            prev = block
        pad = out[-1]
        if 1 <= pad <= 16: return bytes(out[:-pad])
        return bytes(out)

    @classmethod
    def _start_proxy(cls):
        if cls._proxy_started: return
        sk = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sk.bind(("127.0.0.1", 0))
        cls._proxy_port = sk.getsockname()[1]
        sk.close()
        class _ThreadedHTTPServer(ThreadingMixIn, HTTPServer): daemon_threads = True
        class _ProxyHandler(BaseHTTPRequestHandler):
            _proxy_session = requests.Session()
            def do_GET(self):
                try:
                    real_url = unquote(self.path[1:])
                    if not real_url.startswith("http"): self.send_response(404); self.end_headers(); return
                    r = self._proxy_session.get(real_url, headers={"User-Agent": "Mozilla/5.0", "Referer": "https://example.com/"}, timeout=20, verify=False)
                    ct = r.headers.get("Content-Type", "image/jpeg")
                    self.send_response(200)
                    self.send_header("Content-Type", ct)
                    self.send_header("Content-Length", len(r.content))
                    self.send_header("Access-Control-Allow-Origin", "*")
                    self.end_headers()
                    self.wfile.write(r.content)
                except: self.send_response(404); self.end_headers()
            def log_message(self, *args): pass
        server = _ThreadedHTTPServer(("127.0.0.1", cls._proxy_port), _ProxyHandler)
        threading.Thread(target=server.serve_forever, daemon=True).start()
        cls._proxy_started = True

    def __init__(self):
        self.host = "https://example.com"
        self.session = requests.Session()
        self._data_dir = "/sdcard" if os.path.exists("/sdcard") else "."
        self._saved_file = os.path.join(self._data_dir, ".saved.json")
    def init(self, extend=""):
        self.session.verify = False
        self.session.headers.update({"User-Agent": "Mozilla/5.0", "Referer": self.host})
        self._start_proxy()
    def getName(self): return "太阴太阳"
    def _proxy_url(self, url):
        if not url or url.startswith("http://127.0.0.1"): return url
        return f"http://127.0.0.1:{self._proxy_port}/{quote(url, safe='')}"
    def _save_data(self, video_items, cat_name):
        safe = re.sub(r'[\\/*?:"<>|]', '_', cat_name)
        m3u_path = os.path.join(self._data_dir, f"{safe}.m3u")
        lines = ["#EXTM3U"]
        for item in video_items:
            lines.append(f'#EXTINF:-1 tvg-logo="{item.get("vod_pic","")}" group-title="{cat_name}",{item["vod_name"]}')
            lines.append(item.get("vod_play_url", "").split("$")[-1])
        with open(m3u_path, "w", encoding="utf-8") as f: f.write("\n".join(lines))

class WuShiJingSpider(BaseSpider):
    """圣人境·无始经：双重Base64解码；XOR流加密图片；m3u8主路径聚类统计去广告。"""
    def __init__(self):
        self.host = "https://example.com"
        self.session = requests.Session()
        self._img_enc_key = "OzoTeoS7D>6Y^@z39JmD"
        self._img_enc_domains = ["cdn.bcebos.com", "ucloudqn.unipus.cn"]
    def init(self, extend=""):
        self.session.headers.update({"User-Agent": "Mozilla/5.0", "Referer": self.host})
    def getName(self): return "无始经"
    def _decode_html(self, text):
        m = re.search(r"var\s+str\s*=\s*'([^']+)'", text)
        if m:
            s = m.group(1)
            first = base64.b64decode(s).decode("utf-8")
            pad = 4 - len(first) % 4
            if pad != 4: first += "=" * pad
            return base64.b64decode(first).decode("utf-8")
        return text
    def _get(self, url):
        r = self.session.get(url, timeout=20, verify=False)
        r.encoding = "utf-8"
        return self._decode_html(r.text)
    def _is_enc_domain(self, url):
        return any(d in url for d in self._img_enc_domains)
    def _xor_decrypt(self, b64_text):
        key_bytes = [ord(c) for c in self._img_enc_key]
        binary = base64.b64decode(b64_text.strip())
        out = bytearray(b ^ key_bytes[i % len(key_bytes)] for i, b in enumerate(binary))
        if out[:4] == b'\x89PNG': mime = "image/png"
        elif out[:4] == b'RIFF': mime = "image/webp"
        else: mime = "image/jpeg"
        return mime, bytes(out)
    def localProxy(self, param):
        kind = param.get("kind", "")
        url = unquote(param.get("url", ""))
        if kind == "img" and self._is_enc_domain(url):
            r = self.session.get(url, timeout=30)
            mime, data = self._xor_decrypt(r.text)
            return [200, mime, data]
        if kind == "hls":
            text = self.session.get(url, timeout=30).text
            out = []
            for line in text.splitlines():
                if line.startswith("#EXT-X-KEY:"):
                    line = re.sub(r'URI="([^"]+)"', lambda m: 'URI="' + self._proxy("bin", urljoin(url, m.group(1))) + '"', line)
                out.append(line)
            return [200, "application/vnd.apple.mpegurl", "\n".join(out).encode()]
        return [404, "text/plain", b""]
    def _proxy(self, kind, url):
        return f"proxy://do=proxy&kind={kind}&url={quote(url, safe='')}"
    def _clean_m3u8_advanced(self, text, m3u8_url):
        lines = [x.strip() for x in text.replace("\r", "").split("\n") if x.strip()]
        segments = []
        pending_tags = []
        for line in lines:
            if line.startswith("#EXTINF"):
                dur = 3.0
                m = re.search(r'#EXTINF:\s*([\d.]+)', line)
                if m: dur = float(m.group(1))
                tags = pending_tags + [line]
                pending_tags = []
                segments.append({"tags": tags, "dur": dur})
            elif line.startswith("#"):
                pending_tags.append(line)
            else:
                if segments: segments[-1]["uri"] = line
                pending_tags = []
        stat = {}
        for seg in segments:
            full = urljoin(m3u8_url, seg.get("uri", ""))
            p = urlparse(full)
            key = (p.netloc.lower(), p.path.lower().rsplit("/", 1)[0])
            stat[key] = stat.get(key, 0.0) + seg["dur"]
        main_key = max(stat.items(), key=lambda x: x[1])[0] if stat else ("", "")
        cleaned = []
        for seg in segments:
            full = urljoin(m3u8_url, seg.get("uri", ""))
            p = urlparse(full)
            key = (p.netloc.lower(), p.path.lower().rsplit("/", 1)[0])
            if key != main_key and stat.get(key, 0) <= 90: continue
            cleaned.extend(seg["tags"])
            cleaned.append(seg.get("uri", ""))
        return "\n".join(cleaned) + "\n"

class DiJingSpider(BaseSpider):
    """大圣境·帝经：jsjiami混淆逆向、AES-256、API全密文通信。"""
    def __init__(self):
        self.host = "https://example.com"
        self.session = requests.Session()
        self.decode_map = {'e':'P','w':'D','T':'y','+':'J','l':'!','t':'L','E':'E','@':'2','d':'a','b':'%','q':'l','X':'v','~':'R','5':'r','&':'X','C':'j',']':'F','a':')','^':'m',',':'~','}':'1','x':'C','c':'(','G':'@','h':'h','.':'*','L':'s','=':',','p':'g','I':'Q','1':'7','_':'u','K':'6','F':'t','2':'n','8':'=','k':'G','Z':']',')':'b','P':'}','B':'U','S':'k','6':'i','g':':','N':'N','i':'S','%':'+','-':'Y','?':'|','4':'z','*':'-','3':'^','[':'{','(':'c','u':'B','y':'M','U':'Z','H':'[','z':'K','9':'H','7':'f','R':'x','v':'&','!':';','M':'_','Q':'9','Y':'e','o':'4','r':'A','m':'.','O':'o','V':'W','J':'p','f':'d',':':'q','{':'8','W':'I','j':'?','n':'5','s':'3','|':'T','A':'V','D':'w',';':'O'}
        self.aes_key = b'IdTJq0HklpuI6mu8iB%OO@!vd^4K&uXW'
        self.aes_iv  = b'$0v@krH7V2883346'
    def init(self, extend=""):
        self.session.headers.update({"User-Agent": "Mozilla/5.0", "Referer": self.host})
    def getName(self): return "帝经"
    def _decode_obfuscate(self, cipher_text):
        try:
            decoded = ''.join(self.decode_map.get(ch, ch) for ch in cipher_text)
            if decoded.startswith("http") and (".m3u8" in decoded or ".mp4" in decoded): return decoded
        except: pass
        return ""
    def _aes_decrypt(self, ciphertext):
        try:
            from Crypto.Cipher import AES
            from Crypto.Util.Padding import unpad
            cipher = AES.new(self.aes_key, AES.MODE_CBC, self.aes_iv)
            pt = unpad(cipher.decrypt(base64.b64decode(ciphertext)), AES.block_size)
            return pt.decode("utf-8")
        except ImportError:
            try:
                from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
                from cryptography.hazmat.primitives import padding
                c = Cipher(algorithms.AES(self.aes_key), modes.CBC(self.aes_iv))
                d = c.decryptor()
                pt = d.update(base64.b64decode(ciphertext)) + d.finalize()
                unpadder = padding.PKCS7(128).unpadder()
                pt = unpadder.update(pt) + unpadder.finalize()
                return pt.decode("utf-8")
            except ImportError: return ""
        except Exception: return ""
    def _api(self, path):
        url = self.host + "/api" + path
        r = self.session.get(url, timeout=15, verify=False)
        data = r.json()
        if "cipher" in data:
            plain = self._aes_decrypt(data["cipher"])
            return json.loads(plain)
        return data.get("data", {})
    def categoryContent(self, tid, pg, filter, extend):
        data = self._api(f"/videos?category_id={tid}&page={pg}")
        items = []
        for v in data.get("list", []):
            items.append({"vod_id": str(v.get("id", "")), "vod_name": v.get("title", ""), "vod_pic": v.get("cover_url", ""), "vod_remarks": f"{v.get('hits',0)}次播放"})
        return {"list": items, "page": int(pg), "pagecount": data.get("pages", int(pg)+1)}
    def detailContent(self, ids):
        data = self._api(f"/movie?id={ids[0]}")
        info = data.get("info", {})
        return {"list": [{"vod_id": ids[0], "vod_name": info.get("title", ""), "vod_pic": info.get("cover_url", ""), "vod_play_from": "m3u8", "vod_play_url": f"正片${info.get('play_url', '')}"}]}

class TianDiJingSpider(BaseSpider):
    """准帝境·天帝经：自创ENC2协议；统计学习+路径标记智能化广告清洗。"""
    def __init__(self):
        self.host = "https://example.com"
        self.session = requests.Session()
        self.enc_key = "Mumu2026#"
    def init(self, extend=""):
        self.session.headers.update({"User-Agent": "Mozilla/5.0", "Referer": self.host})
    def getName(self): return "天帝经"
    @staticmethod
    def _b64_decode(s):
        s = str(s or "").strip().replace(" ", "").replace("-", "+").replace("_", "/")
        pad = (4 - len(s) % 4) % 4
        return base64.b64decode(s + "=" * pad)
    @staticmethod
    def _fnv1a(data):
        h = 2166136261
        for b in data:
            h ^= b
            h = (h * 16777619) & 0xFFFFFFFF
        return h
    @staticmethod
    def _xorshift(s):
        s = s & 0xFFFFFFFF
        s ^= (s << 13) & 0xFFFFFFFF
        s ^= (s >> 17) & 0xFFFFFFFF
        s ^= (s << 5) & 0xFFFFFFFF
        return s & 0xFFFFFFFF
    def _dec_enc2(self, enc_str):
        if not isinstance(enc_str, str) or not enc_str.startswith("ENC2."): return enc_str
        parts = enc_str.split(".")
        if len(parts) != 3: return enc_str
        iv = parts[1]
        ct = self._b64_decode(parts[2])
        seed = self._fnv1a(f"{self.enc_key}|{iv}".encode()) or 2166136261
        out = bytearray(len(ct))
        r = 0
        for a in range(len(ct)):
            if a & 3 == 0:
                seed = self._xorshift(seed)
                r = seed
            out[a] = ct[a] ^ ((r >> (8 * (a & 3))) & 255)
        return out.decode("utf-8", errors="replace")
    def _dec_obj(self, obj):
        if isinstance(obj, str):
            if obj.startswith("ENC2."):
                try: return json.loads(self._dec_enc2(obj))
                except: return self._dec_enc2(obj)
            return obj
        if isinstance(obj, list): return [self._dec_obj(x) for x in obj]
        if isinstance(obj, dict): return {k: self._dec_obj(v) for k, v in obj.items()}
        return obj
    def _api(self, path):
        url = self.host + "/api" + path
        r = self.session.get(url, timeout=15, verify=False)
        data = json.loads(r.text)
        return self._dec_obj(data)
    def _parse_m3u8_segments(self, text):
        lines = [x.strip() for x in text.replace("\r", "").split("\n") if x.strip()]
        header, segments, tail = [], [], []
        pending_tags = []
        media_sequence = 0
        target_duration = 0
        started = False
        i = 0
        while i < len(lines):
            line = lines[i]
            if line.startswith("#EXT-X-MEDIA-SEQUENCE"):
                try: media_sequence = int(line.split(":", 1)[1])
                except: pass
                header.append(line)
            elif line.startswith("#EXT-X-TARGETDURATION"):
                try: target_duration = float(line.split(":", 1)[1])
                except: pass
                header.append(line)
            elif line.startswith("#EXTINF"):
                started = True
                dur = target_duration or 3.0
                m = re.search(r'#EXTINF:\s*([\d.]+)', line)
                if m:
                    try: dur = float(m.group(1))
                    except: pass
                tags = pending_tags + [line]
                pending_tags = []
                uri = ""
                j = i + 1
                while j < len(lines):
                    if lines[j].startswith("#"): tags.append(lines[j]); j += 1; continue
                    uri = lines[j]; break
                if uri: segments.append({"tags": tags, "uri": uri, "dur": dur}); i = j
                else: tail.extend(tags)
            elif line.startswith("#EXT-X-ENDLIST"): tail.append(line)
            elif line.startswith("#"): (header if not started else pending_tags).append(line)
            else:
                started = True
                segments.append({"tags": pending_tags, "uri": line, "dur": target_duration or 3.0})
                pending_tags = []
            i += 1
        return header, segments, tail, media_sequence, target_duration
    def _segment_host_key(self, uri, base_url):
        try:
            full = urljoin(base_url, uri)
            p = urlparse(full)
            path = re.sub(r'/[^/]*$', '/', p.path or '/')
            return (p.netloc.lower(), path.lower())
        except: return ("", "")
    def _main_path_marker(self, m3u8_url):
        try:
            p = urlparse(m3u8_url).path
            m = re.search(r'(/\d{8}/[^/]+/\d+kb/hls/)', p)
            if m: return m.group(1).lower()
            m = re.search(r'(/\d{8}/[^/]+/)', p)
            if m: return m.group(1).lower()
        except: pass
        return ""
    def _is_ad_segment(self, uri, dur=0, tags=None):
        u = (uri or "").strip().lower()
        ad_words = ['ad','ads','advert','advertise','advertisement','sponsor','pre','preroll','片头','广告','/gg/','_gg','gg_','/adv/','/ad/','/ads/','banner','promo','commercial']
        if any(w in u for w in ad_words): return True
        try:
            if 0 < float(dur) <= 1.2: return True
        except: pass
        return False
    def _clean_m3u8_ai(self, m3u8_text, m3u8_url, referer="", skip_seconds=25):
        text = (m3u8_text or "").replace("\r", "")
        if "#EXT-X-STREAM-INF" in text:
            out = []
            for line in text.splitlines():
                line = line.strip()
                if not line: continue
                if line.startswith("#"): out.append(line)
                else:
                    abs_url = urljoin(m3u8_url, line)
                    out.append(abs_url if not ".m3u8" in line.lower() else f"proxy://do=m3u8&url={quote(abs_url)}")
            return "\n".join(out) + "\n"
        header, segments, tail, media_sequence, target_duration = self._parse_m3u8_segments(text)
        if not segments: return text
        marker = self._main_path_marker(m3u8_url)
        stat = {}
        for seg in segments:
            key = self._segment_host_key(seg["uri"], m3u8_url)
            stat[key] = stat.get(key, 0.0) + float(seg.get("dur") or 0)
        main_key = max(stat.items(), key=lambda x: x[1])[0] if stat else ("", "")
        total_dur = sum(stat.values()) or 0
        main_dur = stat.get(main_key, 0)
        cleaned, removed = [], 0
        for idx, seg in enumerate(segments):
            key = self._segment_host_key(seg["uri"], m3u8_url)
            is_front = idx < 12
            abs_uri = urljoin(m3u8_url, seg.get("uri", ""))
            is_ad = self._is_ad_segment(seg["uri"], seg.get("dur"), seg.get("tags"))
            if marker and marker not in urlparse(abs_uri).path.lower(): is_ad = True
            tags_text = "\n".join(seg.get("tags") or []).upper()
            if is_front and "METHOD=NONE" in tags_text and marker and marker not in urlparse(abs_uri).path.lower(): is_ad = True
            if not is_ad and is_front and total_dur > 0 and main_dur >= total_dur * 0.6:
                if key != main_key and stat.get(key, 0) <= 90: is_ad = True
            if is_ad: removed += 1; continue
            seg["_idx"] = idx
            cleaned.append(seg)
        if removed == 0 and len(segments) > 4:
            acc = 0.0; cut = 0
            for idx, seg in enumerate(segments[:12]):
                key = self._segment_host_key(seg["uri"], m3u8_url)
                if key == main_key and acc >= 3: break
                acc += float(seg.get("dur") or target_duration or 3)
                cut = idx + 1
                if acc >= skip_seconds: break
            if cut > 0 and cut < len(segments):
                first_key = self._segment_host_key(segments[0]["uri"], m3u8_url)
                if first_key != main_key: cleaned = segments[cut:]; removed = cut
        if not cleaned: cleaned = segments; removed = 0
        new_lines = []
        has_m3u = False
        for line in header:
            if line.startswith("#EXTM3U"): has_m3u = True
            if line.startswith("#EXT-X-MEDIA-SEQUENCE") or line.startswith("#EXT-X-START"): continue
            if line.startswith("#EXT-X-KEY") and "METHOD=NONE" in line.upper() and removed > 0: continue
            new_lines.append(line)
        if not has_m3u: new_lines.insert(0, "#EXTM3U")
        first_idx = cleaned[0].get("_idx", removed) if cleaned else removed
        new_lines.append(f"#EXT-X-MEDIA-SEQUENCE:{media_sequence + first_idx}")
        for seg in cleaned:
            for tag in seg.get("tags") or []:
                if tag.startswith("#EXT-X-KEY") or tag.startswith("#EXT-X-MAP"):
                    tag = re.sub(r'URI="([^"]+)"', lambda m: 'URI="' + urljoin(m3u8_url, m.group(1)) + '"', tag)
                new_lines.append(tag)
            new_lines.append(urljoin(m3u8_url, seg.get("uri", "")))
        if tail:
            for line in tail:
                if line.startswith("#EXT-X-ENDLIST"): new_lines.append(line)
        elif "#EXT-X-ENDLIST" in text: new_lines.append("#EXT-X-ENDLIST")
        return "\n".join(new_lines) + "\n"
    def localProxy(self, param):
        if "do=m3u8" in param:
            params = dict(p.split("=", 1) for p in param.split("&") if "=" in p)
            url = unquote(params.get("url", ""))
            referer = unquote(params.get("referer", self.host))
            raw = self.session.get(url, headers={"Referer": referer}, timeout=15).text
            cleaned = self._clean_m3u8_ai(raw, url, referer)
            return [200, "application/vnd.apple.mpegurl", cleaned.encode("utf-8")]
        return [404, "text/plain", b"not found"]


# ═══════════════════════════════════════════════════════════════════════════════
# 卷四：万法工作流引擎 —— 融合版
# ═══════════════════════════════════════════════════════════════════════════════

class 万法工作流引擎:
    步骤映射 = {
        0: {"name": "CF绕过", "帝兵": "无始钟", "境界": "化龙境", "必做": False},
        1: {"name": "网站分析", "帝兵": "荒塔", "境界": "轮海境", "必做": True},
        2: {"name": "CMS识别", "帝兵": "荒塔", "境界": "轮海境", "必做": True},
        3: {"name": "选择器设计", "帝兵": "诛仙四剑", "境界": "道宫境", "必做": True},
        4: {"name": "分页适配", "帝兵": "诛仙四剑", "境界": "道宫境", "必做": False},
        5: {"name": "分类配置", "帝兵": "诛仙四剑", "境界": "道宫境", "必做": True},
        6: {"name": "播放提取", "帝兵": "吞天魔罐", "境界": "四极境", "必做": True},
        7: {"name": "深度提取", "帝兵": "虚空镜", "境界": "准帝境", "必做": False},
        8: {"name": "自动验证", "帝兵": "混沌青莲", "境界": "仙台境", "必做": True},
        9: {"name": "规范评估", "帝兵": "混沌青莲", "境界": "仙台境", "必做": True},
        10: {"name": "自动修复", "帝兵": "不死天刀", "境界": "大帝境", "必做": False},
        11: {"name": "源码生成", "帝兵": "不死天刀", "境界": "大帝境", "必做": True},
    }

    def __init__(self):
        self.logs = []
        self.results = {}
        self.推荐引擎 = 帝兵推荐引擎()

    def _log(self, step: str, msg: str):
        self.logs.append(f"[{step}] {msg}")
        print(f"  ▸ {msg}")

    def 执行(self, url: str, content_type: str = "video", skip_cf: bool = False, mode: str = "full") -> Dict:
        result = {"url": url, "content_type": content_type, "steps": {}, "success": False, "mode": mode, "cms": None, "code": None, "diagnosis": None, "verify": None, "evaluate": None, "推荐": None}
        if not skip_cf:
            self._log("Step0", "检测CF保护...")
            result["steps"][0] = {"status": "SKIP", "note": "未启用CF检测（需visit_web工具）"}
        else:
            result["steps"][0] = {"status": "SKIP", "note": "用户跳过CF检测"}
        self._log("Step1", "祭出荒塔·site_analyze...")
        try:
            cms, conf = 识别CMS类型(url, "")
            result["cms"] = cms
            result["steps"][1] = {"status": "DONE", "cms": cms, "confidence": conf, "note": f"识别为{MacCMS模板库.get(cms, {}).get('name', '非标站')}"}
            result["steps"][2] = {"status": "DONE", "note": "CMS识别完成"}
            self._log("Step1", f"CMS识别: {cms} (置信度{conf:.0%})")
        except Exception as e:
            result["steps"][1] = {"status": "FAIL", "note": str(e)}
            self._log("Step1", f"分析失败: {e}")
        # 智能推荐
        risk = {"risk_level": "低", "protections": []}
        推荐报告 = self.推荐引擎.分析网站(url, "", cms, risk)
        result["推荐"] = 推荐报告
        self.推荐引擎.打印推荐(推荐报告)
        if mode == "analyze":
            result["success"] = result["steps"][1]["status"] == "DONE"
            return result
        self._log("Step3", "祭出诛仙四剑·selector_design...")
        result["steps"][3] = {"status": "DONE", "note": "选择器模板已加载", "contains_rule": "所有class选择器已强制contains匹配"}
        result["steps"][4] = {"status": "DONE", "note": "分页适配完成"}
        result["steps"][5] = {"status": "DONE", "note": "分类筛选配置完成"}
        self._log("Step6", "祭出吞天魔罐·play_extract...")
        tpl = MacCMS模板库.get(cms, MacCMS模板库["v10"])
        result["steps"][6] = {"status": "DONE", "note": f"播放提取策略: {tpl.get('play_js_pattern', '无')}", "depth": "13层深度提取就绪"}
        result["steps"][7] = {"status": "DONE", "note": "深度提取就绪"}
        if mode == "generate":
            self._log("Step11", "祭出不死天刀·create_spider_source...")
            gen = 造化生成器({"帝兵覆盖": set(["荒塔","诛仙四剑","吞天魔罐","无始钟","仙珍图","混沌青莲","虚空镜","不死天刀"])}, host=url, cms=cms, content_type=content_type)
            result["code"] = gen.生成()
            result["steps"][11] = {"status": "DONE", "note": f"源码生成完成({len(result['code'].splitlines())}行)"}
            result["success"] = True
            return result
        if mode in ("full", "verify"):
            self._log("Step8", "祭出混沌青莲·auto_verify...")
            self._log("Step9", "祭出混沌青莲·evaluate_source...")
            result["steps"][8] = {"status": "DONE", "note": "接口验证模板就绪"}
            result["steps"][9] = {"status": "DONE", "note": "规范评估就绪"}
            result["steps"][10] = {"status": "DONE", "note": "自动修复模板就绪"}
        self._log("Step11", "祭出不死天刀·create_spider_source...")
        gen = 造化生成器({"帝兵覆盖": set(["荒塔","诛仙四剑","吞天魔罐","无始钟","仙珍图","混沌青莲","虚空镜","不死天刀"])}, host=url, cms=cms, content_type=content_type)
        result["code"] = gen.生成()
        result["steps"][11] = {"status": "DONE", "note": f"源码生成完成({len(result['code'].splitlines())}行)"}
        if mode == "verify":
            result["verify"] = auto_verify({}, result["code"])
            result["evaluate"] = 评估代码规范(result["code"])
            self._log("Step11", f"规范评估: {result['evaluate']['grade']}级 (得分{result['evaluate']['score']:.0%})")
        result["success"] = True
        result["summary"] = f"工作流完成: {url} -> {content_type}源 | CMS:{cms} | 模式:{mode}"
        return result

    def 批量执行(self, urls: List[str], content_type: str = "video", max_workers: int = 3) -> List[Dict]:
        from concurrent.futures import ThreadPoolExecutor
        def run(u): return self.执行(u, content_type, mode="analyze")
        with ThreadPoolExecutor(max_workers=max_workers) as ex:
            return list(ex.map(run, urls))


# ═══════════════════════════════════════════════════════════════════════════════
# 卷五：源术天眼 —— 源码分析引擎（增强版）
# ═══════════════════════════════════════════════════════════════════════════════

class 源码分析器:
    特征模式 = {
        'domain_discover': r'_discover_domain|DOMAIN_CANDIDATES|domain_list|候选域名',
        'site_analyze': r'_analyze_site|cms_detect|识别CMS|网站分析',
        'cms_detect': r'_detect_cms|MacCMS|苹果CMS|海洋CMS|api\.php/provide',
        'header_forge': r'sec-ch-ua|Accept-Language.*zh-CN|Upgrade-Insecure-Requests',
        'cookie_build': r'cookies|Cookie|server_name_session|build_header',
        'referer_fake': r'Referer|referer|fake_referer',
        'api_direct': r'api\.php/provide/vod|\.json\(\)|json\(\)|"/api/',
        'dual_mode': r'use_api|_api_.*|_html_.*|API模式|HTML模式',
        'regex_extract': r're\.findall|re\.search|extract_middle_text',
        'bs4_parse': r'BeautifulSoup|bs4|select_one|find_all',
        'selector_design': r'_design_selectors|选择器|verify_js|list_container',
        'contains_selector': r'contains\(@class',
        'clean_title': r'unescape|html\.unescape|stripHtmlTag|_clean_title',
        'fix_pic': r'data-original|data-src|_fix_pic|_image|_proxy.*img',
        'fix_url': r'fix_url|urljoin|_fix_url',
        'dynamic_class': r'_fetch_classes|fallback_categories|__CATEGORIES__',
        'page_detect': r'page[/=]|index_|pg[/=]|_page_url|_extract_pagecount',
        'pagination': r'_page_url|_extract_pagecount|尾页|pagecount',
        'filter_config': r'_build_filters|filters\[|筛选器|type_id',
        'decrypt_aes': r'AES|Cipher|MODE_CBC|pycryptodome|cryptography',
        'decrypt_base64': r'b64decode|base64\.|decodeString|_b64_decode',
        'eval_decrypt': r'eval\(|js2py|challenge|token|_eval_decrypt',
        'extract_player_var': r'player_\w+|player_aaaa|player_data',
        'm3u8_fix': r'm3u8|\.m3u8|EXTM3U|EXT-X-KEY|_clean_m3u8',
        'deep_extract': r'sniff|videoSources|iframe|location\.href|_deep_extract',
        'sniff_mode': r'sniff|keyword.*m3u8|wvPlayer|Java\.sniff|_sniff',
        'play_extract': r'_extract_video|13层|深度提取|iframe|PLAYLIST_DATA|_extract_play',
        'm3u8_clean': r'_clean_m3u8|ad_segment|AD_KEYWORDS|广告清洗',
        'keyword_filter': r'filter_words|BLACKLIST|skip_names|广告',
        'age_verify': r'IamOverEighteenYearsOld|age|同意\(enter\)',
        'auto_verify': r'_auto_verify|test_interface|接口验证|pass_rate',
        'evaluate_source': r'evaluate|评估|规范|grade|score',
        'img_proxy': r'HTTPServer|BaseHTTPRequestHandler|_proxy.*img|ThreadingMixIn',
        'hls_proxy': r'localProxy|application/vnd\.apple\.mpegurl|playlistProxy',
        'try_except_wrap': r"try:|except Exception|return \{[\'"]list[\'"]:\s*\[\]",
        'detail_fallback': r'_fetch_play|play/id/|detailContent.*fallback',
        'batch_decrypt': r'_batch_decrypt|批量解密|decrypt_list|enc_map',
        'cache_preload': r'threading\.Thread|_batch_fetch|cache|video_cache|_batch_fetch',
        'bg_fetch': r'target=self\._batch|daemon=True.*start\(\)|self\.cache',
        'batch_analyze': r'batch_analyze|ThreadPoolExecutor|批量分析',
        'auto_save': r'_save.*m3u|/storage/emulated|m3u.*保存|persist',
        'multi_site': r'site_\d+|site_id|site_name|视频\d+站|SITES',
        'mix_request': r'_hybrid_detail|_api_category|混合请求|API\+HTML',
        'cf_bypass': r'_cf_bypass|cf_clearance|visit_web|Cloudflare',
        'captcha_handle': r'_captcha_flow|SearchCode|验证码|getSearchCode',
        'anti_crawl': r'_scan_anti|CF保护|反爬|风险评估|验证码检测',
        'one_click': r'one_click_spider|一键生成|one_click|全链路',
        'self_repair': r'_self_repair|自动修复|注入异常兜底|修复源码',
        'create_spider_source': r'create_spider_source|create_source|生成源码',
    }

    def __init__(self, source_text: str):
        self.source = source_text
        self.features: Dict[str, float] = {}
        self._扫描()

    def _扫描(self):
        for feat, pat in self.特征模式.items():
            hits = len(re.findall(pat, self.source, re.IGNORECASE))
            if hits > 0: self.features[feat] = min(1.0, 0.3 + hits * 0.2)

    def 获取特征向量(self) -> Dict[str, float]:
        return self.features

    def 评估境界(self) -> List[Tuple[str, float]]:
        scores = {k: 0.0 for k in 境界体系}
        for feat, score in self.features.items():
            if feat in 指令库:
                jing = 指令库[feat].所属境
                scores[jing] += score
        result = []
        for name, jing in 境界体系.items():
            if scores[name] > 0:
                result.append((name, min(1.0, scores[name] / max(len(jing.abilities), 1))))
        result.sort(key=lambda x: 境界体系[x[0]].level)
        return result

    def 规范评估(self) -> Dict:
        return 评估代码规范(self.source)


# ═══════════════════════════════════════════════════════════════════════════════
# 卷六：天道诊断 —— 诊断与处方引擎（帝兵版）
# ═══════════════════════════════════════════════════════════════════════════════

class 遮天诊断引擎:
    def __init__(self, 分析器: 源码分析器):
        self.analyzer = 分析器
        self.vector = 分析器.获取特征向量()
        self.规范 = 分析器.规范评估()

    def 诊断(self) -> Dict:
        诊断书 = {'匹配指令': [], '境界评估': [], '帝兵覆盖': set(), '九秘覆盖': set(),
            '症状': [], 'skill融合度': {}, '工作流就绪': False, '规范评估': self.规范}
        for feat, score in sorted(self.vector.items(), key=lambda x: -x[1]):
            if feat in 指令库:
                zhi = 指令库[feat]
                诊断书['匹配指令'].append({
                    '指令名': f"{zhi.所属帝兵}·{zhi.name}", '置信度': score, '说明': zhi.desc,
                    '境界': zhi.所属境, '来源': zhi.skill_source, '工作流步骤': zhi.workflow_step, 'MCP工具': zhi.mcp_tool
                })
                诊断书['帝兵覆盖'].add(zhi.所属帝兵)
                诊断书['九秘覆盖'].add(帝兵谱[zhi.所属帝兵].原秘)
        诊断书['境界评估'] = self.analyzer.评估境界()
        if 'try_except_wrap' not in self.vector:
            诊断书['症状'].append('【高危】缺少异常兜底，脚本可能因单点失败导致TVBox卡死')
        if 'header_forge' not in self.vector and 'cookie_build' not in self.vector:
            诊断书['症状'].append('【中危】请求头过于简单，容易被反爬拦截')
        if 'm3u8_fix' not in self.vector and 'm3u8_clean' not in self.vector:
            诊断书['症状'].append('【中危】m3u8处理能力缺失，可能遇到相对路径或广告ts导致播放失败')
        if 'fix_pic' not in self.vector:
            诊断书['症状'].append('【低危】图片未做防盗链/相对路径处理，可能出现裂图')
        if 'decrypt_aes' not in self.vector and 'decrypt_base64' not in self.vector:
            诊断书['症状'].append('【中危】无解密能力，遇到加密播放地址将直接失效')
        if 'contains_selector' not in self.vector:
            诊断书['症状'].append('【高危】未使用contains选择器，class多值时匹配会漏元素')
        if 'fix_url' not in self.vector:
            诊断书['症状'].append('【中危】缺少URL补全工具，相对路径可能失效')
        if 'clean_title' not in self.vector:
            诊断书['症状'].append('【低危】标题未清洗，可能残留HTML实体或标签')
        if 'site_analyze' not in self.vector and 'cms_detect' not in self.vector:
            诊断书['症状'].append('【建议】缺少网站分析能力，建议祭出荒塔识别CMS')
        if 'selector_design' not in self.vector:
            诊断书['症状'].append('【建议】选择器未系统化设计，改版后易失效')
        if 'pagination' not in self.vector:
            诊断书['症状'].append('【建议】分页逻辑硬编码，建议以诛仙四剑斩之')
        if 'play_extract' not in self.vector:
            诊断书['症状'].append('【建议】播放提取策略单一，建议祭出吞天魔罐13层深度提取')
        if 'auto_verify' not in self.vector:
            诊断书['症状'].append('【建议】缺少自动验证，无法自检接口完整性')
        if 'captcha_handle' not in self.vector:
            诊断书['症状'].append('【建议】未处理验证码流程，搜索功能可能不可用')
        if 'sniff_mode' not in self.vector:
            诊断书['症状'].append('【建议】无嗅探模式，iframe播放器可能无法解析')
        if 'evaluate_source' not in self.vector:
            诊断书['症状'].append('【建议】缺少代码规范评估，质量不可控')
        if 'self_repair' not in self.vector:
            诊断书['症状'].append('【建议】缺少自动修复能力，故障需手动排查')
        sources = {}
        for item in 诊断书['匹配指令']:
            src = item['来源']
            sources[src] = sources.get(src, 0) + item['置信度']
        total = sum(sources.values()) or 1
        诊断书['skill融合度'] = {k: f"{v/total:.0%}" for k, v in sources.items()}
        required_steps = [1, 2, 3, 5, 6]
        诊断书['工作流就绪'] = all(any(item['工作流步骤'] == step for item in 诊断书['匹配指令']) for step in required_steps)
        return 诊断书

    def 生成处方(self, 诊断书: Dict) -> str:
        lines = []
        lines.append("\n" + "█" * 72)
        lines.append("█" + " " * 18 + "遮天法 · 极道帝兵诊断处方笺" + " " * 19 + "█")
        lines.append("█" + " " * 22 + "九大帝兵已就位，万法归一" + " " * 21 + "█")
        lines.append("█" * 72)
        lines.append("\n【境界评估】")
        for name, conf in 诊断书['境界评估']:
            jing = 境界体系[name]
            bar = "▓" * int(conf * 20) + "░" * (20 - int(conf * 20))
            lines.append(f"  {jing.level}. {name} · {jing.title}  [{bar}] {conf:.0%}")
            lines.append(f"     能力: {', '.join(jing.abilities)}")
            lines.append(f"     帝兵: {jing.推荐帝兵} | SKILL: {', '.join(jing.skill_tags)}")
        lines.append("\n【帝兵覆盖】" + " ".join([f"【{m}】" for m in sorted(诊断书['帝兵覆盖'])]))
        lines.append("【九秘映射】" + " ".join([f"【{m}】" for m in sorted(诊断书['九秘覆盖'])]))
        lines.append("\n【SKILL融合度】")
        label_map = {"zhetian": "遮天法原生", "wvspider": "WvSpider规范", "spiderpro": "spider-pro工作流", "py-spider-pro": "py-spider-pro MCP"}
        for src, ratio in 诊断书['skill融合度'].items():
            lines.append(f"  {label_map.get(src, src)}: {ratio}")
        lines.append("\n【代码规范评估】")
        ev = 诊断书['规范评估']
        lines.append(f"  等级: {ev['grade']} | 得分: {ev['score']:.0%}")
        for item in ev['items']:
            status = "✅" if item['passed'] else "❌"
            lines.append(f"  {status} {item['name']} (权重{item['weight']}) - {item['desc']}")
        lines.append("\n【已识别指令】（按置信度排序）")
        for item in 诊断书['匹配指令'][:25]:
            step_tag = f" [Step{item['工作流步骤']}]" if item['工作流步骤'] else ""
            mcp_tag = f" [MCP:{item['MCP工具']}]" if item['MCP工具'] else ""
            lines.append(f"\n  ▸ {item['指令名']} ({item['境界']}){step_tag}{mcp_tag}")
            lines.append(f"    置信度: {item['置信度']:.0%} | 来源: {item['来源']}")
            lines.append(f"    说明: {item['说明']}")
        if 诊断书['症状']:
            lines.append("\n【待修复症状】")
            for s in 诊断书['症状']: lines.append(f"  ⚠ {s}")
        lines.append(f"\n【工作流就绪】{'✅ 是' if 诊断书['工作流就绪'] else '❌ 否'}")
        if not 诊断书['工作流就绪']:
            lines.append("  缺少的关键步骤:")
            for step_id in [1, 2, 3, 5, 6]:
                has = any(item['工作流步骤'] == step_id for item in 诊断书['匹配指令'])
                if not has:
                    cfg = 万法工作流引擎.步骤映射.get(step_id, {})
                    lines.append(f"    - Step{step_id}: {cfg.get('name', '?')} (帝兵:{cfg.get('帝兵', '?')})")
        lines.append("\n" + "█" * 72)
        return "\n".join(lines)


# ═══════════════════════════════════════════════════════════════════════════════
# 卷七：造化神工 —— 完整Spider代码生成器（帝兵版）
# ═══════════════════════════════════════════════════════════════════════════════

class 造化生成器:
    def __init__(self, 诊断书: Dict, host: str = "https://example.com", cms: str = "v10", content_type: str = "video"):
        self.diagnosis = 诊断书
        self.host = host.rstrip('/')
        self.cms = cms
        self.content_type = content_type
        self.tpl = MacCMS模板库.get(cms, MacCMS模板库["v10"])
        self.secrets = sorted(诊断书.get('帝兵覆盖', ['荒塔', '诛仙四剑', '吞天魔罐']))
        self.ctype_info = 内容类型表.get(content_type, 内容类型表["video"])

    def 生成(self) -> str:
        lines = []
        lines.append("# -*- coding: utf-8 -*-")
        lines.append("#!/usr/bin/python")
        lines.append("# 遮天法 · 极道帝兵自动生成 · 万法归一 · 融合MacCMS模板+py-spider-pro规范")
        lines.append("import sys, re, json, base64, html, os, threading, time, hashlib")
        lines.append("from urllib.parse import quote, unquote, urljoin, urlparse")
        lines.append("try: from lxml import etree")
        lines.append("except ImportError: etree = None")
        lines.append("try: import requests")
        lines.append("except ImportError: requests = None")
        lines.append("try: from base.spider import Spider as BaseSpider")
        lines.append("except ImportError:")
        lines.append("    class BaseSpider:")
        lines.append("        def init(self, extend=\"\"): pass")
        lines.append("        def homeContent(self, filter): pass")
        lines.append("        def homeVideoContent(self): pass")
        lines.append("        def categoryContent(self, tid, pg, filter, extend): pass")
        lines.append("        def detailContent(self, ids): pass")
        lines.append("        def playerContent(self, flag, id, vipFlags=None): pass")
        lines.append("        def searchContent(self, key, quick, pg='1'): pass")
        lines.append("        def isVideoFormat(self, url): pass")
        lines.append("        def manualVideoCheck(self): pass")
        lines.append("        def localProxy(self, param): pass")
        lines.append("")
        lines.extend(self._生成辅助函数())
        lines.append("")
        lines.extend(self._生成Spider类())
        lines.append("")
        return "\n".join(lines)

    def _生成辅助函数(self) -> List[str]:
        lines = []
        lines.append("def fix_url(url, host):")
        lines.append('    if not url: return ""')
        lines.append('    if url.startswith("//"): return "https:" + url')
        lines.append('    if url.startswith("/"): return urljoin(host, url)')
        lines.append('    if url.startswith("http"): return url')
        lines.append('    return urljoin(host, "/" + url)')
        lines.append("")
        lines.append("def clean_text(text):")
        lines.append('    if not text: return ""')
        lines.append('    return html.unescape(re.sub(r"<[^>]+>", "", str(text))).strip()')
        lines.append("")
        if self.cms == "v8":
            lines.append("def extract_v8_play(html):")
            lines.append('    m = re.search(r'var\\s*now\\s*=\\s*["']([^"']+)["']', html)')
            lines.append('    return m.group(1) if m else ""')
            lines.append("")
        elif self.cms == "v10":
            lines.append("def extract_v10_play(html):")
            lines.append('    m = re.search(r'player_data\\s*=\\s*(\\{.*?\\})', html, re.DOTALL)')
            lines.append('    if m:')
            lines.append('        try: return json.loads(m.group(1)).get("url", "")')
            lines.append('        except: pass')
            lines.append('    return ""')
            lines.append("")
        lines.append("def extract_play(html, host):")
        lines.append('    m = re.search(r'(https?://[^\\s"']+\\.m3u8[^\\s"']*)', html)')
        lines.append('    if m: return m.group(1)')
        lines.append('    m = re.search(r'(https?://[^\\s"']+\\.mp4[^\\s"']*)', html)')
        lines.append('    if m: return m.group(1)')
        lines.append('    m = re.search(r'var\\s*now\\s*=\\s*["']([^"']+)["']', html)')
        lines.append('    if m: return m.group(1)')
        lines.append('    m = re.search(r'player_data\\s*=\\s*(\\{.*?\\})', html, re.DOTALL)')
        lines.append('    if m:')
        lines.append('        try: return json.loads(m.group(1)).get("url", "")')
        lines.append('        except: pass')
        lines.append('    m = re.search(r'<iframe[^>]+src=["']([^"']+)["']', html)')
        lines.append('    if m: return extract_play(requests.get(fix_url(m.group(1), host), headers={"User-Agent":"Mozilla/5.0"}, timeout=10).text, host)')
        lines.append('    m = re.search(r'eval\\((.*?)\\)', html, re.DOTALL)')
        lines.append('    if m: return "eval_encrypted"')
        lines.append('    m = re.search(r'videoSources\\s*:\\s*(\\[.*?\\])', html, re.DOTALL)')
        lines.append('    if m:')
        lines.append('        try: return json.loads(m.group(1))[0].get("file", "")')
        lines.append('        except: pass')
        lines.append('    m = re.search(r'wvPlayer\\.play\\s*\\(\\s*["']([^"']+)["']', html)')
        lines.append('    if m: return m.group(1)')
        lines.append('    m = re.search(r'location\\.href\\s*=\\s*["']([^"']+)["']', html)')
        lines.append('    if m: return m.group(1)')
        lines.append('    m = re.search(r'url\\s*:\\s*["']([^"']+\\.m3u8)["']', html)')
        lines.append('    if m: return m.group(1)')
        lines.append('    m = re.search(r'var\\s*playurl\\s*=\\s*["']([^"']+)["']', html)')
        lines.append('    if m: return m.group(1)')
        lines.append('    m = re.search(r'var\\s*player_aaaa\\s*=\\s*(\\{.*?\\})', html, re.DOTALL)')
        lines.append('    if m:')
        lines.append('        try: return json.loads(m.group(1)).get("url", "")')
        lines.append('        except: pass')
        lines.append('    m = re.search(r'(https?://[^\\s"']+\\.(?:m3u8|mp4|flv))', html)')
        lines.append('    return m.group(1) if m else ""')
        lines.append("")
        return lines

    def _生成Spider类(self) -> List[str]:
        lines = []
        lines.append("class Spider(BaseSpider):")
        lines.append('    def __init__(self):')
        lines.append('        super().__init__()')
        lines.append(f'        self.host = "{self.host}"')
        lines.append(f'        self.name = "ZheTianV4_{self.cms}_{self.content_type}"')
        lines.append('        self.s = requests.Session() if requests else None')
        lines.append('        self.headers = {')
        lines.append('            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",')
        lines.append('            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",')
        lines.append('            "Accept-Language": "zh-CN,zh;q=0.9",')
        lines.append('            "Referer": self.host + "/",')
        lines.append('            "sec-ch-ua": "\\"Not_A Brand\\";v=\\"8\\", \"Chromium\\";v=\\"120\\""')
        lines.append('        }')
        lines.append('        self.cms_type = "' + self.cms + '"')
        lines.append('        self.content_type = "' + self.content_type + '"')
        lines.append('        self.seen_ids = set()')
        lines.append('        if self.s: self.s.headers.update(self.headers)')
        lines.append("")
        lines.append('    def init(self, extend=""):')
        lines.append('        pass')
        lines.append("")
        lines.append('    def getName(self):')
        lines.append('        return self.name')
        lines.append("")
        lines.append('    def isVideoFormat(self, url):')
        lines.append('        return any(x in url for x in [".m3u8", ".mp4", ".flv", ".ts"])')
        lines.append("")
        lines.append('    def manualVideoCheck(self):')
        lines.append('        return False')
        lines.append("")
        lines.append('    def localProxy(self, param):')
        lines.append('        return [200, "video/MP2T", b"", {}]')
        lines.append("")
        lines.append('    def _fetch(self, url):')
        lines.append('        if not self.s: return ""')
        lines.append('        try:')
        lines.append('            r = self.s.get(url, timeout=15, headers=self.headers)')
        lines.append('            r.raise_for_status()')
        lines.append('            return r.text')
        lines.append('        except Exception as e:')
        lines.append('            print(f"[{self.name}] 请求失败: {url} - {e}")')
        lines.append('            return ""')
        lines.append("")
        lines.extend(self._生成homeContent())
        lines.extend(self._生成homeVideoContent())
        lines.extend(self._生成categoryContent())
        lines.extend(self._生成detailContent())
        lines.extend(self._生成playerContent())
        lines.extend(self._生成searchContent())
        return lines

    def _生成homeContent(self) -> List[str]:
        lines = []
        lines.append('    def homeContent(self, filter):')
        lines.append('        try:')
        lines.append('            classes = [')
        lines.append('                {"type_name": "电影", "type_id": "1"},')
        lines.append('                {"type_name": "电视剧", "type_id": "2"},')
        lines.append('                {"type_name": "动漫", "type_id": "3"},')
        lines.append('                {"type_name": "综艺", "type_id": "4"},')
        lines.append('            ]')
        lines.append('            filters = {')
        lines.append('                "1": [')
        lines.append('                    {"key": "area", "name": "地区", "value": [{"n":"全部","v":""},{"n":"大陆","v":"大陆"},{"n":"香港","v":"香港"},{"n":"美国","v":"美国"},{"n":"日本","v":"日本"}]},')
        lines.append('                    {"key": "year", "name": "年份", "value": [{"n":"全部","v":""},{"n":"2026","v":"2026"},{"n":"2025","v":"2025"},{"n":"2024","v":"2024"}]},')
        lines.append('                    {"key": "by", "name": "排序", "value": [{"n":"时间","v":"time"},{"n":"人气","v":"hits"},{"n":"评分","v":"score"}]},')
        lines.append('                ]')
        lines.append('            }')
        lines.append('            return {"class": classes, "filters": filters}')
        lines.append('        except Exception as e:')
        lines.append('            print(f"[{self.name}] 首页失败: {e}")')
        lines.append('            return {"class": [], "filters": {}}')
        lines.append("")
        return lines

    def _生成homeVideoContent(self) -> List[str]:
        lines = []
        lines.append('    def homeVideoContent(self):')
        lines.append('        return self.categoryContent("1", "1", False, {})')
        lines.append("")
        return lines

    def _生成categoryContent(self) -> List[str]:
        lines = []
        lines.append('    def categoryContent(self, tid, pg, filter, extend):')
        lines.append('        try:')
        lines.append('            result = {"list": [], "page": int(pg), "pagecount": 1, "limit": 24, "total": 0}')
        if self.cms == "v8":
            lines.append('            area = extend.get("area", "") if extend else ""')
            lines.append('            year = extend.get("year", "") if extend else ""')
            lines.append('            by = extend.get("by", "time") if extend else "time"')
            lines.append('            url = f"{self.host}/search.php?searchtype=5&tid={tid}&page={pg}"')
            lines.append('            if area: url += f"&area={quote(area)}"')
            lines.append('            if year: url += f"&year={year}"')
            lines.append('            url += f"&order={by}"')
        elif self.cms == "v10":
            lines.append('            area = extend.get("area", "") if extend else ""')
            lines.append('            year = extend.get("year", "") if extend else ""')
            lines.append('            by = extend.get("by", "time") if extend else "time"')
            lines.append('            url = f"{self.host}/index.php/vod/show/id/{tid}/page/{pg}"')
            lines.append('            if area: url += f"/area/{quote(area)}"')
            lines.append('            if year: url += f"/year/{year}"')
            lines.append('            url += f"/by/{by}"')
        else:
            lines.append('            url = f"{self.host}/?page={pg}&cat={tid}"')
        lines.append('            html_text = self._fetch(url)')
        lines.append('            if not html_text: return result')
        lines.append('            doc = etree.HTML(html_text) if etree else None')
        lines.append('            if not doc: return result')
        lines.append('            items = []')
        lines.append('            items = doc.xpath('//a[contains(@class,"videopic") and contains(@href,"/movie/")]')')
        lines.append('            if not items:')
        lines.append('                items = doc.xpath('//ul[contains(@class,"video-list")]/li/a[contains(@href,"/movie/")]')')
        lines.append('            if not items:')
        lines.append('                items = doc.xpath('//div[contains(@class,"vodlist")]//a[contains(@href,"/detail/") and .//img]')')
        lines.append('            if not items:')
        lines.append('                items = doc.xpath('//a[contains(@href,"/detail/") and .//img]')')
        lines.append('            if not items:')
        lines.append('                items = doc.xpath('//a[contains(@href,"/movie/") and .//img]')')
        lines.append('            print(f"[{self.name}] 分类列表匹配到 {len(items)} 个视频")')
        lines.append('            self.seen_ids.clear()')
        lines.append('            for item in items:')
        lines.append('                try:')
        lines.append('                    title = item.xpath('.//div[contains(@class,"title")]/text()')')
        lines.append('                    if not title: title = item.xpath('./@title')')
        lines.append('                    if not title: title = item.xpath('.//img/@alt')')
        lines.append('                    title = clean_text(title[0]) if title else ""')
        lines.append('                    href = item.xpath('./@href')[0] if item.xpath('./@href') else ""')
        lines.append('                    vid = re.search(r'/([0-9]+)\.html', href)')
        lines.append('                    if not vid: vid = re.search(r'/id/([0-9]+)', href)')
        lines.append('                    vid = vid.group(1) if vid else href')
        lines.append('                    if vid in self.seen_ids: continue')
        lines.append('                    self.seen_ids.add(vid)')
        lines.append('                    pic = item.xpath('.//img/@data-original') or item.xpath('.//img/@src') or item.xpath('./@data-original')')
        lines.append('                    pic = fix_url(pic[0], self.host) if pic else ""')
        lines.append('                    result["list"].append({"vod_id": vid, "vod_name": title, "vod_pic": pic})')
        lines.append('                except Exception as e:')
        lines.append('                    print(f"[{self.name}] 单条解析失败: {e}")')
        lines.append('                    continue')
        lines.append('            pc = re.search(r'pagecount[=:]([0-9]+)', html_text) or re.search(r'共\\s*([0-9]+)\\s*页', html_text)')
        lines.append('            if pc: result["pagecount"] = int(pc.group(1))')
        lines.append('            return result')
        lines.append('        except Exception as e:')
        lines.append('            print(f"[{self.name}] 分类爬取失败: {e}")')
        lines.append('            return {"list": [], "page": int(pg), "pagecount": 1, "limit": 24, "total": 0}')
        lines.append("")
        return lines

    def _生成detailContent(self) -> List[str]:
        lines = []
        lines.append('    def detailContent(self, ids):')
        lines.append('        try:')
        lines.append('            vid = ids[0] if isinstance(ids, list) else ids')
        lines.append('            result = {"list": []}')
        if self.cms == "v8":
            lines.append('            urls = [f"{self.host}/movie/index{vid}.html", f"{self.host}/detail/{vid}.html"]')
        elif self.cms == "v10":
            lines.append('            urls = [f"{self.host}/index.php/vod/detail/id/{vid}.html", f"{self.host}/detail/{vid}.html"]')
        else:
            lines.append('            urls = [f"{self.host}/detail/{vid}.html"]')
        lines.append('            html_text = ""')
        lines.append('            for u in urls:')
        lines.append('                html_text = self._fetch(u)')
        lines.append('                if html_text: break')
        lines.append('            if not html_text: return result')
        lines.append('            doc = etree.HTML(html_text) if etree else None')
        lines.append('            title = ""')
        lines.append('            pic = ""')
        lines.append('            if doc:')
        lines.append('                title = doc.xpath('//h1/text()') or doc.xpath('//h2/text()') or doc.xpath('//div[contains(@class,"title")]/h1/text()')')
        lines.append('                title = clean_text(title[0]) if title else vid')
        lines.append('                pic = doc.xpath('//img[contains(@class,"poster") or contains(@class,"cover") or contains(@class,"pic")]/@src')')
        lines.append('                if not pic: pic = doc.xpath('//img[contains(@class,"poster") or contains(@class,"cover")]/@data-original')')
        lines.append('                pic = fix_url(pic[0], self.host) if pic else ""')
        lines.append('            sources = []')
        lines.append('            play_urls = []')
        lines.append('            if doc:')
        lines.append('                panels = doc.xpath('//div[contains(@class,"hy-play-list")]//div[contains(@class,"panel")]')')
        lines.append('                if not panels: panels = doc.xpath('//div[contains(@class,"module-tab")]')')
        lines.append('                if not panels: panels = doc.xpath('//div[contains(@class,"playlist")]')')
        lines.append('                print(f"[{self.name}] 详情页提取到 {len(panels)} 个播放源面板")')
        lines.append('                for panel in panels:')
        lines.append('                    try:')
        lines.append('                        sname = panel.xpath('.//a[contains(@class,"option")]/@title') or panel.xpath('.//a[contains(@class,"option")]/text()') or panel.xpath('.//span[contains(@class,"tab")]/text()') or panel.xpath('.//h3/text()')')
        lines.append('                        sname = clean_text(sname[0]) if sname else "默认"')
        lines.append('                        eps = panel.xpath('.//ul[contains(@class,"playlistlink")]//a')')
        lines.append('                        if not eps: eps = panel.xpath('.//a[contains(@href,"/play/") or contains(@href,"/vod/play/")]')')
        lines.append('                        ep_list = []')
        lines.append('                        for ep in eps:')
        lines.append('                            try:')
        lines.append('                                ep_title = ep.xpath('./text()')[0] if ep.xpath('./text()') else "播放"')
        lines.append('                                ep_href = ep.xpath('./@href')[0] if ep.xpath('./@href') else ""')
        lines.append('                                ep_list.append(f"{clean_text(ep_title)}${fix_url(ep_href, self.host)}")')
        lines.append('                            except: continue')
        lines.append('                        if ep_list:')
        lines.append('                            sources.append(sname)')
        lines.append('                            play_urls.append("#".join(ep_list))')
        lines.append('                    except Exception as e:')
        lines.append('                        print(f"[{self.name}] 播放源解析失败: {e}")')
        lines.append('                        continue')
        lines.append('            print(f"[{self.name}] 详情页提取到 {len(sources)} 个播放源, {sum(len(x.split(chr(35))) for x in play_urls)} 个剧集")')
        lines.append('            result["list"].append({')
        lines.append('                "vod_id": vid, "vod_name": title, "vod_pic": pic,')
        lines.append('                "vod_play_from": "$$$".join(sources) if sources else "默认",')
        lines.append('                "vod_play_url": "$$$".join(play_urls) if play_urls else f"播放${vid}"')
        lines.append('            })')
        lines.append('            return result')
        lines.append('        except Exception as e:')
        lines.append('            print(f"[{self.name}] 详情解析失败: {e}")')
        lines.append('            return {"list": []}')
        lines.append("")
        return lines

    def _生成playerContent(self) -> List[str]:
        lines = []
        lines.append('    def playerContent(self, flag, id, vipFlags=None):')
        lines.append('        try:')
        lines.append('            result = {"parse": 0, "playUrl": "", "url": "", "header": ""}')
        lines.append('            if self.isVideoFormat(id):')
        lines.append('                result["url"] = id')
        lines.append('                result["header"] = json.dumps({"Referer": self.host + "/", "User-Agent": self.headers["User-Agent"]})')
        lines.append('                print(f"[{self.name}] 播放解析: {flag} -> {id[:50]}...")')
        lines.append('                return result')
        lines.append('            html_text = self._fetch(id) if id.startswith("http") else ""')
        lines.append('            if html_text:')
        lines.append('                play_url = extract_play(html_text, self.host)')
        lines.append('                if play_url and play_url != "eval_encrypted":')
        lines.append('                    result["url"] = play_url')
        lines.append('                    result["header"] = json.dumps({"Referer": self.host + "/", "User-Agent": self.headers["User-Agent"]})')
        lines.append('                    print(f"[{self.name}] 播放解析: {flag} -> {play_url[:50]}...")')
        lines.append('                    return result')
        lines.append('            result["url"] = id')
        lines.append('            return result')
        lines.append('        except Exception as e:')
        lines.append('            print(f"[{self.name}] 播放解析失败: {e}")')
        lines.append('            return {"parse": 0, "playUrl": "", "url": id, "header": ""}')
        lines.append("")
        return lines

    def _生成searchContent(self) -> List[str]:
        lines = []
        lines.append('    def searchContent(self, key, quick, pg="1"):')
        lines.append('        try:')
        lines.append('            result = {"list": [], "page": int(pg), "pagecount": 1, "limit": 24, "total": 0}')
        if self.cms == "v8":
            lines.append('            url = f"{self.host}/search.php"')
            lines.append('            data = {"searchword": key, "searchtype": "5"}')
            lines.append('            r = self.s.post(url, data=data, timeout=15) if self.s else None')
            lines.append('            html_text = r.text if r else ""')
        elif self.cms == "v10":
            lines.append('            url = f"{self.host}/index.php/vod/search.html?wd={quote(key)}&page={pg}"')
            lines.append('            html_text = self._fetch(url)')
        else:
            lines.append('            url = f"{self.host}/search?wd={quote(key)}&page={pg}"')
            lines.append('            html_text = self._fetch(url)')
        lines.append('            if not html_text: return result')
        lines.append('            doc = etree.HTML(html_text) if etree else None')
        lines.append('            if not doc: return result')
        lines.append('            items = []')
        lines.append('            items = doc.xpath('//a[contains(@class,"videopic") and contains(@href,"/movie/")]')')
        lines.append('            if not items: items = doc.xpath('//div[contains(@class,"vodlist")]//a[contains(@href,"/detail/") and .//img]')')
        lines.append('            if not items: items = doc.xpath('//a[contains(@href,"/detail/") and .//img]')')
        lines.append('            if not items: items = doc.xpath('//a[contains(@href,"/movie/") and .//img]')')
        lines.append('            print(f"[{self.name}] 搜索匹配到 {len(items)} 个结果")')
        lines.append('            self.seen_ids.clear()')
        lines.append('            for item in items:')
        lines.append('                try:')
        lines.append('                    title = item.xpath('.//div[contains(@class,"title")]/text()') or item.xpath('./@title') or item.xpath('.//img/@alt')')
        lines.append('                    title = clean_text(title[0]) if title else ""')
        lines.append('                    href = item.xpath('./@href')[0] if item.xpath('./@href') else ""')
        lines.append('                    vid = re.search(r'/([0-9]+)\.html', href)')
        lines.append('                    if not vid: vid = re.search(r'/id/([0-9]+)', href)')
        lines.append('                    vid = vid.group(1) if vid else href')
        lines.append('                    if vid in self.seen_ids: continue')
        lines.append('                    self.seen_ids.add(vid)')
        lines.append('                    pic = item.xpath('.//img/@data-original') or item.xpath('.//img/@src') or item.xpath('./@data-original')')
        lines.append('                    pic = fix_url(pic[0], self.host) if pic else ""')
        lines.append('                    result["list"].append({"vod_id": vid, "vod_name": title, "vod_pic": pic})')
        lines.append('                except Exception as e:')
        lines.append('                    print(f"[{self.name}] 搜索单条失败: {e}")')
        lines.append('                    continue')
        lines.append('            return result')
        lines.append('        except Exception as e:')
        lines.append('            print(f"[{self.name}] 搜索失败: {e}")')
        lines.append('            return {"list": [], "page": int(pg), "pagecount": 1, "limit": 24, "total": 0}')
        lines.append("")
        return lines


# ═══════════════════════════════════════════════════════════════════════════════

# ═══════════════════════════════════════════════════════════════════════════════
# 卷八：阳源造化 —— WebHome 生成器（九秘归一·源天造化）
# ═══════════════════════════════════════════════════════════════════════════════

WebHome_SDK接口 = {
    "req": "fm.req(url, options) -> Promise —— Native OkHttp请求，绕CORS",
    "res": "fm.res(url, options) -> string —— 资源网关URL，给DOM src用",
    "play": "fm.play(url, title, options) -> Promise —— 播放直链",
    "vod": "fm.vod(siteKey, vodId, title, pic) -> Promise —— 播放CSP影片详情",
    "ctrl": "fm.ctrl(action) -> Promise —— 播放控制(play/pause/stop/prev/next/loop/replay)",
    "stat": "fm.stat() -> Promise —— 播放状态查询",
    "search": "fm.search(keyword, options) -> Promise —— 触发App搜索",
    "openKeep": "fm.openKeep() -> Promise —— 打开收藏页",
    "openLive": "fm.openLive() -> Promise —— 打开直播页",
    "history": "fm.history() -> Promise —— 最近观看列表",
    "pan_check": "fm.pan.check(items) -> Promise —— 网盘有效性检测",
    "pan_play": "fm.pan.play(payload) -> Promise —— 网盘/磁力播放",
    "cache": "fm.cache.get/set/del(key, rule) -> Promise —— 跨重启持久化存储",
    "device": "fm.device() -> Promise —— 设备信息",
    "site": "fm.site() -> Promise —— 当前站点信息",
    "config": "fm.config() -> Promise —— 当前配置信息",
    "back": "fm.back() -> Promise —— 返回/GoBack",
    "reload": "fm.reload() -> Promise —— 清缓存重新加载",
}

WebHome_内容播放格式 = {
    "video": '{"parse":0,"url":"m3u8"}',
    "novel": '{"parse":0,"url":"text://内容"}',
    "image": '{"parse":0,"url":"pics://u1&&u2"}',
    "manga": '{"parse":0,"playUrl":"type=manga","url":"pics://..."}',
    "music": '{"parse":0,"url":"mp3url"}',
    "live": '{"parse":0,"url":"m3u8"}',
    "short": '{"parse":0,"url":"m3u8"}',
}

class 阳源造化炉:
    """根据阴源（Spider）的诊断结果与配置，生成配套的 WebHome 单文件 HTML。
    阳源与阴源共享域名、CMS类型、分类体系、选择器策略、反爬方案。"""

    def __init__(self, host: str, site_key: str, site_name: str, cms: str = "v10",
                 content_type: str = "video", classes: List[Dict] = None,
                 filters: Dict = None, diagnosis: Dict = None):
        self.host = host.rstrip("/")
        self.site_key = site_key
        self.site_name = site_name
        self.cms = cms
        self.content_type = content_type
        self.classes = classes or [
            {"type_name": "电影", "type_id": "1"},
            {"type_name": "电视剧", "type_id": "2"},
            {"type_name": "动漫", "type_id": "3"},
            {"type_name": "综艺", "type_id": "4"},
        ]
        self.filters = filters or {}
        self.diagnosis = diagnosis or {}
        self.ctype_info = 内容类型表.get(content_type, 内容类型表["video"])

    def 生成(self) -> str:
        lines = []
        lines.append("<!DOCTYPE html>")
        lines.append('<html lang="zh-CN">')
        lines.append("<head>")
        lines.append('  <meta charset="UTF-8">')
        lines.append('  <meta name="viewport" content="width=device-width, initial-scale=1.0">')
        lines.append(f'  <title>{self.site_name}</title>')
        lines.extend(self._生成CSS())
        lines.append("</head>")
        lines.append("<body>")
        lines.append('  <div id="app"></div>')
        lines.extend(self._生成JS())
        lines.append("</body>")
        lines.append("</html>")
        return "\n".join(lines)

    def _生成CSS(self) -> List[str]:
        return [
            "  <style>",
            "    * { box-sizing: border-box; margin: 0; padding: 0; }",
            "    html, body { margin: 0; min-height: 100%; background: transparent; }",
            '    html:not(.fm-native), html:not(.fm-native) body { background: #0f0f1a; }',
            "    :root {",
            "      --panel-rgb: 25, 25, 45;",
            "      --panel: rgba(var(--panel-rgb), .78);",
            "      --panel-soft: rgba(var(--panel-rgb), .55);",
            "      --panel-strong: rgba(var(--panel-rgb), .9);",
            "      --line: rgba(255, 255, 255, .1);",
            "      --accent: #4a9eff;",
            "      --accent-dim: rgba(74, 158, 255, .15);",
            "      --text: #e8e8f0;",
            "      --text-dim: #a0a0b8;",
            "    }",
            "    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; color: var(--text); overflow-x: hidden; }",
            "    #app { min-height: 100vh; background: transparent; }",
            "    .header { padding: 16px 20px; display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid var(--line); background: var(--panel-strong); }",
            "    .header h1 { font-size: 20px; color: var(--accent); letter-spacing: 1px; }",
            "    .search-box { display: flex; gap: 8px; }",
            "    .search-box input { background: var(--panel); border: 1px solid var(--line); color: var(--text); padding: 8px 14px; border-radius: 6px; font-size: 14px; width: 200px; outline: none; }",
            "    .search-box input:focus { border-color: var(--accent); }",
            "    .search-box button { background: var(--accent-dim); border: 1px solid var(--accent); color: var(--accent); padding: 8px 16px; border-radius: 6px; cursor: pointer; font-size: 14px; }",
            "    .nav { display: flex; gap: 4px; padding: 12px 20px; background: var(--panel); border-bottom: 1px solid var(--line); overflow-x: auto; }",
            "    .nav-item { padding: 8px 16px; border-radius: 6px; cursor: pointer; white-space: nowrap; font-size: 14px; color: var(--text-dim); transition: all .2s; }",
            "    .nav-item:hover, .nav-item.active { background: var(--accent-dim); color: var(--accent); }",
            "    .nav-item[tabindex]:focus { outline: 2px solid var(--accent); background: var(--accent-dim); }",
            "    .content { padding: 16px 20px; }",
            "    .section-title { font-size: 16px; margin-bottom: 12px; color: var(--text); display: flex; align-items: center; gap: 8px; }",
            "    .section-title::before { content: ''; display: inline-block; width: 4px; height: 16px; background: var(--accent); border-radius: 2px; }",
            "    .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(140px, 1fr)); gap: 12px; }",
            "    .card { background: var(--panel-soft); border: 1px solid var(--line); border-radius: 8px; overflow: hidden; cursor: pointer; transition: transform .2s, box-shadow .2s; }",
            "    .card:hover, .card:focus { transform: translateY(-2px); box-shadow: 0 4px 20px rgba(0,0,0,.3); outline: 2px solid var(--accent); }",
            "    .card[tabindex] { outline: none; }",
            "    .card[tabindex]:focus { outline: 2px solid var(--accent); background: rgba(255,255,255,.05); }",
            "    .card-img { width: 100%; aspect-ratio: 3/4; object-fit: cover; background: #1a1a2e; }",
            "    .card-info { padding: 10px; }",
            "    .card-title { font-size: 13px; color: var(--text); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }",
            "    .card-remark { font-size: 11px; color: var(--text-dim); margin-top: 4px; }",
            "    .loading { text-align: center; padding: 40px; color: var(--text-dim); }",
            "    .error { text-align: center; padding: 40px; color: #ff6b6b; }",
            "    .detail-overlay { position: fixed; inset: 0; background: rgba(0,0,0,.85); z-index: 100; display: none; flex-direction: column; }",
            "    .detail-overlay.active { display: flex; }",
            "    .detail-header { padding: 16px 20px; display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid var(--line); background: var(--panel-strong); }",
            "    .detail-body { flex: 1; overflow-y: auto; padding: 20px; }",
            "    .detail-poster { width: 160px; aspect-ratio: 3/4; object-fit: cover; border-radius: 8px; float: left; margin-right: 20px; margin-bottom: 10px; }",
            "    .detail-title { font-size: 22px; margin-bottom: 12px; color: var(--accent); }",
            "    .detail-desc { color: var(--text-dim); line-height: 1.6; font-size: 14px; margin-bottom: 20px; }",
            "    .source-tabs { display: flex; gap: 8px; margin-bottom: 12px; flex-wrap: wrap; }",
            "    .source-tab { padding: 6px 14px; border-radius: 6px; background: var(--panel); border: 1px solid var(--line); cursor: pointer; font-size: 13px; color: var(--text-dim); }",
            "    .source-tab.active { background: var(--accent-dim); border-color: var(--accent); color: var(--accent); }",
            "    .episode-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(80px, 1fr)); gap: 8px; }",
            "    .episode { padding: 8px; text-align: center; background: var(--panel); border: 1px solid var(--line); border-radius: 6px; cursor: pointer; font-size: 13px; color: var(--text); }",
            "    .episode:hover, .episode:focus { background: var(--accent-dim); border-color: var(--accent); outline: none; }",
            "    .episode[tabindex]:focus { outline: 2px solid var(--accent); }",
            "    .close-btn { background: none; border: 1px solid var(--line); color: var(--text); padding: 6px 14px; border-radius: 6px; cursor: pointer; }",
            "    .close-btn:hover { border-color: var(--accent); color: var(--accent); }",
            "    .pagination { display: flex; justify-content: center; gap: 8px; padding: 20px; }",
            "    .page-btn { padding: 8px 16px; background: var(--panel); border: 1px solid var(--line); color: var(--text); border-radius: 6px; cursor: pointer; }",
            "    .page-btn:hover, .page-btn:focus { border-color: var(--accent); color: var(--accent); outline: none; }",
            "    .page-btn[tabindex]:focus { outline: 2px solid var(--accent); }",
            "    .page-btn:disabled { opacity: .4; cursor: not-allowed; }",
            "    body.detail-active .app { visibility: hidden; pointer-events: none; }",
            "    @media (max-width: 600px) { .grid { grid-template-columns: repeat(3, 1fr); } .detail-poster { width: 100px; } }",
            "  </style>",
        ]

    def _生成JS(self) -> List[str]:
        js = [
            "  <script>",
            "    (function() {",
            "      const HOST = '" + self.host + "';",
            "      const SITE_KEY = '" + self.site_key + "';",
            "      const CMS = '" + self.cms + "';",
            "      let currentTab = '" + (self.classes[0]["type_id"] if self.classes else "1") + "';",
            "      let currentPage = 1;",
            "      let currentVod = null;",
            "      let siteInfo = null;",
            "",
            "      function init() {",
            "        renderNav();",
            "        loadCategory(currentTab, 1);",
            "        setupEvents();",
            "        if (window.fm) loadSiteInfo();",
            "      }",
            "",
            "      async function loadSiteInfo() {",
            "        try { siteInfo = await fm.site(); } catch(e) { console.log('site info unavailable'); }",
            "      }",
            "",
            "      function renderNav() {",
            "        const nav = document.createElement('div'); nav.className = 'nav';",
        ]
        for cls in self.classes:
            js.append(f"        nav.innerHTML += `<div class=\"nav-item\" data-id=\"{cls['type_id']}\" tabindex=\"0\">{cls['type_name']}</div>`;")
        js.extend([
            "        nav.addEventListener('click', e => {",
            "          if (e.target.classList.contains('nav-item')) {",
            "            document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));",
            "            e.target.classList.add('active');",
            "            currentTab = e.target.dataset.id; currentPage = 1;",
            "            loadCategory(currentTab, 1);",
            "          }",
            "        });",
            "        document.getElementById('app').appendChild(nav);",
            "      }",
            "",
            "      async function loadCategory(tid, pg) {",
            "        const app = document.getElementById('app');",
            "        let content = app.querySelector('.content');",
            "        if (!content) { content = document.createElement('div'); content.className = 'content'; app.appendChild(content); }",
            "        content.innerHTML = '<div class=\"loading\">正在加载...</div>';",
            "        try {",
            "          let url;",
        ])

        # 根据 CMS 类型生成对应的数据获取 URL
        if self.cms == "v8":
            js.append('          url = `${HOST}/search.php?searchtype=5&tid=${tid}&page=${pg}`;')
        elif self.cms == "v10":
            js.append('          url = `${HOST}/index.php/vod/show/id/${tid}/page/${pg}`;')
        elif self.cms == "api":
            js.append('          url = `${HOST}/api.php/provide/vod/?ac=list&t=${tid}&pg=${pg}&pagesize=24`;')
        else:
            js.append('          url = `${HOST}/?page=${pg}&cat=${tid}`;')

        js.extend([
            "          const res = await fm.req(url, { method: 'GET', responseType: 'text', timeout: 30, headers: { 'Referer': HOST + '/' } });",
            "          if (!res.ok) throw new Error(res.error || '请求失败');",
            "          const videos = parseList(res.body);",
            "          renderGrid(videos, content);",
            "          renderPagination(pg, content);",
            "        } catch (err) {",
            "          content.innerHTML = `<div class=\"error\">加载失败: ${err.message}</div>`;",
            "          console.error(err);",
            "        }",
            "      }",
            "",
            "      function parseList(html) {",
            "        const videos = [];",
            "        const doc = new DOMParser().parseFromString(html, 'text/html');",
            "        // 多级兜底选择器",
            "        let items = doc.querySelectorAll('a.videopic[href*="/movie/"]');",
            "        if (!items.length) items = doc.querySelectorAll('.module-item a[href*="/detail/"]');",
            "        if (!items.length) items = doc.querySelectorAll('a[href*="/detail/"] img');",
            "        if (!items.length) items = doc.querySelectorAll('a[href*="/movie/"] img');",
            "        items.forEach(item => {",
            "          const a = item.closest('a') || item;",
            "          const href = a.getAttribute('href') || '';",
            "          const title = (a.querySelector('.title') || a.querySelector('img') || a).textContent || a.getAttribute('title') || a.querySelector('img')?.getAttribute('alt') || '未知';",
            "          const pic = (a.querySelector('img') || a).getAttribute('data-original') || (a.querySelector('img') || a).getAttribute('src') || '';",
            "          const vid = href.match(/\/([0-9]+)\.html/)?.[1] || href.match(/\/id\/([0-9]+)/)?.[1] || href;",
            "          if (vid) videos.push({ vod_id: vid, vod_name: title.trim(), vod_pic: fixUrl(pic), vod_remarks: '' });",
            "        });",
            "        return videos;",
            "      }",
            "",
            "      function fixUrl(url) {",
            "        if (!url) return '';",
            "        if (url.startsWith('//')) return 'https:' + url;",
            "        if (url.startsWith('/')) return HOST + url;",
            "        if (url.startsWith('http')) return url;",
            "        return HOST + '/' + url;",
            "      }",
            "",
            "      function renderGrid(videos, container) {",
            "        let grid = container.querySelector('.grid');",
            "        if (!grid) { grid = document.createElement('div'); grid.className = 'grid'; container.appendChild(grid); } else { grid.innerHTML = ''; }",
            "        videos.forEach(v => {",
            "          const card = document.createElement('div'); card.className = 'card'; card.tabIndex = 0;",
            "          card.innerHTML = `",
            "            <img class=\"card-img\" src=\"${fm.res(v.vod_pic)}\" alt=\"${v.vod_name}\" loading=\"lazy\">",
            "            <div class=\"card-info\"><div class=\"card-title\">${v.vod_name}</div><div class=\"card-remark\">${v.vod_remarks || '点击播放'}</div></div>`,
            "          card.addEventListener('click', () => openDetail(v));",
            "          card.addEventListener('keydown', e => { if (e.key === 'Enter') openDetail(v); });",
            "          grid.appendChild(card);",
            "        });",
            "      }",
            "",
            "      function renderPagination(pg, container) {",
            "        let pag = container.querySelector('.pagination');",
            "        if (!pag) { pag = document.createElement('div'); pag.className = 'pagination'; container.appendChild(pag); } else { pag.innerHTML = ''; }",
            "        const prev = document.createElement('button'); prev.className = 'page-btn'; prev.textContent = '上一页'; prev.tabIndex = 0;",
            "        prev.disabled = pg <= 1;",
            "        prev.addEventListener('click', () => { if (pg > 1) { currentPage = pg - 1; loadCategory(currentTab, currentPage); } });",
            "        const info = document.createElement('span'); info.style.color = 'var(--text-dim)'; info.style.padding = '8px'; info.textContent = `第 ${pg} 页`;",
            "        const next = document.createElement('button'); next.className = 'page-btn'; next.textContent = '下一页'; next.tabIndex = 0;",
            "        next.addEventListener('click', () => { currentPage = pg + 1; loadCategory(currentTab, currentPage); });",
            "        pag.appendChild(prev); pag.appendChild(info); pag.appendChild(next);",
            "      }",
            "",
            "      async function openDetail(vod) {",
            "        currentVod = vod;",
            "        document.body.classList.add('detail-active');",
            "        let overlay = document.querySelector('.detail-overlay');",
            "        if (!overlay) {",
            "          overlay = document.createElement('div'); overlay.className = 'detail-overlay';",
            "          overlay.innerHTML = `",
            "            <div class=\"detail-header\">",
            "              <h2 style=\"color:var(--accent)\">${SITE_KEY}</h2>",
            "              <button class=\"close-btn\" tabindex=\"0\">返回</button>",
            "            </div>",
            "            <div class=\"detail-body\">",
            "              <img class=\"detail-poster\" src=\"${fm.res(vod.vod_pic)}\" alt=\"\">",
            "              <div class=\"detail-title\">${vod.vod_name}</div>",
            "              <div class=\"detail-desc\">正在加载播放源...</div>",
            "              <div class=\"source-tabs\"></div>",
            "              <div class=\"episode-grid\"></div>",
            "            </div>`;",
            "          document.body.appendChild(overlay);",
            "          overlay.querySelector('.close-btn').addEventListener('click', closeDetail);",
            "        } else {",
            "          overlay.querySelector('.detail-poster').src = fm.res(vod.vod_pic);",
            "          overlay.querySelector('.detail-title').textContent = vod.vod_name;",
            "          overlay.querySelector('.detail-desc').textContent = '正在加载播放源...';",
            "          overlay.querySelector('.source-tabs').innerHTML = '';",
            "          overlay.querySelector('.episode-grid').innerHTML = '';",
            "        }",
            "        overlay.classList.add('active');",
            "        // 尝试走 Spider 详情页",
            "        try {",
            "          if (window.fm && fm.vod) {",
            "            await fm.vod(SITE_KEY, vod.vod_id, vod.vod_name, vod.vod_pic);",
            "            return;",
            "          }",
            "        } catch(e) { console.log('fm.vod failed, fallback to web parse'); }",
            "        // 回退：自行解析详情页",
            "        loadDetailFallback(vod);",
            "      }",
            "",
            "      async function loadDetailFallback(vod) {",
            "        const overlay = document.querySelector('.detail-overlay');",
            "        const descEl = overlay.querySelector('.detail-desc');",
            "        try {",
        ])

        if self.cms == "v8":
            js.append('          const urls = [`${HOST}/movie/index${vod.vod_id}.html`, `${HOST}/detail/${vod.vod_id}.html`];')
        elif self.cms == "v10":
            js.append('          const urls = [`${HOST}/index.php/vod/detail/id/${vod.vod_id}.html`, `${HOST}/detail/${vod.vod_id}.html`];')
        else:
            js.append('          const urls = [`${HOST}/detail/${vod.vod_id}.html`];')

        js.extend([
            "          let html = '';",
            "          for (const u of urls) {",
            "            const res = await fm.req(u, { method: 'GET', responseType: 'text', timeout: 30, headers: { 'Referer': HOST + '/' } });",
            "            if (res.ok) { html = res.body; break; }",
            "          }",
            "          if (!html) { descEl.textContent = '无法加载详情页'; return; }",
            "          const doc = new DOMParser().parseFromString(html, 'text/html');",
            "          // 提取播放源",
            "          const panels = doc.querySelectorAll('.hy-play-list .panel, .module-tab, .playlist');",
            "          const sources = []; const episodes = {};",
            "          panels.forEach((panel, idx) => {",
            "            const sname = panel.querySelector('.option, .tab, h3')?.textContent?.trim() || `源${idx+1}`;",
            "            sources.push(sname);",
            "            const eps = panel.querySelectorAll('a[href*="/play/"], a[href*="/vod/play/"]');",
            "            episodes[sname] = Array.from(eps).map(ep => ({",
            "              title: ep.textContent.trim(),",
            "              url: fixUrl(ep.getAttribute('href'))",
            "            })).filter(e => e.url);",
            "          });",
            "          if (!sources.length) {",
            "            // 尝试直接提取m3u8",
            "            const m3u8 = html.match(/(https?:\/\/[^\s"']+\.m3u8[^\s"']*)/)?.[1];",
            "            if (m3u8) { sources.push('直链'); episodes['直链'] = [{title: '正片', url: m3u8}]; }",
            "          }",
            "          descEl.textContent = `共找到 ${sources.length} 个播放源`;",
            "          renderSources(sources, episodes);",
            "        } catch(err) {",
            "          descEl.textContent = '解析失败: ' + err.message;",
            "          console.error(err);",
            "        }",
            "      }",
            "",
            "      function renderSources(sources, episodes) {",
            "        const overlay = document.querySelector('.detail-overlay');",
            "        const tabs = overlay.querySelector('.source-tabs');",
            "        const grid = overlay.querySelector('.episode-grid');",
            "        let activeSource = sources[0];",
            "        function renderEps(src) {",
            "          grid.innerHTML = '';",
            "          (episodes[src] || []).forEach(ep => {",
            "            const btn = document.createElement('div'); btn.className = 'episode'; btn.tabIndex = 0; btn.textContent = ep.title;",
            "            btn.addEventListener('click', () => playEpisode(ep.url, ep.title));",
            "            btn.addEventListener('keydown', e => { if (e.key === 'Enter') playEpisode(ep.url, ep.title); });",
            "            grid.appendChild(btn);",
            "          });",
            "        }",
            "        sources.forEach(src => {",
            "          const tab = document.createElement('div'); tab.className = 'source-tab'; tab.textContent = src; tab.tabIndex = 0;",
            "          tab.addEventListener('click', () => {",
            "            tabs.querySelectorAll('.source-tab').forEach(t => t.classList.remove('active'));",
            "            tab.classList.add('active'); activeSource = src; renderEps(src);",
            "          });",
            "          tabs.appendChild(tab);",
            "        });",
            "        if (tabs.firstChild) tabs.firstChild.classList.add('active');",
            "        renderEps(activeSource);",
            "      }",
            "",
            "      async function playEpisode(url, title) {",
            "        try {",
            "          if (url.match(/\.(m3u8|mp4|flv)$/i)) {",
            "            await fm.play(url, title || currentVod?.vod_name, { headers: { Referer: HOST + '/' } });",
            "          } else if (window.fm && fm.vod) {",
            "            await fm.vod(SITE_KEY, currentVod.vod_id, currentVod.vod_name, currentVod.vod_pic);",
            "          } else {",
            "            // 尝试解析播放页",
            "            const res = await fm.req(url, { method: 'GET', responseType: 'text', timeout: 30, headers: { Referer: HOST + '/' } });",
            "            if (res.ok) {",
            "              const m3u8 = res.body.match(/(https?:\/\/[^\s"']+\.m3u8[^\s"']*)/)?.[1];",
            "              if (m3u8) await fm.play(m3u8, title || currentVod?.vod_name, { headers: { Referer: HOST + '/' } });",
            "            }",
            "          }",
            "        } catch(err) { console.error('播放失败', err); alert('播放失败: ' + err.message); }",
            "      }",
            "",
            "      function closeDetail() {",
            "        document.body.classList.remove('detail-active');",
            "        document.querySelector('.detail-overlay')?.classList.remove('active');",
            "      }",
            "",
            "      function setupEvents() {",
            "        // 搜索",
            "        const searchInput = document.querySelector('.search-box input');",
            "        const searchBtn = document.querySelector('.search-box button');",
            "        if (searchBtn) searchBtn.addEventListener('click', () => {",
            "          const kw = searchInput?.value?.trim();",
            "          if (kw) fm.search(kw, { direct: true });",
            "        });",
            "        if (searchInput) searchInput.addEventListener('keydown', e => {",
            "          if (e.key === 'Enter') { const kw = searchInput.value.trim(); if (kw) fm.search(kw, { direct: true }); }",
            "        });",
            "        // 返回键处理",
            "        window.addEventListener('keydown', e => {",
            "          if (e.key === 'Backspace' || e.key === 'Escape') {",
            "            if (document.querySelector('.detail-overlay.active')) { e.preventDefault(); closeDetail(); }",
            "          }",
            "        });",
            "        // 路由",
            "        window.addEventListener('popstate', e => {",
            "          if (!e.state || e.state.route === 'home') closeDetail();",
            "        });",
            "      }",
            "",
            "      // 初始化",
            "      window.addEventListener('fmsdk', init);",
            "      if (window.fm) init();",
            "    })();",
            "  </script>",
        ])
        return js


# ═══════════════════════════════════════════════════════════════════════════════
# 卷九：双生造化炉 —— 归一帝法引擎（九秘合一·万法归一）
# ═══════════════════════════════════════════════════════════════════════════════

class 双生造化炉:
    """归一帝法核心引擎。同时驾驭阴源（Spider.py）与阳源（WebHome.html），
    一念之间为任意网站铸成双生之源，共享域名、CMS、分类、选择器、反爬方案。"""

    def __init__(self, host: str, site_key: str = "", site_name: str = "",
                 cms: str = "v10", content_type: str = "video",
                 diagnosis: Dict = None):
        self.host = host.rstrip("/")
        self.site_key = site_key or re.sub(r"[^a-zA-Z0-9_]", "_", urlparse(host).netloc.replace(".", "_"))
        self.site_name = site_name or f"遮天·{urlparse(host).netloc}"
        self.cms = cms
        self.content_type = content_type
        self.diagnosis = diagnosis or {"帝兵覆盖": set(["荒塔", "诛仙四剑", "吞天魔罐"])}
        self.阴源 = 造化生成器(self.diagnosis, host=host, cms=cms, content_type=content_type)
        self.阳源 = 阳源造化炉(host=host, site_key=self.site_key, site_name=self.site_name,
                              cms=cms, content_type=content_type)

    def 铸源(self) -> Dict[str, str]:
        """同时铸造阴源、阳源、源引，返回三件套字典。"""
        阴 = self.阴源.生成()
        阳 = self.阳源.生成()
        引 = self._铸源引()
        return {
            f"spider_{self.site_key}.py": 阴,
            f"home_{self.site_key}.html": 阳,
            f"config_{self.site_key}.json": 引,
        }

    def _铸源引(self) -> str:
        cfg = {
            "key": self.site_key,
            "name": self.site_name,
            "type": 3,
            "api": "csp_Builtin",
            "homePage": f"./home_{self.site_key}.html",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1,
            "ext": self.host,
        }
        return json.dumps(cfg, ensure_ascii=False, indent=2)

    def 验证契约(self, 阴: str, 阳: str) -> Dict:
        """验证阴源与阳源的数据契约一致性。"""
        checks = {
            "域名一致": self.host in 阴 and self.host in 阳,
            "CMS标识": self.cms in 阴 and self.cms in 阳,
            "分类体系": all(c["type_name"] in 阳 for c in self.阳源.classes),
            "内容类型": self.content_type in 阴,
            "vod_id解析": "vod_id" in 阴 and "vod_id" in 阳,
            "图片修复": "fix_url" in 阴 and "fixUrl" in 阳,
            "播放格式": 内容类型表.get(self.content_type, 内容类型表["video"]).player_format in 阴,
        }
        checks["契约完整"] = all(checks.values())
        return checks



# 卷十：主控程序 —— CLI与万法调度（归一帝法版） —— CLI与万法调度（帝兵版）
# ═══════════════════════════════════════════════════════════════════════════════

def 打印帝兵帮助(帝兵名: str = ""):
    if 帝兵名:
        if 帝兵名 in 帝兵谱:
            b = 帝兵谱[帝兵名]
            print(f"\n【{b.name}】· {b.大帝}所铸极道帝兵")
            print(f"原九秘: {b.原秘}字秘")
            print(f"境界: {b.推荐境界}")
            print(f"说明: {b.desc}")
            print(f"能力: {', '.join(b.abilities)}")
            print(f"克制: {', '.join(b.克制)}")
            print(f"标签: {', '.join(b.skill_tags)}")
            # 打印该帝兵下的指令
            print(f"\n附属指令:")
            for k, v in 指令库.items():
                if v.所属帝兵 == 帝兵名:
                    print(f"  ▸ {v.name} - {v.desc[:40]}...")
        else:
            print(f"未找到帝兵: {帝兵名}")
            print("可用帝兵列表:")
            for k, v in 帝兵谱.items():
                print(f"  {k} ({v.大帝}) - {v.desc[:30]}...")
    else:
        print("\n" + "═" * 72)
        print("遮天法 · 极道帝兵谱 v4.0（万法归一融合版）")
        print("═" * 72)
        print("\n【九大帝兵】")
        for k, v in 帝兵谱.items():
            print(f"\n  【{k}】· {v.大帝}所铸")
            print(f"     原秘: {v.原秘}字秘 | 境界: {v.推荐境界}")
            print(f"     说明: {v.desc}")
            print(f"     能力: {', '.join(v.abilities)}")
        print("\n【辅助帝兵】")
        for k, v in 辅助帝兵.items():
            print(f"  {k} - {v['功能']} ({v['效果']})")
        print("\n【八境功法模板】")
        realms = [
            ("轮海境", "道经", "DaoJingSpider", "直接正则，无加密无反爬"),
            ("道宫境", "西皇经", "XiHuangJingSpider", "Session复用，工具链"),
            ("四极境", "九秘→帝兵", "JiuMiSpider", "m3u8去广告/域名漂移/JS Cookie"),
            ("化龙境", "太皇经", "TaiHuangJingSpider", "多模态/Nuxt/动态接口"),
            ("仙台境", "太阴太阳", "TaiYinTaiYangSpider", "纯Python AES/自建代理"),
            ("圣人境", "无始经", "WuShiJingSpider", "双重Base64/XOR/HLS重写"),
            ("大圣境", "帝经", "DiJingSpider", "jsjiami逆向/AES-256/全密文"),
            ("准帝境", "天帝经", "TianDiJingSpider", "ENC2协议/AI广告清洗"),
        ]
        for realm, gongfa, cls, desc in realms:
            print(f"  {realm} · {gongfa} ({cls}) - {desc}")
        print("\n查看单条帝兵: python 遮天_极道帝兵_万法归一.py --帝兵 荒塔")
        print("一键工作流:   python 遮天_极道帝兵_万法归一.py --mode workflow --url https://example.com")
        print("智能推荐:     python 遮天_极道帝兵_万法归一.py --mode recommend --url https://example.com")

def main():
    parser = argparse.ArgumentParser(description='遮天法 · 极道帝兵 · 爬虫源开发指令系统')
    parser.add_argument('--file', '-f', type=str, default='', help='分析本地脚本文件')
    parser.add_argument('--url', '-u', type=str, default='', help='分析目标网址/生成源码')
    parser.add_argument('--source', '-s', type=str, default='', help='直接传入源码文本')
    parser.add_argument('--帝兵', '-b', type=str, default='', help='查看指定帝兵帮助')
    parser.add_argument('--host', type=str, default='', help='生成代码时使用的目标域名')
    parser.add_argument('--输出', '-o', type=str, default='./zhetian_dibing_spider.py', help='输出脚本路径')
    parser.add_argument('--mode', '-m', type=str, default='analyze',
                       choices=['analyze','workflow','batch','diagnose','generate','verify','recommend','unified'], help='工作模式')
    parser.add_argument('--type', '-t', type=str, default='video', help='内容类型')
    parser.add_argument('--cms', type=str, default='auto', help='CMS类型')
    parser.add_argument('--batch-file', type=str, default='', help='批量分析URL列表文件')
    args = parser.parse_args()

    if args.帝兵:
        打印帝兵帮助(args.帝兵)
        return

    source = args.source
    if args.file:
        try:
            with open(args.file, 'r', encoding='utf-8', errors='ignore') as f:
                source = f.read()
            print(f"已加载文件: {args.file} ({len(source)} 字符)")
        except Exception as e:
            print(f"读取文件失败: {e}"); sys.exit(1)

    if args.mode == 'recommend' and args.url:
        print("\n" + "▓" * 72)
        print("遮天法 · 极道帝兵 · 智能推荐模式")
        print("▓" * 72)
        引擎 = 帝兵推荐引擎()
        report = 引擎.分析网站(args.url, "", args.cms if args.cms != "auto" else "nonstandard")
        引擎.打印推荐(report)
        return

    if args.mode == 'workflow' and args.url:
        print("\n" + "▓" * 72)
        print("遮天法 · 极道帝兵 · 一键工作流启动")
        print("▓" * 72)
        engine = 万法工作流引擎()
        result = engine.执行(args.url, args.type, mode="generate")
        print(json.dumps({k:v for k,v in result.items() if k != 'code'}, ensure_ascii=False, indent=2))
        if result.get('code'):
            with open(args.输出, 'w', encoding='utf-8') as f:
                f.write(result['code'])
            print(f"\n✅ 源码已保存: {os.path.abspath(args.输出)} ({len(result['code'].splitlines())}行)")
        return

    if args.mode == 'verify' and args.url:
        print("\n" + "▓" * 72)
        print("遮天法 · 极道帝兵 · 全链路验证模式")
        print("▓" * 72)
        engine = 万法工作流引擎()
        result = engine.执行(args.url, args.type, mode="verify")
        print(json.dumps({k:v for k,v in result.items() if k != 'code'}, ensure_ascii=False, indent=2))
        if result.get('code'):
            with open(args.输出, 'w', encoding='utf-8') as f:
                f.write(result['code'])
            print(f"\n✅ 源码已保存: {os.path.abspath(args.输出)}")
            print(f"✅ 规范评估: {result.get('evaluate',{}).get('grade','?')}级")
            print(f"✅ 接口验证: {result.get('verify',{}).get('pass_rate',0):.0%}通过率")
        return

    if args.mode == 'batch' or args.batch_file:
        urls = []
        if args.batch_file:
            with open(args.batch_file, 'r') as f:
                urls = [line.strip() for line in f if line.strip()]
        elif args.url:
            urls = args.url.split(',')
        if not urls:
            print("批量模式需要--batch-file或逗号分隔的--url")
            return
        print("\n" + "▓" * 72)
        print(f"遮天法 · 极道帝兵 · 批量分析 ({len(urls)}个站点)")
        print("▓" * 72)
        engine = 万法工作流引擎()
        results = engine.批量执行(urls, args.type)
        for r in results:
            print(f"\n{r['url']} -> CMS:{r.get('cms','?')} | 成功:{r['success']}")
            if r.get('推荐'):
                print(f"  推荐功法: {' → '.join(r['推荐']['主修功法'])}")
                print(f"  本命帝兵: {r['推荐']['本命帝兵']}")
        return

    if args.mode == 'generate' and args.url:
        print("\n" + "▓" * 72)
        print("遮天法 · 极道帝兵 · 直接生成模式")
        print("▓" * 72)
        cms = args.cms
        if cms == "auto":
            cms, conf = 识别CMS类型(args.url, "")
            print(f"自动识别CMS: {cms} (置信度{conf:.0%})")
        gen = 造化生成器({"帝兵覆盖": set(["荒塔","诛仙四剑","吞天魔罐","无始钟","仙珍图","混沌青莲","虚空镜","不死天刀"])},
                        host=args.url, cms=cms, content_type=args.type)
        code = gen.生成()
        with open(args.输出, 'w', encoding='utf-8') as f:
            f.write(code)
        print(f"✅ 生成成功: {os.path.abspath(args.输出)} ({len(code.splitlines())}行)")
        print(f"✅ CMS类型: {cms}")
        print(f"✅ 内容类型: {args.type}")
        ev = 评估代码规范(code)
        print(f"✅ 规范评估: {ev['grade']}级 (得分{ev['score']:.0%})")
        return
    if args.mode == 'unified' and args.url:
        print("\n" + "▓" * 72)
        print("遮天法 · 九秘归一 · 源天造化 · 归一帝法启动")
        print("同时铸造：阴源(Spider.py) + 阳源(WebHome.html) + 源引(Config.json)")
        print("▓" * 72)
        cms = args.cms
        if cms == "auto":
            cms, conf = 识别CMS类型(args.url, "")
            print(f"祭出荒塔 → CMS识别: {cms} (置信度{conf:.0%})")
        推荐 = 帝兵推荐引擎()
        report = 推荐.分析网站(args.url, "", cms, {"risk_level": "低", "protections": []})
        推荐.打印推荐(report)
        print("\n祭出不死天刀 → 双生造化炉开炉...")
        炉 = 双生造化炉(host=args.url, cms=cms, content_type=args.type)
        三件套 = 炉.铸源()
        输出目录 = os.path.dirname(args.输出) or "."
        os.makedirs(输出目录, exist_ok=True)
        for 文件名, 内容 in 三件套.items():
            路径 = os.path.join(输出目录, 文件名)
            with open(路径, 'w', encoding='utf-8') as f:
                f.write(内容)
            print(f"  ✅ {文件名} ({len(内容.splitlines())}行) → {os.path.abspath(路径)}")
        # 验证契约
        契约 = 炉.验证契约(三件套[f"spider_{炉.site_key}.py"], 三件套[f"home_{炉.site_key}.html"])
        print("\n【数据契约验证】")
        for k, v in 契约.items():
            print(f"  {'✅' if v else '❌'} {k}")
        if 契约["契约完整"]:
            print("\n🎉 归一帝法大成！阴源与阳源同源同根，数据契约完整。")
        else:
            print("\n⚠️ 契约存在缺口，建议祭出混沌青莲进一步验证。")
        return


    if not source or len(source) < 50:
        print("\n遮天法 · 极道帝兵 · 万法归一 · 爬虫源开发指令系统")
        print("=" * 60)
        print("未提供有效源码，显示完整帝兵帮助:\n")
        打印帝兵帮助()
        print("\n" + "=" * 60)
        print("用法示例:")
        print("  python 遮天_极道帝兵_万法归一.py --file ./四色.py")
        print("  python 遮天_极道帝兵_万法归一.py --url https://example.com --mode recommend")
        print("  python 遮天_极道帝兵_万法归一.py --url https://example.com --mode workflow")
        print("  python 遮天_极道帝兵_万法归一.py --url https://example.com --mode verify --type video")
        print("  python 遮天_极道帝兵_万法归一.py --url https://example.com --mode generate --cms v10")
        print("  python 遮天_极道帝兵_万法归一.py --url https://example.com --mode unified --cms v10")
        print("  python 遮天_极道帝兵_万法归一.py --batch-file urls.txt --mode batch")
        print("  python 遮天_极道帝兵_万法归一.py --帝兵 荒塔")
        return

    print("\n" + "▓" * 72)
    print("正在施展源术分析...")
    print("▓" * 72)

    analyzer = 源码分析器(source)
    engine = 遮天诊断引擎(analyzer)
    diagnosis = engine.诊断()

    print(engine.生成处方(diagnosis))

    if args.mode == 'diagnose':
        return

    print("\n" + "▓" * 72)
    print("正在以帝兵之力构建Spider源码...")
    print("▓" * 72)

    host = args.host or "https://example.com"
    cms = args.cms if args.cms != "auto" else "v10"
    gen = 造化生成器(diagnosis, host=host, cms=cms, content_type=args.type)
    code = gen.生成()

    if 'self_repair' in 指令库:
        code = 指令库['self_repair'].code.strip()

    with open(args.输出, 'w', encoding='utf-8') as f:
        f.write(code)

    verify = auto_verify({}, code)
    evaluate = 评估代码规范(code)

    print(f"\n✅ 生成成功: {os.path.abspath(args.输出)}")
    print(f"✅ 注入帝兵: {', '.join(diagnosis['帝兵覆盖']) or '荒塔, 诛仙四剑, 吞天魔罐'}")
    print(f"✅ 九秘映射: {', '.join(diagnosis['九秘覆盖']) or '临, 斗, 兵'}")
    print(f"✅ SKILL融合度: {diagnosis['skill融合度']}")
    print(f"✅ 工作流就绪: {'是' if diagnosis['工作流就绪'] else '否'}")
    print(f"✅ 代码规范: {evaluate['grade']}级 (得分{evaluate['score']:.0%})")
    print(f"✅ 接口验证: {verify['passed']}/{verify['total']} 通过")
    print(f"✅ 代码行数: {len(code.splitlines())}")
    print(f"\n使用说明:")
    print("  1. 查看已识别指令的完整代码:")
    print("     python 遮天_极道帝兵_万法归一.py --帝兵 荒塔")
    print("  2. 智能推荐功法和帝兵:")
    print("     python 遮天_极道帝兵_万法归一.py --mode recommend --url https://example.com")
    print("  3. 一键工作流:")
    print("     python 遮天_极道帝兵_万法归一.py --mode workflow --url https://example.com")
    print("  4. 全链路验证:")
    print("     python 遮天_极道帝兵_万法归一.py --mode verify --url https://example.com")
    print("  5. 九秘归一·双生输出:")
    print("     python 遮天_极道帝兵_万法归一.py --mode unified --url https://example.com")
    print("\n极道帝兵，万法归一，为你护道！")

if __name__ == '__main__':
    main()